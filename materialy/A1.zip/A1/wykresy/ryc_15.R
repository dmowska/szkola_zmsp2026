################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 15
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "(A) Średnia roczna temperatura powietrza (Tr) w Stacji Bazowej ZMŚP
#   {nazwa_stacji} w wieloleciu {zakres_lat(lata_ryc_15)}. Niebieska
#   linia pokazuje trend zmian wyznaczony metodą Theila-Sena (nachylenie linii
#   (slope) = {tad_trend_txt["slope"]} °C/rok, wartość poziomu istotności
#   {tad_trend_txt["pvalue"]}) - przy serii krótszej niż 5 lat zdanie o trendzie
#   zastępuje informacja, że trendu nie wyznaczono. Czerwona przerywana linia wskazuje średnią
#   wieloletnią temperaturę powietrza obliczoną dla wielolecia
#   {rok_poczatek}-{rok_koniec}. (B) Zmienność miesięcznych wartości
#   temperatury powietrza (Tm). Niebieskie kropki pokazują wartości średnie w
#   analizowanym roku. Czerwona przerywana linia wskazuje średnią wieloletnią
#   temperaturę powietrza obliczoną dla wielolecia
#   {rok_poczatek}-{rok_koniec}"
#
# Uwagi do kodu:
# Oba panele mają jawnie ustawiony ten sam zakres osi X, żeby podziałki
# pokrywały się przy składaniu przez plot_grid(align = "v").
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_agg_vw_m: wartości miesięczne wszystkich lat analizy
# - a1_dane_agg_vw_roczne: wartości roczne (wiersze RH) wszystkich lat
#     analizy
# - krok_osi_lat: funkcja: krok podpisów osi lat dobrany do długości serii
# - lata_ryc_15: lata, w których rycina ma dane - z nich powstają
#     podziałki osi X
# - plot_theme: funkcja: wspólny motyw wykresów raportu
# - srednia_temp_wielolecia: średnia temperatura wielolecia, bez roku
#     analizowanego
# - tad_trend: parametry trendu Theila-Sena: slope, intercept, pvalue
################################################################################
# WYNIK
################################################################################
# - dane_ryc_15: wartości roczne uzupełnione o wiersze z NA za lata bez
#     pomiaru - dzięki nim linia panelu A przerywa się na lukach w serii
# - ryc_15: gotowa rycina złożona z kilku paneli (obiekt cowplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - cowplot
# - ggplot2
# - tidyr
################################################################################

# Oś X jest liczbowa, od pierwszego do ostatniego roku z danymi tej ryciny (lata_ryc_15
# z przetwarzanie_danych.R). Podziałka i linia siatki stoją przy KAŻDYM roku zakresu,
# także tym, dla którego stacja nie ma pomiaru. Rok bez danych zostaje wtedy widoczny
# jako przerwa w serii przy własnej podziałce, zamiast wypadać z osi razem z nią.
# Jawne limits utrzymują stały margines - skala ciągła rozszerzyłaby zakres
# o szerokość skrajnych słupków.
# Oba panele mają ten sam zakres i te same podziałki, żeby pokrywały się po złożeniu.
lata_os_x   = min(lata_ryc_15):max(lata_ryc_15)
zakres_os_x = range(lata_os_x) + c(-0.6, 0.6)

# Podpisy przerzedza krok_osi_lat (docelowo = 15, bo oś zajmuje całą szerokość
# ryciny), ale PODZIAŁKA I SIATKA zostają przy każdym roku - rok bez pomiaru ma
# własną kreskę, więc luka w serii jest widoczna także tam, gdzie nie ma podpisu.
krok_lat_15    = krok_osi_lat(length(lata_os_x), docelowo = 15)
podpisy_lat_15 = ifelse((seq_along(lata_os_x) - 1) %% krok_lat_15 == 0,
                        lata_os_x, "")

# Rok bez pomiaru musi mieć własny wiersz z wartością NA, inaczej linia panelu A
# przechodzi nad luką jak nad odcinkiem z danymi: geom_line łączy kolejne punkty,
# a rok, którego w ramce w ogóle nie ma, niczego nie rozdziela. Wiersz z NA
# przerywa linię dokładnie w miejscu przerwy w serii. complete() dokłada brakujące
# lata, a te już obecne zostawia bez zmian.
dane_ryc_15 = a1_dane_agg_vw_roczne |>
  complete(rok_hydro = lata_os_x)

# Panel A: przebieg roczny, prosta trendu Theila-Sena i średnia wielolecia.
# Prosta jest wyrażona w latach kalendarzowych, więc oś X musi być ciągła -
# na osi dyskretnej geom_abline trafiłby daleko poza panel.
# Prosta trendu tylko wtedy, gdy trend w ogóle wyznaczono. Przy krótszej niż
# 5-letnia serii przetwarzanie_danych.R zostawia w tad_trend same NA - dodanie
# NULL do wykresu jest wtedy pustą operacją, a geom_abline z NA rysowałby nic
# i zostawiał ostrzeżenie przy każdym renderowaniu raportu.
warstwa_trendu <- if (is.na(tad_trend["slope"])) {
  NULL
} else {
  geom_abline(intercept = tad_trend["intercept"], slope = tad_trend["slope"],
              color = "blue", linewidth = 0.5)
}

panelA <- ggplot(dane_ryc_15, aes(x = rok_hydro, y = `TA_D avg`)) +
  warstwa_trendu +
  geom_line(color = "black", linewidth = 0.5) +
  geom_point(shape = 21, fill = "black", color = "black", size = 1.5) +

  geom_hline(yintercept = srednia_temp_wielolecia, linewidth = 1, color = "red", linetype = "dashed") +
  scale_x_continuous(breaks = lata_os_x, labels = podpisy_lat_15,
                     limits = zakres_os_x, expand = expansion(add = 0)) +
  scale_y_continuous(
    limits = c(0, NA),
    expand = expansion(mult = c(0, 0.05)),
    breaks = function(x) seq(0, ceiling(max(x)), by = 2)
  ) +
  xlab("") +
  ylab(expression(paste("T"[r], " [°C]"))) +

  plot_theme() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5))

# Dolna granica osi Y z minimum, a nie z zera: miesiące zimowe mają ujemne średnie,
# a limits = c(0, ...) wycinałoby je z danych i zaniżało boxploty.
# min_lub/max_lub zamiast min/max: przy stacji bez pomiarów temperatury zakres
# wyszedłby c(Inf, -Inf), a seq() budujący podziałki panelu B przerwałby pracę,
# zanim skrypt doszedłby do własnego warunku NULL w ostatniej linii.
zakres_tm = c(floor(min_lub(a1_dane_agg_vw_m$`TA_D avg`, 0) / 5) * 5,
              ceiling(max_lub(a1_dane_agg_vw_m$`TA_D avg`, 5) / 5) * 5)

# Panel B: rozkład wartości miesięcznych w każdym roku. group = rok_hydro daje
# jeden boxplot na rok - bez tego skala ciągła zlałaby wszystkie lata w jeden.
panelB = ggplot(a1_dane_agg_vw_m, aes(x = rok_hydro, y = `TA_D avg`, group = rok_hydro)) +
  geom_boxplot(color = "black") +
  geom_point(data = a1_dane_agg_vw_roczne, aes(x = rok_hydro, y = `TA_D avg`), shape = 21, fill = "blue", color = "blue", size = 1.5) +
  geom_hline(yintercept = srednia_temp_wielolecia, linewidth = 1, color = "red", linetype = "dashed") +
  xlab("") +
  ylab(expression(paste("T"[m], " [°C]"))) +
  scale_x_continuous(breaks = lata_os_x, labels = podpisy_lat_15,
                     limits = zakres_os_x, expand = expansion(add = 0)) +
  scale_y_continuous(limits = zakres_tm,
                     breaks = seq(zakres_tm[1], zakres_tm[2], by = 5)) +
  plot_theme() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5),
        plot.margin = margin(r = 5, l = 15))

# Panele jeden pod drugim, ze wspólną osią X.
ryc_15 = plot_grid(panelA, panelB, nrow = 2, labels = "AUTO", align = "v")

ryc_15

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_15)).
if (!(ma_dane(a1_dane_agg_vw_roczne$`TA_D avg`, a1_dane_agg_vw_m$`TA_D avg`))) ryc_15 <- NULL
