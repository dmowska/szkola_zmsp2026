################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 1
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Przebieg dobowych wartości temperatury powietrza (średniej (T śr),
#   maksymalnej (T max) i minimalnej (T min)) w Stacji Bazowej ZMŚP
#   {nazwa_stacji} w {analizowany_rok} roku"
#
# Uwagi do kodu:
# Podziałki osi X stoją w pierwszych dniach kolejnych miesięcy, policzonych z
# danych. Zakres osi Y zaokrąglany do pełnych 5 °C.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_dobowe_vw: pomiary dobowe roku analizowanego; dzien_roku
#     numeruje dni od 1 XI
# - miesiac_rzymski: funkcja: numer miesiąca zapisem rzymskim
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - ryc_1: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
# - ggplot2
################################################################################

# Zakres osi Y wspólny dla trzech serii, zaokrąglony do pełnych 5 °C.
wart_min = min(c(a1_dane_dobowe_vw$TA_D, a1_dane_dobowe_vw$TA_X, a1_dane_dobowe_vw$TA_N), na.rm = TRUE)
wart_max = max(c(a1_dane_dobowe_vw$TA_D, a1_dane_dobowe_vw$TA_X, a1_dane_dobowe_vw$TA_N), na.rm = TRUE)
lim_min = floor(wart_min / 5) * 5
lim_max = ceiling(wart_max / 5) * 5
lw = 0.6

# Podziałki osi X w pierwszych dniach kolejnych miesięcy, policzone z danych:
# miesiące mają różną długość, a rok hydrologiczny bywa przestępny.
osie_miesiecy = a1_dane_dobowe_vw |>
  group_by(miesiac) |>
  summarise(dzien_roku = min(dzien_roku), .groups = "drop") |>
  arrange(miesiac)

# Nazwy serii podane w aes(color=) tworzą legendę, a scale_color_manual
# ustala ich barwy i kolejność.
ryc_1 <- ggplot(data = a1_dane_dobowe_vw) +
  geom_line(aes(x = dzien_roku, y = `TA_X`, color = "T max"), linewidth = lw) +
  geom_line(aes(x = dzien_roku, y = `TA_D`, color = "T śr"),  linewidth = lw) +
  geom_line(aes(x = dzien_roku, y = `TA_N`, color = "T min"), linewidth = lw) +
  scale_color_manual(
    name = "",
    values = c(
      "T max" = "#D73027",
      "T śr" = "black",
      "T min" = "#4575B4"
    ),
    breaks = c("T max", "T śr", "T min")
  ) +
  scale_x_continuous(breaks = osie_miesiecy$dzien_roku,
                     labels = miesiac_rzymski(osie_miesiecy$miesiac)) +
  scale_y_continuous(limits = c(lim_min, lim_max),
  breaks = seq(from = -100, to = 100, by = 5)) +
  xlab("") +
  ylab(expression("Temperatura powietrza [°C]")) +
  plot_theme()

ryc_1

rm(wart_min, wart_max, lim_min, lim_max, lw)

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_1)).
if (!(ma_dane(a1_dane_dobowe_vw$TA_X, a1_dane_dobowe_vw$TA_D, a1_dane_dobowe_vw$TA_N))) ryc_1 <- NULL
