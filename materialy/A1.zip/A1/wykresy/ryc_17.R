################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 17
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Wskaźnik śnieżności zimy w Stacji Bazowej ZMŚP {nazwa_stacji} w
#   wieloleciu {zakres_lat(lata_ryc_17)}"
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_pokrywa_sniezna_vw: roczne charakterystyki pokrywy śnieżnej, w tym
#     wskaźnik Wsn
# - krok_osi_lat: funkcja: krok podpisów osi lat dobrany do długości serii
# - lata_ryc_17: lata, w których rycina ma dane - z nich powstają
#     podziałki osi X
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - ryc_17: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
################################################################################

# Oś X jest liczbowa, od pierwszego do ostatniego roku z danymi tej ryciny (lata_ryc_17
# z przetwarzanie_danych.R). Podziałka i linia siatki stoją przy KAŻDYM roku zakresu,
# także tym, dla którego stacja nie ma pomiaru. Rok bez danych zostaje wtedy widoczny
# jako przerwa w serii przy własnej podziałce, zamiast wypadać z osi razem z nią.
# Jawne limits utrzymują stały margines - skala ciągła rozszerzyłaby zakres
# o szerokość skrajnych słupków.
lata_os_x   = min(lata_ryc_17):max(lata_ryc_17)
zakres_os_x = range(lata_os_x) + c(-0.6, 0.6)

# Podpisy przerzedza krok_osi_lat (docelowo = 15, bo oś zajmuje całą szerokość
# ryciny), ale PODZIAŁKA I SIATKA zostają przy każdym roku - rok bez pomiaru ma
# własną kreskę, więc luka w serii jest widoczna także tam, gdzie nie ma podpisu.
krok_lat_17    = krok_osi_lat(length(lata_os_x), docelowo = 15)
podpisy_lat_17 = ifelse((seq_along(lata_os_x) - 1) %% krok_lat_17 == 0,
                        lata_os_x, "")

# Słupki wskaźnika śnieżności; oś Y od zera do najbliższej liczby całkowitej.
ryc_17 = ggplot(a1_pokrywa_sniezna_vw, aes(x = rok_hydro, y = Wsn)) +
  geom_bar(stat = "identity", fill = "#2f75b5") +
  xlab("") +
  ylab("Wskaźnik śnieżności zimy") +
  scale_x_continuous(breaks = lata_os_x, labels = podpisy_lat_17,
                     limits = zakres_os_x, expand = expansion(add = 0)) +
  scale_y_continuous(limits = c(0,ceiling(max(a1_pokrywa_sniezna_vw$Wsn, na.rm = TRUE)))) +
  plot_theme() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5))

ryc_17

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_17)).
if (!(ma_dane(a1_pokrywa_sniezna_vw$Wsn))) ryc_17 <- NULL
