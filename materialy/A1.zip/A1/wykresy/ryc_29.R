################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 29
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Kompletność serii danych dla elementów meteorologicznych w Stacji Bazowej
#   ZMŚP {nazwa_stacji} w ujęciu miesięcznym w wieloleciu
#   {zakres_lat(lata_ryc_29)} (elementy temperaturowe)"
#
# Uwagi do kodu:
# Mapa rok x miesiąc, osobny panel dla każdego elementu - układ i sposób rysowania
# jak na rycinach 27 i 28. Elementy temperaturowe; pozostałe pokazuje rycina 30.
# Podział wynika z czytelności: komplet piętnastu paneli dałby kafelki tak wąskie,
# że nie dałoby się odczytać pojedynczego miesiąca.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - kolory_kompletnosc: paleta klas kompletności
# - kompletnosc_temperatura: elementy temperaturowe - te trafiają na tę rycinę
# - krok_osi_lat: funkcja: krok podpisów osi lat dobrany do długości serii
# - lata_ryc_29: lata, w których rycina ma dane - z nich powstaje zakres osi X
# - miesiace_hydro: miesiące w porządku roku hydrologicznego (11, 12,
#     1:10)
# - plot_theme: funkcja: wspólny motyw wykresów raportu
# - ryc_kompletnosc: kompletność każdego elementu w kolejnych miesiącach
#     i latach, wraz z klasą kompletności (postać długa)
################################################################################
# WYNIK
################################################################################
# - dane_ryc_29: kompletność elementów temperaturowych, bez tych, których
#     stacja nie mierzy w ogóle; z poziomów jej kolumny parametr powstaje blok
#     objaśnień pod ryciną w tworzenie_raportu.qmd
# - ryc_29: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
# - forcats
# - ggplot2
################################################################################

# Element, którego stacja nie mierzy W OGÓLE (kompletność pusta w każdym miesiącu
# każdego roku), nie dostaje własnej fasety - byłby to panel jednolicie szary,
# powtarzający to, co widać już po jego nieobecności w tabelach. Element mierzony
# choćby przez jeden miesiąc zostaje, bo wtedy panel pokazuje, kiedy seria się
# zaczyna i gdzie ma dziury.
dane_ryc_29 <- ryc_kompletnosc |>
  filter(parametr %in% kompletnosc_temperatura) |>
  group_by(parametr) |>
  filter(!all(is.na(kompletnosc))) |>
  ungroup() |>
  mutate(parametr = fct_drop(parametr))

# Zakres osi X: od pierwszego do ostatniego roku z danymi tej ryciny (lata_ryc_29
# z przetwarzanie_danych.R), a nie całe wielolecie z parametrów. Krok podpisów
# dobrany do długości tej serii - jak na rycinach 27 i 28.
rok_od_29 <- min(lata_ryc_29)
rok_do_29 <- max(lata_ryc_29)
krok_lat_29 <- krok_osi_lat(rok_do_29 - rok_od_29 + 1)

# Siatkę rysujemy ręcznie, na stykach kafelków, bo domyślna trafiałaby w ich środki.
# Pionowa linia stoi przy każdym roku, także tym bez pomiarów.
ryc_29 = ggplot(dane_ryc_29, aes(x = rok_hydro, y = miesiac, fill = klasa)) +
  geom_tile() +

  geom_vline(xintercept = seq(rok_od_29 - 0.5, rok_do_29 + 0.5, by = 1), color = "lightgrey", linewidth = 0.2) +
  geom_hline(yintercept = seq(0.5, length(miesiace_hydro) + 0.5, by = 1), color = "lightgrey", linewidth = 0.2) +

  # Pasek fasety niesie sam symbol elementu; jego rozwinięcie podaje blok objaśnień
  # pod ryciną, składany z tego samego słownika opisy_elementow. Pełne nazwy nie
  # mieszczą się na pasku panelu, a skracane na potrzeby ryciny rozjeżdżałyby się
  # z opisami spod tabel.
  facet_wrap(~parametr, ncol = 3) +

  scale_fill_manual(name = "Kompletność serii", values = kolory_kompletnosc) +

  scale_x_continuous(
    breaks = seq(rok_od_29, rok_do_29, krok_lat_29)
  ) +

  # drop = FALSE zostawia na osi wszystkie miesiące roku hydrologicznego, także
  # te bez pomiaru - inaczej miesiąc bez danych znika z osi razem z podpisem.
  scale_y_discrete(drop = FALSE, labels = as.roman(miesiace_hydro)) +

  labs(x = "", y = "") +
  # Dwa rzędy, jak na rycinach 27 i 28: sześć klas w jednym rzędzie nie mieści się
  # na szerokości ryciny i ostatnia etykieta wychodziłaby poza kadr.
  guides(fill = guide_legend(nrow = 2, byrow = TRUE)) +
  plot_theme() +
  theme(
    strip.text = element_text(size = 9, color = "black", face = "bold.italic"),
    strip.background = element_rect(color = "darkgrey", fill = "white"),
    axis.text.x = element_text(angle = 90, hjust = 1, size = 8),
    axis.text.y = element_text(size = 8),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position = "bottom",
    legend.text = element_text(size = 10, margin = margin(r = 12, l = 3, unit = "pt")),
    legend.title = element_text(size = 10),
    legend.key.size = unit(0.35, "cm")
  )

ryc_29

# Stacja, dla której baza nie podaje kompletności ŻADNEGO elementu temperaturowego,
# dałaby pustą ramkę z podpisem. NULL sprawia, że tworzenie_raportu.qmd pomija chunk
# tej ryciny (eval = !is.null(ryc_29)).
if (nrow(dane_ryc_29) == 0) ryc_29 <- NULL
