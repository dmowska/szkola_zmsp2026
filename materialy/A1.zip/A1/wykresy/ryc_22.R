################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 22
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Liczba dni charakterystycznych ze względu na temperaturę powietrza w
#   Stacji Bazowej ZMŚP {nazwa_stacji} w {analizowany_rok} roku. Kryteria
#   wyznaczenia dni charakterystycznych znajdują się w tabeli 8"
#
# Uwagi do kodu:
# Kategorie, których nie było ani razu w całym roku, są odsiewane: dane mają
# wiersz dla każdej kategorii w każdym miesiącu, więc bez tego zostawałyby w
# legendzie bez słupka.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dni_charakterystyczne_temp_etykiety: etykiety legendy dla kategorii
#     temperatury
# - kolory_dni_charakterystyczne_temp: paleta kolorów kategorii dni
#     charakterystycznych temperatury
# - miesiace_hydro: miesiące w porządku roku hydrologicznego (11, 12,
#     1:10)
# - plot_theme: funkcja: wspólny motyw wykresów raportu
# - ryc_dni_ch_temp_analizowany_rok: liczba dni charakterystycznych
#     temperatury w miesiącach roku analizowanego (postać długa)
################################################################################
# WYNIK
################################################################################
# - dane_ryc_22: liczba dni charakterystycznych temperatury w miesiącach
#     roku analizowanego, bez kategorii nieobecnych przez cały rok
# - ryc_22: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
# - forcats
# - ggplot2
################################################################################

# W legendzie mają zostać tylko kategorie widoczne na wykresie. Dane mają wiersz
# dla każdej kategorii w każdym miesiącu, więc kategoria nieobecna przez cały rok
# ma same zera: słupek jest niewidoczny, ale poziom faktora zostaje i trafia
# do legendy.
# Odsiewamy kategorie o zerowej sumie rocznej; zera w pojedynczych miesiącach
# zostają, bo trzymają słupki w równych odstępach.
dane_ryc_22 = ryc_dni_ch_temp_analizowany_rok |>
  group_by(kategoria) |>
  filter(sum(wartosc, na.rm = TRUE) > 0) |>
  ungroup() |>
  mutate(kategoria = fct_drop(kategoria))

# Słupki kategorii obok siebie w każdym miesiącu (position_dodge).
ryc_22 <- ggplot(dane_ryc_22, aes(x = miesiac, y = wartosc, fill = kategoria)) +

  geom_col(position = position_dodge(width = 0.8), width = 0.7, color = "black", linewidth = 0.2) +

  scale_fill_manual(
    name = NULL,
    values = kolory_dni_charakterystyczne_temp,
    labels = dni_charakterystyczne_temp_etykiety
  ) +
  # drop = FALSE zostawia na osi wszystkie miesiące roku hydrologicznego, także
  # te bez pomiaru: miesiąc bez danych ma być widoczny jako brak słupków przy
  # podpisanej podziałce, a nie znikać z osi razem z podpisem.
  scale_x_discrete(drop = FALSE, labels = as.roman(miesiace_hydro)) +
  scale_y_continuous(
    expand = expansion(mult = c(0, 0.1)),
    breaks = seq(0, 31, by = 2)
  ) +

  xlab("") +
  ylab("Liczba dni") +

plot_theme() +
  # Czcionka i wielkość symboli legendy jak na rycinie 24.
  theme(legend.text = element_text(size = 11, margin = margin(r = 6, l = 2, unit = "pt")),
        legend.key.size = unit(0.35, "cm")) +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE))

ryc_22

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_22)).
if (!(any(dane_ryc_22$wartosc > 0, na.rm = TRUE))) ryc_22 <- NULL
