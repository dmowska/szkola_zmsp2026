################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 26
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Udział typów dni charakterystycznych pod względem opadu atmosferycznego w
#   poszczególnych miesiącach roku hydrologicznego {analizowany_rok} (A),
#   poszczególnych miesiącach wielolecia {zakres_lat(lata_ryc_26)} (B),
#   oraz w latach hydrologicznych {zakres_lat(lata_ryc_26)} w Stacji
#   Bazowej ZMŚP {nazwa_stacji} (C)"
#   Gdy baza nie ma dni charakterystycznych za rok analizowany, rycina nie ma panelu
#   roku, a podpis wymienia tylko miesiące wielolecia (A) i kolejne lata (B).
#
# Uwagi do kodu:
# Legenda jest wspólna dla wszystkich paneli i pochodzi z panelu kolejnych lat.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - analizowany_rok: parametr z parametry.xlsx: analizowany rok
#     hydrologiczny
# - dni_charakterystyczne_opad_etykiety_mm: etykiety legendy: przedziały
#     opadu w mm
# - kolory_dni_charakterystyczne_opad: paleta kolorów kategorii dni
#     charakterystycznych opadu
# - krok_osi_lat: funkcja: krok podpisów osi lat dobrany do długości serii
# - lata_ryc_26: lata, w których rycina ma dane - z nich powstają zakres
#     lat w tytułach paneli wieloletnich i podziałki osi X panelu kolejnych lat
# - plot_theme: funkcja: wspólny motyw wykresów raportu
# - ryc_dni_ch_opad_analizowany_rok: liczba dni charakterystycznych opadu
#     w miesiącach roku analizowanego (postać długa)
# - ryc_dni_ch_opad_m: liczba dni charakterystycznych opadu zsumowana po
#     miesiącach całego wielolecia
# - ryc_dni_ch_opad_r: roczne sumy dni charakterystycznych opadu
################################################################################
# WYNIK
################################################################################
# - ryc_26: gotowa rycina złożona z kilku paneli (obiekt cowplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - cowplot
# - ggplot2
# - scales
################################################################################

# Rok analizowany bez dni charakterystycznych w bazie (rok zakwestionowany) nie dostaje
# pustego panelu A - panel bez słupków wyglądałby na usterkę. Rycina ma wtedy dwa
# panele: A - miesiące wielolecia i B - kolejne lata; podpis w tworzenie_raportu.qmd
# składa litery według tego samego warunku.
ma_rok_26 = any(!is.na(ryc_dni_ch_opad_analizowany_rok$wartosc))
litery_26 = if (ma_rok_26) c("A", "B", "C") else c(NA, "A", "B")

# Panel A: udziały kategorii w miesiącach roku analizowanego. position = "fill"
# normalizuje każdy słupek do 100%.
ryc_26A = ggplot(ryc_dni_ch_opad_analizowany_rok, aes(x = miesiac, y = wartosc, fill = kategoria)) +
  geom_bar(stat = "identity", position = "fill") +
  # drop = FALSE zostawia na osi wszystkie miesiące roku hydrologicznego, także
  # te bez pomiaru: miesiąc bez danych ma być widoczny jako brak słupka przy
  # podpisanej podziałce, a nie znikać z osi razem z podpisem.
  scale_x_discrete(
    drop = FALSE,
    labels = as.roman(levels(ryc_dni_ch_opad_analizowany_rok$miesiac))
  ) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  ggtitle(paste("A:",analizowany_rok)) +
  scale_fill_manual(values = kolory_dni_charakterystyczne_opad) +
  labs(x = "",y = "",fill = "Klasyfikacja dni z opadem:") +
  plot_theme() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.text.x = element_text(size = 8))

# Panel B: to samo dla miesięcy całego wielolecia.
ryc_26B = ggplot(ryc_dni_ch_opad_m, aes(x = miesiac, y = wartosc, fill = kategoria)) +
  geom_bar(stat = "identity", position = "fill") +
  scale_x_discrete(
    drop = FALSE,
    labels = as.roman(levels(ryc_dni_ch_opad_m$miesiac))
  ) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  # Zakres lat z danych ryciny (lata_ryc_26), a nie z parametrów: rok bez danych na
  # brzegu serii nie może stać w tytule panelu.
  ggtitle(paste0(litery_26[2], ": ", min(lata_ryc_26), "-", max(lata_ryc_26))) +
  scale_fill_manual(values = kolory_dni_charakterystyczne_opad) +
  labs(x = "",y = "") +
  plot_theme() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.text.x = element_text(size = 8))

# Oś X jest liczbowa, od pierwszego do ostatniego roku z danymi tej ryciny (lata_ryc_26
# z przetwarzanie_danych.R). Podziałka ma stać przy KAŻDYM roku zakresu, także tym
# bez pomiaru i tym, w którym nie odnotowano ani jednego dnia charakterystycznego
# (position = "fill" dzieli wtedy przez zero i słupka nie ma). Brak słupka przy
# widocznej podziałce jest informacją; rok znikający z osi - nie.
# Jawne limits utrzymują stały margines - skala ciągła rozszerzyłaby zakres
# o szerokość skrajnych słupków.
lata_os_x   = min(lata_ryc_26):max(lata_ryc_26)
zakres_os_x = range(lata_os_x) + c(-0.6, 0.6)

# Podpisy przerzedza krok_osi_lat (docelowo = 15, bo oś zajmuje całą szerokość
# ryciny), ale PODZIAŁKA zostaje przy każdym roku - rok bez pomiaru ma własną kreskę
# i jest widoczny także tam, gdzie nie wypadł na niego podpis. Siatki na tej rycinie
# nie ma (panel.grid.major wyłączona niżej), więc kreska osi jest jedynym znacznikiem.
krok_lat_26    = krok_osi_lat(length(lata_os_x), docelowo = 15)
podpisy_lat_26 = ifelse((seq_along(lata_os_x) - 1) %% krok_lat_26 == 0,
                        lata_os_x, "")

# Panel C: udziały w kolejnych latach. Tylko ten panel ma legendę - jest wspólna
# dla całej ryciny.
ryc_26C = ggplot(ryc_dni_ch_opad_r, aes(x = rok_hydro, y = wartosc, fill = kategoria)) +
  geom_bar(stat = "identity", position = "fill") +
  scale_x_continuous(breaks = lata_os_x, labels = podpisy_lat_26,
                     limits = zakres_os_x, expand = expansion(add = 0)) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  ggtitle(paste0(litery_26[3], ": lata ", min(lata_os_x), "-", max(lata_os_x))) +
  scale_fill_manual(
    name = "",
    values = kolory_dni_charakterystyczne_opad,
    labels = dni_charakterystyczne_opad_etykiety_mm
  ) +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE)) +
  labs(x = "",y = "",fill = "Klasyfikacja dni z opadem:") +
  plot_theme() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "bottom",
        legend.spacing.x = unit(1, "cm"),
        # Czcionka i wielkość symboli legendy jak na rycinie 24. Odstępy zostają
        # własne: plot_theme() zastępuje legend.text w całości, więc element ten
        # nie dziedziczy domyślnego marginesu i bez jawnej wartości etykiety
        # przedziałów nachodzą na kolejne próbki barwy.
        legend.text = element_text(size = 11, margin = margin(r = 20, l = 4, unit = "pt")),
        legend.title = element_text(size = 11, margin = margin(r = 20, unit = "pt")),
        legend.key.size = unit(0.35, "cm"))

# A i B obok siebie w górnym wierszu, C pod nimi i nieco wyższy. Bez panelu roku
# górny wiersz zajmuje sam panel miesięcy wielolecia.
gora_26 = if (ma_rok_26) plot_grid(ryc_26A, ryc_26B, ncol = 2) else ryc_26B
ryc_26 = plot_grid(gora_26, ryc_26C, nrow = 2,
                  rel_heights = c(1, 1.3))

rm(gora_26, litery_26)

ryc_26

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_26)).
if (!(any(ryc_dni_ch_opad_analizowany_rok$wartosc > 0, na.rm = TRUE) ||
    any(ryc_dni_ch_opad_m$wartosc > 0, na.rm = TRUE) ||
    any(ryc_dni_ch_opad_r$wartosc > 0, na.rm = TRUE))) ryc_26 <- NULL
