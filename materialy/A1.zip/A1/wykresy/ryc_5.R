################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 5
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Dobowe sumy usłonecznienia w Stacji Bazowej ZMŚP {nazwa_stacji} w
#   {analizowany_rok} roku"
#
# Uwagi do kodu:
# Podziałki osi X stoją w pierwszych dniach kolejnych miesięcy, policzonych z
# danych.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_dobowe_vw: pomiary dobowe roku analizowanego; dzien_roku
#     numeruje dni od 1 XI
# - miesiac_rzymski: funkcja: numer miesiąca zapisem rzymskim
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - ryc_5: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
# - ggplot2
################################################################################

# Podziałki osi X w pierwszych dniach kolejnych miesięcy, policzone z danych:
# miesiące mają różną długość, a rok hydrologiczny bywa przestępny.
osie_miesiecy = a1_dane_dobowe_vw |>
  group_by(miesiac) |>
  summarise(dzien_roku = min(dzien_roku), .groups = "drop") |>
  arrange(miesiac)

ryc_5 = ggplot(a1_dane_dobowe_vw, aes(x = dzien_roku, y = `SOL_P h`)) +
  geom_bar(stat = "identity", fill = "#E69F00", width = 1) +
  scale_x_continuous(breaks = osie_miesiecy$dzien_roku,
                     labels = miesiac_rzymski(osie_miesiecy$miesiac)) +
  scale_y_continuous(limits = c(0,ceiling(max(a1_dane_dobowe_vw$`SOL_P h`,na.rm = TRUE)/2) * 2)) +
  xlab("") +
  ylab("Usłonecznienie [h]") +
  plot_theme()

ryc_5

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_5)).
if (!(ma_dane(a1_dane_dobowe_vw$`SOL_P h`))) ryc_5 <- NULL
