################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 13
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Porównanie wartości wilgotności względnej powietrza w Stacji Bazowej ZMŚP
#   {nazwa_stacji} w {analizowany_rok} roku ze statystykami jej zmienności
#   obliczonymi dla każdego dnia roku w wieloleciu
#   {rok_poczatek}-{rok_koniec}"
#
# Uwagi do kodu:
# Podziałki osi X stoją w pierwszych dniach kolejnych miesięcy, policzonych z
# danych. Wstęgi pokazują zakres min-maks. oraz przedziały percentylowe 05-95
# i 25-75 wyznaczone z wielolecia dla każdego dnia roku. Oś Y jest ustalona na
# 0-100%.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_wieloletnie_dobowe_vw: statystyki wielolecia dla każdego dnia
#     roku (min, maks., percentyle) z doklejonym przebiegiem roku
#     analizowanego
# - analizowany_rok: parametr z parametry.xlsx: analizowany rok
#     hydrologiczny
# - kolory_linii_doy: kolory linii: rok analizowany, mediana, średnia
# - kolory_perc_doy: kolory wstęg: zakres min-maks. i przedziały
#     percentylowe
# - miesiac_rzymski: funkcja: numer miesiąca zapisem rzymskim
# - nazwy_linii_doy: nazwy linii w legendzie, budowane z analizowany_rok
#     w przetwarzanie_danych.R
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - ryc_13: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
# - ggplot2
################################################################################

# Zakres wyliczony, ale oś Y i tak jest ustalona na 0-100% - wilgotność względna
# z definicji nie wychodzi poza ten przedział.
wart_min = min(a1_dane_wieloletnie_dobowe_vw$`HH min`, na.rm = TRUE)
wart_max = max(a1_dane_wieloletnie_dobowe_vw$`HH max`, na.rm = TRUE)
lim_min = floor(wart_min / 10) * 10
lim_max = ceiling(wart_max / 10) * 10
lw = 0.6

# Podziałki osi X w pierwszych dniach kolejnych miesięcy, policzone z danych:
# miesiące mają różną długość, a rok hydrologiczny bywa przestępny.
osie_miesiecy = a1_dane_wieloletnie_dobowe_vw |>
  group_by(miesiac) |>
  summarise(dzien_roku = min(dzien_roku), .groups = "drop") |>
  arrange(miesiac)

# Wstęgi rysowane od najszerszej do najwęższej, żeby węższe pozostały widoczne.
# Na wierzchu mediana, średnia wielolecia i przebieg roku analizowanego.
ryc_13 = ggplot(a1_dane_wieloletnie_dobowe_vw, aes(dzien_roku)) +
  geom_ribbon(aes(ymin = `HH min`,
                  ymax = `HH max`,
                  fill = "Minimum-Maksimum"), alpha = 0.4) +
  geom_ribbon(aes(ymin = `HH p05`,
                  ymax = `HH p95`,
                  fill = "Percentyle: 05-95"), alpha = 0.8) +
  geom_ribbon(aes(ymin = `HH p25`,
                  ymax = `HH p75`,
                  fill = "Percentyle: 25-75"), alpha = 0.6) +
  geom_line(aes(y = `HH p50`,
                color = "Mediana"), linewidth = lw) +
  geom_line(aes(y = `HH avg`,
                color = "Średnia"), linewidth = lw) +
  geom_line(aes(y = HH,
                color = as.character(analizowany_rok)), linewidth = lw) +
  scale_color_manual(name = "",
                     values = setNames(kolory_linii_doy, nazwy_linii_doy)) +
  scale_fill_manual(name = "",
                    values = kolory_perc_doy) +
  scale_x_continuous(breaks = osie_miesiecy$dzien_roku,
                     labels = miesiac_rzymski(osie_miesiecy$miesiac)) +
  scale_y_continuous(limits = c(0, 100),
                     breaks = seq(from = 0, to = 100, by = 10),
                     expand = expansion(mult = c(0, 0))) +

  xlab("") +
  ylab(expression("Wilgotność względna [%]")) +
  guides(color = guide_legend(order = 1, nrow = 1),
         fill  = guide_legend(order = 2, nrow = 1)) +
  plot_theme() +
  theme(legend.box = "vertical", legend.spacing.y = unit(0.3, "cm"))

ryc_13

rm(wart_min, wart_max, lim_min, lim_max, lw)

# Rycina zestawia rok analizowany z tłem wielolecia, więc warunkiem jest obecność
# SERII ROKU ANALIZOWANEGO. Samo wielolecie nie wystarcza: wykres byłby wtedy
# w połowie pusty, a legenda zapowiadałaby rok, którego na nim nie ma.
# NULL sprawia, że qmd pomija chunk tej ryciny (eval = !is.null(ryc_13)).
if (!(ma_dane(a1_dane_wieloletnie_dobowe_vw$HH))) ryc_13 <- NULL
