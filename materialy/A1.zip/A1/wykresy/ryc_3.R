################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 3
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Przebieg dobowych wartości temperatury gruntu na głębokościach
#   {ryc_3_glebokosci_txt} cm w Stacji Bazowej ZMŚP {nazwa_stacji} w
#   {analizowany_rok} roku"
#
# Uwagi do kodu:
# Podziałki osi X stoją w pierwszych dniach kolejnych miesięcy, policzonych z
# danych. Głębokości bez pomiarów są pomijane w legendzie, a ich wykaz trafia
# do ryc_3_glebokosci_txt, którego używa podpis ryciny w raporcie.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_dobowe_vw: pomiary dobowe roku analizowanego; dzien_roku
#     numeruje dni od 1 XI
# - miesiac_rzymski: funkcja: numer miesiąca zapisem rzymskim
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - ryc_3: gotowa rycina (obiekt ggplot)
# - ryc_3_glebokosci: głębokości naniesione na wykres, bez jednostki
#     ("5", "20", "50") - materiał dla wykazu poniżej
# - ryc_3_glebokosci_txt: tekstowy wykaz głębokości naniesionych na
#     wykres, używany w podpisie ryciny w raporcie
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
# - ggplot2
################################################################################

# Zakres osi Y wspólny dla wszystkich głębokości.
wart_min = min(c(a1_dane_dobowe_vw$`T_S 5cm`, a1_dane_dobowe_vw$`T_S 10cm`, a1_dane_dobowe_vw$`T_S 20cm`, a1_dane_dobowe_vw$`T_S 50cm`), na.rm = TRUE)
wart_max = max(c(a1_dane_dobowe_vw$`T_S 5cm`, a1_dane_dobowe_vw$`T_S 10cm`, a1_dane_dobowe_vw$`T_S 20cm`, a1_dane_dobowe_vw$`T_S 50cm`), na.rm = TRUE)

lim_min = floor(wart_min / 5) * 5
lim_max = ceiling(wart_max / 5) * 5

lw = 0.6

# Głębokości, dla których są jakiekolwiek pomiary. Pozostałe wypadają z legendy
# (limits) i z podpisu ryciny.
glebokosci <- c("5cm", "10cm", "20cm", "50cm")[c(
  any(!is.na(a1_dane_dobowe_vw$`T_S 5cm`)),
  any(!is.na(a1_dane_dobowe_vw$`T_S 10cm`)),
  any(!is.na(a1_dane_dobowe_vw$`T_S 20cm`)),
  any(!is.na(a1_dane_dobowe_vw$`T_S 50cm`))
)]

# Podziałki osi X w pierwszych dniach kolejnych miesięcy, policzone z danych:
# miesiące mają różną długość, a rok hydrologiczny bywa przestępny.
osie_miesiecy = a1_dane_dobowe_vw |>
  group_by(miesiac) |>
  summarise(dzien_roku = min(dzien_roku), .groups = "drop") |>
  arrange(miesiac)

ryc_3 <- ggplot(data = a1_dane_dobowe_vw) +
  geom_line(aes(x = dzien_roku, y = `T_S 5cm`, color = "5cm"),  linewidth = lw) +
  geom_line(aes(x = dzien_roku, y = `T_S 10cm`, color = "10cm"), linewidth = lw) +
  geom_line(aes(x = dzien_roku, y = `T_S 20cm`, color = "20cm"), linewidth = lw) +
  geom_line(aes(x = dzien_roku, y = `T_S 50cm`, color = "50cm"), linewidth = lw) +
  scale_color_manual(
    name = "Głębokość",
    values = c(
      "5cm" = "#D73027",
      "10cm" = "#FC8D59",
      "20cm" = "#91BFDB",
      "50cm" = "#4575B4"
    ),
    breaks = glebokosci,
    limits = glebokosci,
    na.translate = FALSE
  ) +
  scale_x_continuous(breaks = osie_miesiecy$dzien_roku,
                     labels = miesiac_rzymski(osie_miesiecy$miesiac)) +

  scale_y_continuous(limits = c(lim_min, lim_max),
                     breaks = seq(from = -100, to = 100, by = 5)) +

  xlab("") +
  ylab(expression("Temperatura gruntu [°C]")) +
  plot_theme()

ryc_3

# Wykaz głębokości do podpisu ryciny w raporcie, w formie "5, 20 i 50".
ryc_3_glebokosci = sub("cm$", "", glebokosci)
ryc_3_glebokosci_txt = if (length(ryc_3_glebokosci) > 1) {
  paste0(paste(head(ryc_3_glebokosci, -1), collapse = ", "), " i ", tail(ryc_3_glebokosci, 1))
} else {
  ryc_3_glebokosci
}

rm(wart_min, wart_max, lim_min, lim_max, lw, glebokosci)

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_3)).
if (!(ma_dane(a1_dane_dobowe_vw$`T_S 5cm`, a1_dane_dobowe_vw$`T_S 10cm`,
            a1_dane_dobowe_vw$`T_S 20cm`, a1_dane_dobowe_vw$`T_S 50cm`))) ryc_3 <- NULL
