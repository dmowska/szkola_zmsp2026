################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 18
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Anomalie średniej rocznej temperatury powietrza w Stacji Bazowej ZMŚP
#   {nazwa_stacji} w wieloleciu {zakres_lat(lata_ryc_18)}"
#
# Uwagi do kodu:
# Kolor słupka rozróżnia anomalie dodatnie i ujemne.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_agg_vw_roczne: wartości roczne (wiersze RH) wszystkich lat
#     analizy
# - krok_osi_lat: funkcja: krok podpisów osi lat dobrany do długości serii
# - lata_ryc_18: lata, w których rycina ma dane - z nich powstają
#     podziałki osi X
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - ryc_18: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
################################################################################

# Zakres osi Y z faktycznych anomalii, zaokrąglony do pełnych stopni.
wart_min = min(a1_dane_agg_vw_roczne$TA_D_anomalie, na.rm = TRUE)
wart_max = max(a1_dane_agg_vw_roczne$TA_D_anomalie, na.rm = TRUE)
lim_min = floor(wart_min)
lim_max = ceiling(wart_max)

# Oś X jest liczbowa, od pierwszego do ostatniego roku z danymi tej ryciny (lata_ryc_18
# z przetwarzanie_danych.R). Podziałka i linia siatki stoją przy KAŻDYM roku zakresu,
# także tym, dla którego stacja nie ma pomiaru. Rok bez danych zostaje wtedy widoczny
# jako przerwa w serii przy własnej podziałce, zamiast wypadać z osi razem z nią.
# Jawne limits utrzymują stały margines - skala ciągła rozszerzyłaby zakres
# o szerokość skrajnych słupków.
lata_os_x   = min(lata_ryc_18):max(lata_ryc_18)
zakres_os_x = range(lata_os_x) + c(-0.6, 0.6)

# Podpisy przerzedza krok_osi_lat (docelowo = 15, bo oś zajmuje całą szerokość
# ryciny), ale PODZIAŁKA I SIATKA zostają przy każdym roku - rok bez pomiaru ma
# własną kreskę, więc luka w serii jest widoczna także tam, gdzie nie ma podpisu.
krok_lat_18    = krok_osi_lat(length(lata_os_x), docelowo = 15)
podpisy_lat_18 = ifelse((seq_along(lata_os_x) - 1) %% krok_lat_18 == 0,
                        lata_os_x, "")

# Kolor słupka wynika z warunku > 0. Punktem odniesienia anomalii jest średnia
# wielolecia bez roku analizowanego (liczona w przetwarzanie_danych.R).
ryc_18 = ggplot(a1_dane_agg_vw_roczne, aes(x = rok_hydro, y = TA_D_anomalie, fill = TA_D_anomalie > 0)) +
  geom_bar(stat = "identity", color = "black", linewidth = 0.2) +

  scale_x_continuous(breaks = lata_os_x, labels = podpisy_lat_18,
                     limits = zakres_os_x, expand = expansion(add = 0)) +

  scale_fill_manual(
    values = c("TRUE" = "#c65711", "FALSE" = "#2f75b5"),
    guide = "none"
  ) +
  scale_y_continuous(limits = c(lim_min, lim_max),
                     breaks = seq(from = -100, to = 100, by = 1)) +

  xlab("") +
  ylab("Anomalie temperatury powietrza [°C]") +
  plot_theme() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5))

ryc_18

rm(wart_min, wart_max, lim_min, lim_max)

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_18)).
if (!(ma_dane(a1_dane_agg_vw_roczne$TA_D_anomalie))) ryc_18 <- NULL
