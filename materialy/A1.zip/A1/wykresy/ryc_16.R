################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 16
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "(A) Sumy roczne opadów atmosferycznych (Pr) w Stacji Bazowej ZMŚP
#   {nazwa_stacji} w wieloleciu {zakres_lat(lata_ryc_16)}. Czerwona
#   przerywana linia wskazuje średnią sumę opadów obliczoną z wielolecia
#   {rok_poczatek}-{rok_koniec}. (B) Zmienność sum miesięcznych opadów
#   atmosferycznych (Pm) w Stacji Bazowej ZMŚP {nazwa_stacji} w wieloleciu
#   {zakres_lat(lata_ryc_16)}. Wykres pudełkowy przedstawia rozkład
#   statystyk podstawowych: 25. percentyla (podstawa pudełka), mediany (linia
#   wewnątrz pudełka) i 75. percentyla (górna część pudełka). Czarne punkty
#   oznaczają wartości większe niż 75. percentyl + 1,5*(75. percentyl - 25.
#   percentyl) oraz mniejsze niż 25. percentyl - 1,5*(75. percentyl - 25.
#   percentyl)"
#
# Uwagi do kodu:
# Oba panele mają jawnie ustawiony ten sam zakres osi X, żeby podziałki
# pokrywały się przy składaniu przez plot_grid(align = "v").
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_agg_vw_m: wartości miesięczne wszystkich lat analizy
# - a1_dane_agg_vw_roczne: wartości roczne (wiersze RH) wszystkich lat
#     analizy
# - krok_osi_lat: funkcja: krok podpisów osi lat dobrany do długości serii
# - lata_ryc_16: lata, w których rycina ma dane - z nich powstają
#     podziałki osi X
# - plot_theme: funkcja: wspólny motyw wykresów raportu
# - srednia_opad_wielolecia: średnia suma opadów wielolecia, bez roku
#     analizowanego
################################################################################
# WYNIK
################################################################################
# - ryc_16: gotowa rycina złożona z kilku paneli (obiekt cowplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - cowplot
# - ggplot2
################################################################################

# Oś X jest liczbowa, od pierwszego do ostatniego roku z danymi tej ryciny (lata_ryc_16
# z przetwarzanie_danych.R). Podziałka i linia siatki stoją przy KAŻDYM roku zakresu,
# także tym, dla którego stacja nie ma pomiaru. Rok bez danych zostaje wtedy widoczny
# jako przerwa w serii przy własnej podziałce, zamiast wypadać z osi razem z nią.
# Jawne limits utrzymują stały margines - skala ciągła rozszerzyłaby zakres
# o szerokość skrajnych słupków.
# Oba panele mają ten sam zakres i te same podziałki, żeby pokrywały się po złożeniu.
lata_os_x   = min(lata_ryc_16):max(lata_ryc_16)
zakres_os_x = range(lata_os_x) + c(-0.6, 0.6)

# Podpisy przerzedza krok_osi_lat (docelowo = 15, bo oś zajmuje całą szerokość
# ryciny), ale PODZIAŁKA I SIATKA zostają przy każdym roku - rok bez pomiaru ma
# własną kreskę, więc luka w serii jest widoczna także tam, gdzie nie ma podpisu.
krok_lat_16    = krok_osi_lat(length(lata_os_x), docelowo = 15)
podpisy_lat_16 = ifelse((seq_along(lata_os_x) - 1) %% krok_lat_16 == 0,
                        lata_os_x, "")

# Panel A: roczne sumy opadu i średnia wielolecia.
panelA = ggplot(a1_dane_agg_vw_roczne, aes(x = rok_hydro,y = `RR_T sum`)) +
  geom_bar(stat = "identity", fill = "#2f75b5") +
  geom_hline(yintercept = srednia_opad_wielolecia, linewidth = 1, color = "red", linetype = "dashed") +
  xlab("") +
  ylab(expression(paste("P"[r], " [mm]"))) +
  scale_x_continuous(breaks = lata_os_x, labels = podpisy_lat_16,
                     limits = zakres_os_x, expand = expansion(add = 0)) +
  scale_y_continuous(limits = c(0,ceiling(max(a1_dane_agg_vw_roczne$`RR_T sum`, na.rm = TRUE)/10) * 10)) +
  plot_theme() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5),
        plot.margin = margin(r = 5, l = 15, t = 5))

# Panel B: rozkład sum miesięcznych w każdym roku. group = rok_hydro daje
# jeden boxplot na rok - bez tego skala ciągła zlałaby wszystkie lata w jeden.
panelB = ggplot(a1_dane_agg_vw_m, aes(x = rok_hydro, y = `RR_T sum`, group = rok_hydro)) +
  geom_boxplot() +
  geom_hline(yintercept = srednia_opad_wielolecia, linewidth = 1, color = "red", linetype = "dashed") +
  xlab("") +
  ylab(expression(paste("P"[m], " [mm]"))) +
  scale_x_continuous(breaks = lata_os_x, labels = podpisy_lat_16,
                     limits = zakres_os_x, expand = expansion(add = 0)) +
  scale_y_continuous(limits = c(0,ceiling(max(a1_dane_agg_vw_m$`RR_T sum`, na.rm = TRUE)/10) * 10)) +
  plot_theme() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5),
        plot.margin = margin(r = 5, l = 15))

# Panele jeden pod drugim, ze wspólną osią X.
ryc_16 = plot_grid(panelA, panelB, nrow = 2, labels = "AUTO", align = "v")

ryc_16

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_16)).
if (!(ma_dane(a1_dane_agg_vw_roczne$`RR_T sum`, a1_dane_agg_vw_m$`RR_T sum`))) ryc_16 <- NULL
