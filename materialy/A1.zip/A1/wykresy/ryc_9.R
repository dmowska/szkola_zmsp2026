################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 9
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Miesięczne sumy usłonecznienia w Stacji Bazowej ZMŚP {nazwa_stacji} w
#   {analizowany_rok} roku na tle okresu {rok_poczatek}-{rok_koniec}"
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - analizowany_rok: parametr z parametry.xlsx: analizowany rok
#     hydrologiczny
# - dane_uslonecznienie: miesięczne sumy usłonecznienia w postaci długiej:
#     rok analizowany i średnia wielolecia rozdzielone kolumną Okres
# - plot_theme: funkcja: wspólny motyw wykresów raportu
# - rok_koniec: parametr z parametry.xlsx: ostatni rok wielolecia
# - rok_poczatek: parametr z parametry.xlsx: pierwszy rok wielolecia
################################################################################
# WYNIK
################################################################################
# - ryc_9: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
################################################################################

# Dwa szeregi obok siebie (position_dodge): rok analizowany i średnia wielolecia.
# Etykiety legendy są budowane z parametrów, więc zawsze podają właściwe lata.
ryc_9 <- ggplot(dane_uslonecznienie, aes(x = miesiac, y = Uslonecznienie, fill = Okres)) +

  geom_col(position = position_dodge(0.8), width = 0.7, color = "black", linewidth = 0.2) +

  scale_fill_manual(
    name = NULL,
    # Wielolecie na ciemnobrązowo, a nie szaro: szary czyta się na wykresach jako
    # brak danych, a to jest pełnoprawny szereg. Ciemny brąz zostaje wyraźnie
    # ciemniejszy od pomarańczowego słupka roku analizowanego również na wydruku
    # czarno-białym.
    values = c("rok" = "#E69F00", "wielolecie" = "#663300"),
    labels = c(
      "wielolecie" = paste0("Średnia ", rok_poczatek, "-", rok_koniec),
      "rok"   = paste0(analizowany_rok)
    )
  ) +

  # drop = FALSE zostawia na osi wszystkie miesiące roku hydrologicznego, także
  # te bez pomiaru: miesiąc bez danych ma być widoczny jako brak słupka przy
  # podpisanej podziałce, a nie znikać z osi razem z podpisem.
  scale_x_discrete(drop = FALSE, expand = c(0.02, 0),
                   labels = as.roman(levels(dane_uslonecznienie$miesiac))) +

  scale_y_continuous(expand = expansion(mult = c(0, 0.05)), n.breaks = 8) +

  xlab("") +
  ylab("Usłonecznienie [h]") +

 plot_theme()

ryc_9

# Rycina zestawia rok analizowany z tłem wielolecia, więc warunkiem jest obecność
# SERII ROKU ANALIZOWANEGO. Samo wielolecie nie wystarcza: wykres byłby wtedy
# w połowie pusty, a legenda zapowiadałaby rok, którego na nim nie ma.
# NULL sprawia, że qmd pomija chunk tej ryciny (eval = !is.null(ryc_9)).
if (!(ma_dane(dane_uslonecznienie$Uslonecznienie[dane_uslonecznienie$Okres == "rok"]))) ryc_9 <- NULL
