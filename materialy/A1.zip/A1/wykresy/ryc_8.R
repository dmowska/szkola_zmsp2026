################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 8
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Odchylenia miesięcznych sum opadów w Stacji Bazowej ZMŚP {nazwa_stacji} w
#   {analizowany_rok} roku od średniej wieloletniej
#   {rok_poczatek}-{rok_koniec}"
#
# Uwagi do kodu:
# Kolor słupka rozróżnia odchylenia dodatnie i ujemne.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_agg_vw_rok: wartości miesięczne roku analizowanego wraz z
#     odchyleniami od średnich wielolecia
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - ryc_8: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
################################################################################

# Zakres osi Y z faktycznych odchyleń, zaokrąglony do pełnych dziesiątek mm.
# min_lub/max_lub: rok bez danych miesięcznych daje same braki, a min()/max() zwróciłyby
# wtedy Inf z ostrzeżeniem - rycina i tak zostanie na końcu zastąpiona przez NULL.
wart_min = min_lub(a1_dane_agg_vw_rok$RR_T_roznica, 0)
wart_max = max_lub(a1_dane_agg_vw_rok$RR_T_roznica, 1)
lim_min = floor(wart_min / 10) * 10
lim_max = ceiling(wart_max / 10) * 10

# Kolor słupka wynika z warunku > 0, więc legenda nic nie wnosi (guide = "none").
ryc_8 = ggplot(a1_dane_agg_vw_rok, aes(x = miesiac, y = RR_T_roznica, fill = RR_T_roznica > 0)) +
  geom_bar(stat = "identity", color = "black", linewidth = 0.2) +

  scale_fill_manual(
    values = c("TRUE" = "#c65711", "FALSE" = "#2f75b5"),
    guide = "none"
  ) +
  # drop = FALSE zostawia na osi wszystkie miesiące roku hydrologicznego, także
  # te bez pomiaru: miesiąc bez danych ma być widoczny jako brak słupka przy
  # podpisanej podziałce, a nie znikać z osi razem z podpisem.
  scale_x_discrete(
    drop = FALSE,
    labels = as.roman(levels(a1_dane_agg_vw_rok$miesiac))
  ) +
  scale_y_continuous(limits = c(lim_min, lim_max),
                     breaks = pretty(c(lim_min, lim_max), n = 8)) +

  xlab("") +
  ylab("Odchylenie sumy opadów [mm]") +
  plot_theme()

ryc_8

rm(wart_min, wart_max, lim_min, lim_max)

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_8)).
if (!(ma_dane(a1_dane_agg_vw_rok$RR_T_roznica))) ryc_8 <- NULL
