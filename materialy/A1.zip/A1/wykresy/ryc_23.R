################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 23
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Liczba dni charakterystycznych ze względu na opady atmosferyczne w Stacji
#   Bazowej ZMŚP {nazwa_stacji} w {analizowany_rok} roku"
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dni_charakterystyczne_opad_etykiety_mm: etykiety legendy: przedziały
#     opadu w mm
# - kolory_dni_charakterystyczne_opad: paleta kolorów kategorii dni
#     charakterystycznych opadu
# - miesiace_hydro: miesiące w porządku roku hydrologicznego (11, 12,
#     1:10)
# - plot_theme: funkcja: wspólny motyw wykresów raportu
# - ryc_dni_ch_opad_analizowany_rok: liczba dni charakterystycznych opadu
#     w miesiącach roku analizowanego (postać długa)
################################################################################
# WYNIK
################################################################################
# - ryc_23: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
################################################################################

# Słupki kategorii obok siebie w każdym miesiącu (position_dodge); legenda opisana
# przedziałami wysokości opadu w mm.
ryc_23 <- ggplot(ryc_dni_ch_opad_analizowany_rok, aes(x = miesiac, y = wartosc, fill = kategoria)) +

  geom_col(position = position_dodge(width = 0.8), width = 0.7, color = "black", linewidth = 0.2) +

  scale_fill_manual(
    name = "",
    values = kolory_dni_charakterystyczne_opad,
    labels = dni_charakterystyczne_opad_etykiety_mm
  ) +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE)) +
  # drop = FALSE zostawia na osi wszystkie miesiące roku hydrologicznego, także
  # te bez pomiaru: miesiąc bez danych ma być widoczny jako brak słupków przy
  # podpisanej podziałce, a nie znikać z osi razem z podpisem.
  scale_x_discrete(drop = FALSE, labels = as.roman(miesiace_hydro)) +
  scale_y_continuous(
    expand = expansion(mult = c(0, 0.1)),
    breaks = seq(0, 31, by = 2)
  ) +

  xlab("") +
  ylab("Liczba dni") +

plot_theme() +
  # Czcionka i wielkość symboli legendy jak na rycinie 24.
  theme(legend.text = element_text(size = 11, margin = margin(r = 6, l = 2, unit = "pt")),
        legend.key.size = unit(0.35, "cm"))

ryc_23

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_23)).
if (!(any(ryc_dni_ch_opad_analizowany_rok$wartosc > 0, na.rm = TRUE))) ryc_23 <- NULL
