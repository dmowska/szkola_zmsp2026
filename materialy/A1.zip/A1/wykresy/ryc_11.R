################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 11
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Porównanie wartości minimalnej dobowej temperatury powietrza w Stacji
#   Bazowej ZMŚP {nazwa_stacji} w {analizowany_rok} roku ze statystykami jej
#   zmienności obliczonymi dla każdego dnia roku w wieloleciu
#   {rok_poczatek}-{rok_koniec}"
#
# Uwagi do kodu:
# Podziałki osi X stoją w pierwszych dniach kolejnych miesięcy, policzonych z
# danych. Wstęgi pokazują zakres min-maks. oraz przedziały percentylowe 05-95
# i 25-75 wyznaczone z wielolecia dla każdego dnia roku.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_wieloletnie_dobowe_vw: statystyki wielolecia dla każdego dnia
#     roku (min, maks., percentyle) z doklejonym przebiegiem roku
#     analizowanego
# - analizowany_rok: parametr z parametry.xlsx: analizowany rok
#     hydrologiczny
# - kolory_linii_doy: kolory linii: rok analizowany, mediana, średnia
# - kolory_perc_doy: kolory wstęg: zakres min-maks. i przedziały
#     percentylowe
# - miesiac_rzymski: funkcja: numer miesiąca zapisem rzymskim
# - nazwy_linii_doy: nazwy linii w legendzie, budowane z analizowany_rok
#     w przetwarzanie_danych.R
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - ryc_11: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
# - ggplot2
################################################################################

# Zakres osi Y obejmuje skrajne wartości wielolecia, nie tylko rok analizowany.
wart_min = min(a1_dane_wieloletnie_dobowe_vw$`TA_N min`, na.rm = TRUE)
wart_max = max(a1_dane_wieloletnie_dobowe_vw$`TA_N max`, na.rm = TRUE)
lim_min = floor(wart_min / 5) * 5
lim_max = ceiling(wart_max / 5) * 5
lw = 0.6

# Podziałki osi X w pierwszych dniach kolejnych miesięcy, policzone z danych:
# miesiące mają różną długość, a rok hydrologiczny bywa przestępny.
osie_miesiecy = a1_dane_wieloletnie_dobowe_vw |>
  group_by(miesiac) |>
  summarise(dzien_roku = min(dzien_roku), .groups = "drop") |>
  arrange(miesiac)

# Wstęgi rysowane od najszerszej do najwęższej, żeby węższe pozostały widoczne.
# Na wierzchu mediana, średnia wielolecia i przebieg roku analizowanego.
ryc_11 = ggplot(a1_dane_wieloletnie_dobowe_vw, aes(dzien_roku)) +
  geom_ribbon(aes(ymin = `TA_N min`,
                  ymax = `TA_N max`,
                  fill = "Minimum-Maksimum"), alpha = 0.4) +
  geom_ribbon(aes(ymin = `TA_N p05`,
                  ymax = `TA_N p95`,
                  fill = "Percentyle: 05-95"), alpha = 0.8) +
  geom_ribbon(aes(ymin = `TA_N p25`,
                  ymax = `TA_N p75`,
                  fill = "Percentyle: 25-75"), alpha = 0.6) +
  geom_line(aes(y = `TA_N p50`,
                color = "Mediana"), linewidth = lw) +
  geom_line(aes(y = `TA_N avg`,
                color = "Średnia"), linewidth = lw) +
  geom_line(aes(y = TA_N,
                color = as.character(analizowany_rok)), linewidth = lw) +
  scale_color_manual(name = "",
                     values = setNames(kolory_linii_doy, nazwy_linii_doy)) +
  scale_fill_manual(name = "",
                    values = kolory_perc_doy) +
  scale_x_continuous(breaks = osie_miesiecy$dzien_roku,
                     labels = miesiac_rzymski(osie_miesiecy$miesiac)) +
  scale_y_continuous(limits = c(lim_min, lim_max),
                     breaks = seq(from = -100, to = 100, by = 5)) +

  xlab("") +
  ylab(expression("Temperatura powietrza [°C]")) +
  guides(color = guide_legend(order = 1, nrow = 1),
         fill  = guide_legend(order = 2, nrow = 1)) +
  plot_theme() +
  theme(legend.box = "vertical", legend.spacing.y = unit(0.3, "cm"))

ryc_11

rm(wart_min, wart_max, lim_min, lim_max, lw)

# Rycina zestawia rok analizowany z tłem wielolecia, więc warunkiem jest obecność
# SERII ROKU ANALIZOWANEGO. Samo wielolecie nie wystarcza: wykres byłby wtedy
# w połowie pusty, a legenda zapowiadałaby rok, którego na nim nie ma.
# NULL sprawia, że qmd pomija chunk tej ryciny (eval = !is.null(ryc_11)).
if (!(ma_dane(a1_dane_wieloletnie_dobowe_vw$TA_N))) ryc_11 <- NULL
