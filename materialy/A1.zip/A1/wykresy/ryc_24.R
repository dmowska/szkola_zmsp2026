################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 24
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Rozkład dni charakterystycznych pod względem temperatury (A) oraz opadu
#   atmosferycznego (B) w Stacji Bazowej ZMŚP {nazwa_stacji} w
#   {analizowany_rok} roku. Kryteria wyznaczenia dni charakterystycznych
#   przedstawionych na panelu A znajdują się w tabeli 8"
#
# Uwagi do kodu:
# Dni bez przypisanej kategorii zostają szare i nie trafiają do legendy.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_dobowe_vw: pomiary dobowe roku analizowanego; dzien_roku
#     numeruje dni od 1 XI
# - dni_charakterystyczne_opad_etykiety_mm: etykiety legendy: przedziały
#     opadu w mm
# - dni_charakterystyczne_temp_etykiety: etykiety legendy dla kategorii
#     temperatury
# - kolory_dni_charakterystyczne_opad: paleta kolorów kategorii dni
#     charakterystycznych opadu
# - kolory_dni_charakterystyczne_temp: paleta kolorów kategorii dni
#     charakterystycznych temperatury
# - miesiace_hydro: miesiące w porządku roku hydrologicznego (11, 12,
#     1:10)
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - ryc_24: gotowa rycina złożona z kilku paneli (obiekt cowplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - cowplot
# - ggplot2
################################################################################

# Panel A: mapa dzień x miesiąc z kategorią termiczną każdego dnia.
# na.translate = FALSE trzyma dni bez kategorii poza legendą, a na.value maluje je
# na szaro. Siatkę rysujemy ręcznie, dokładnie na stykach kafelków.
a = ggplot(a1_dane_dobowe_vw, aes(x = dzien, y = miesiac, fill = dch_temp)) +
  geom_tile() +
  geom_vline(xintercept = seq(0.5, 31.5, 1), colour = "grey85", linewidth = 0.5) +
  geom_hline(yintercept = seq(0.5, length(miesiace_hydro) + 0.5, 1), colour = "grey85", linewidth = 0.5) +
  labs(x = "Dzień", y = "") +
  scale_fill_manual(
    values = kolory_dni_charakterystyczne_temp,
    labels = dni_charakterystyczne_temp_etykiety,
    na.value = "grey90",
    na.translate = FALSE,
    name = ""
  ) +
  scale_x_continuous(
    breaks = seq(1, 31, 1),
    expand = c(0, 0)
  ) +
  # drop = FALSE zostawia na osi wszystkie miesiące roku hydrologicznego, także
  # te bez pomiaru: miesiąc bez danych ma być widoczny jako pusty pas przy
  # podpisanej podziałce, a nie znikać z osi razem z podpisem.
  scale_y_discrete(
    drop = FALSE,
    labels = as.roman(miesiace_hydro),
    expand = c(0, 0)
  ) +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE)) +
  plot_theme() +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),

    axis.text = element_text(size = 11),
    axis.title = element_text(size = 11),
    axis.title.y = element_text(size = 11, angle = 90, margin = margin(r = 4)),
    legend.text = element_text(size = 11, margin = margin(r = 6, l = 2, unit = "pt")),
    legend.key.size = unit(0.35, "cm"),
    legend.position = "bottom",
    legend.margin = margin(t = 2),
    legend.box.spacing = unit(4, "pt"),
    plot.margin = margin(b = 10, t = 5, l = 5, r = 5)
  )

# Legenda panelu B: przedziały w mm plus osobna pozycja dla dni bez opadu.
etykiety_b = c(dni_charakterystyczne_opad_etykiety_mm, "brak opadu")

# Panel B: to samo dla kategorii opadowej.
b = ggplot(a1_dane_dobowe_vw, aes(x = dzien, y = miesiac, fill = dch_opad)) +
  geom_tile() +
  geom_vline(xintercept = seq(0.5, 31.5, 1), colour = "grey85", linewidth = 0.5) +
  geom_hline(yintercept = seq(0.5, length(miesiace_hydro) + 0.5, 1), colour = "grey85", linewidth = 0.5) +
  labs(x = "Dzień", y = "") +
  scale_fill_manual(
    values = c(kolory_dni_charakterystyczne_opad, "brak opadu" = "grey90", na.value = "grey90"),
    labels = etykiety_b,
    na.translate = FALSE,
    name = ""
  ) +
  scale_x_continuous(
    breaks = seq(1, 31, 1),
    expand = c(0, 0)
  ) +
  # drop = FALSE zostawia na osi wszystkie miesiące roku hydrologicznego, także
  # te bez pomiaru: miesiąc bez danych ma być widoczny jako pusty pas przy
  # podpisanej podziałce, a nie znikać z osi razem z podpisem.
  scale_y_discrete(
    drop = FALSE,
    labels = as.roman(miesiace_hydro),
    expand = c(0, 0)
  ) +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE)) +
  plot_theme() +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),

    axis.text = element_text(size = 11),
    axis.title = element_text(size = 11),
    axis.title.y = element_text(size = 11, angle = 90, margin = margin(r = 4)),
    legend.text = element_text(size = 11, margin = margin(r = 6, l = 2, unit = "pt")),
    legend.key.size = unit(0.35, "cm"),
    legend.position = "bottom",
    legend.margin = margin(t = 2),
    legend.box.spacing = unit(4, "pt"),
    plot.margin = margin(b = 10, t = 5, l = 5, r = 5)
  )

# Panele jeden pod drugim, z wyrównaniem obu osi (align = "hv").
ryc_24 = plot_grid(a, b, nrow = 2, labels = "AUTO",
                   align = "hv", axis = "tblr")

ryc_24

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_24)).
if (!(ma_dane(a1_dane_dobowe_vw$dch_temp, a1_dane_dobowe_vw$dch_opad))) ryc_24 <- NULL
