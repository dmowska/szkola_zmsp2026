################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 30
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Kompletność serii danych dla elementów meteorologicznych w Stacji Bazowej
#   ZMŚP {nazwa_stacji} w ujęciu miesięcznym w wieloleciu
#   {zakres_lat(lata_ryc_30)} (pozostałe elementy)"
#
# Uwagi do kodu:
# Druga część ryciny 29: te same dane i ten sam sposób rysowania, tylko elementy
# INNE niż temperaturowe (wilgotność, opad, śnieg, wiatr, usłonecznienie,
# promieniowanie, ciśnienie). Podział wynika z czytelności - patrz ryc_29.R.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - kolory_kompletnosc: paleta klas kompletności
# - kompletnosc_temperatura: elementy temperaturowe - te są POMIJANE na tej
#     rycinie, pokazuje je rycina 29
# - krok_osi_lat: funkcja: krok podpisów osi lat dobrany do długości serii
# - lata_ryc_30: lata, w których rycina ma dane - z nich powstaje zakres osi X
# - miesiace_hydro: miesiące w porządku roku hydrologicznego (11, 12,
#     1:10)
# - plot_theme: funkcja: wspólny motyw wykresów raportu
# - ryc_kompletnosc: kompletność każdego elementu w kolejnych miesiącach
#     i latach, wraz z klasą kompletności (postać długa)
################################################################################
# WYNIK
################################################################################
# - dane_ryc_30: kompletność pozostałych elementów, bez tych, których stacja
#     nie mierzy w ogóle; z poziomów jej kolumny parametr powstaje blok
#     objaśnień pod ryciną w tworzenie_raportu.qmd
# - ryc_30: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
# - forcats
# - ggplot2
################################################################################

# Element, którego stacja nie mierzy W OGÓLE, nie dostaje własnej fasety - tak samo
# jak na rycinie 29.
dane_ryc_30 <- ryc_kompletnosc |>
  filter(!(parametr %in% kompletnosc_temperatura)) |>
  group_by(parametr) |>
  filter(!all(is.na(kompletnosc))) |>
  ungroup() |>
  mutate(parametr = fct_drop(parametr))

# Zakres osi X: od pierwszego do ostatniego roku z danymi tej ryciny (lata_ryc_30
# z przetwarzanie_danych.R), a nie całe wielolecie z parametrów. Krok podpisów
# dobrany do długości tej serii - jak na rycinach 27 i 28.
rok_od_30 <- min(lata_ryc_30)
rok_do_30 <- max(lata_ryc_30)
krok_lat_30 <- krok_osi_lat(rok_do_30 - rok_od_30 + 1)

# Siatkę rysujemy ręcznie, na stykach kafelków, bo domyślna trafiałaby w ich środki.
ryc_30 = ggplot(dane_ryc_30, aes(x = rok_hydro, y = miesiac, fill = klasa)) +
  geom_tile() +

  geom_vline(xintercept = seq(rok_od_30 - 0.5, rok_do_30 + 0.5, by = 1), color = "lightgrey", linewidth = 0.2) +
  geom_hline(yintercept = seq(0.5, length(miesiace_hydro) + 0.5, by = 1), color = "lightgrey", linewidth = 0.2) +

  # Pasek fasety niesie sam symbol elementu; jego rozwinięcie podaje blok objaśnień
  # pod ryciną, składany z tego samego słownika opisy_elementow. Pełne nazwy nie
  # mieszczą się na pasku panelu, a skracane na potrzeby ryciny rozjeżdżałyby się
  # z opisami spod tabel.
  facet_wrap(~parametr, ncol = 3) +

  scale_fill_manual(name = "Kompletność serii", values = kolory_kompletnosc) +

  scale_x_continuous(
    breaks = seq(rok_od_30, rok_do_30, krok_lat_30)
  ) +

  # drop = FALSE zostawia na osi wszystkie miesiące roku hydrologicznego, także
  # te bez pomiaru - inaczej miesiąc bez danych znika z osi razem z podpisem.
  scale_y_discrete(drop = FALSE, labels = as.roman(miesiace_hydro)) +

  labs(x = "", y = "") +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE)) +
  plot_theme() +
  theme(
    strip.text = element_text(size = 9, color = "black", face = "bold.italic"),
    strip.background = element_rect(color = "darkgrey", fill = "white"),
    axis.text.x = element_text(angle = 90, hjust = 1, size = 8),
    axis.text.y = element_text(size = 8),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position = "bottom",
    legend.text = element_text(size = 10, margin = margin(r = 12, l = 3, unit = "pt")),
    legend.title = element_text(size = 10),
    legend.key.size = unit(0.35, "cm")
  )

ryc_30

# Stacja mierząca wyłącznie temperaturę dałaby tu pustą ramkę z podpisem. NULL
# sprawia, że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_30)).
if (nrow(dane_ryc_30) == 0) ryc_30 <- NULL
