################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 4
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Dobowe sumy opadów atmosferycznych (A) oraz grubość pokrywy śnieżnej (B)
#   w Stacji Bazowej ZMŚP {nazwa_stacji} w {analizowany_rok} roku"
#
# Uwagi do kodu:
# Podziałki osi X stoją w pierwszych dniach kolejnych miesięcy, policzonych z
# danych. Każdy panel ma własną skalę Y, bo opad jest w mm, a pokrywa śnieżna
# w cm.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_dobowe_vw: pomiary dobowe roku analizowanego; dzien_roku
#     numeruje dni od 1 XI
# - miesiac_rzymski: funkcja: numer miesiąca zapisem rzymskim
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - ryc_4: gotowa rycina złożona z kilku paneli (obiekt cowplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - cowplot
# - dplyr
# - ggplot2
################################################################################

lim_min = 0

# Górna granica panelu A liczona z samego opadu - pokrywa śnieżna jest w cm
# i ma własną skalę w panelu B.
lim_max = ceiling(max(a1_dane_dobowe_vw$RR_T, na.rm = TRUE)/5) * 5

# Podziałki osi X w pierwszych dniach kolejnych miesięcy, policzone z danych:
# miesiące mają różną długość, a rok hydrologiczny bywa przestępny.
osie_miesiecy = a1_dane_dobowe_vw |>
  group_by(miesiac) |>
  summarise(dzien_roku = min(dzien_roku), .groups = "drop") |>
  arrange(miesiac)

# Panel A: dobowe sumy opadu.
ryc_4A = ggplot(a1_dane_dobowe_vw, aes(x = dzien_roku, y = RR_T)) +
  geom_bar(stat = "identity", fill = "#2f75b5", width = 1) +
  scale_x_continuous(breaks = osie_miesiecy$dzien_roku,
                     labels = miesiac_rzymski(osie_miesiecy$miesiac)) +
  scale_y_continuous(limits = c(lim_min, lim_max)) +
  xlab("") +
  ylab("Opad atmosferyczny [mm]") +
  plot_theme()

# Panel B: grubość pokrywy śnieżnej.
ryc_4B = ggplot(a1_dane_dobowe_vw, aes(x = dzien_roku, y = SC_H)) +
  geom_bar(stat = "identity", fill = "lightblue", width = 1) +
  scale_x_continuous(breaks = osie_miesiecy$dzien_roku,
                     labels = miesiac_rzymski(osie_miesiecy$miesiac)) +
  scale_y_continuous(limits = c(0,ceiling(max(a1_dane_dobowe_vw$SC_H, na.rm = TRUE)/5) * 5)) +
  xlab("") +
  ylab("Pokrywa śnieżna [cm]") +
  plot_theme()

rm(lim_min, lim_max)

# Panele jeden pod drugim, z wyrównanymi osiami pionowymi.
# Etykiety A i B stoją po LEWEJ i NAD panelem: górny margines paneli (t = 14) robi
# im miejsce poza obszarem rysowania, więc nie nachodzą na słupki, a przesunięcie
# o 0,09 szerokości (label_x) omija pionowy opis osi Y - przy label_x = 0 etykieta A
# wylądowałaby na napisie "Opad atmosferyczny [mm]".
ryc_4A = ryc_4A + theme(plot.margin = margin(t = 14, r = 5, b = 5, l = 5))
ryc_4B = ryc_4B + theme(plot.margin = margin(t = 14, r = 5, b = 5, l = 5))

ryc_4 = plot_grid(ryc_4A, ryc_4B, nrow = 2, labels = "AUTO",
                  label_x = 0.09, label_y = 1, hjust = 0, vjust = 1,
                  align = "v", axis = "lr")

ryc_4

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_4)).
if (!(ma_dane(a1_dane_dobowe_vw$RR_T, a1_dane_dobowe_vw$SC_H))) ryc_4 <- NULL
