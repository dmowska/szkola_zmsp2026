################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 21
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Klasyfikacja termiczna (A) i opadowa (B) lat hydrologicznych w Stacji Bazowej
#   ZMŚP {nazwa_stacji} w okresie {zakres_lat(lata_ryc_21)} na tle okresu
#   referencyjnego {okres_referencyjny}, wyznaczonego na podstawie danych
#   {zrodlo_okresu_ref}"
#
# Uwagi do kodu:
# Legendy są wyjmowane z paneli i układane jako osobne wiersze siatki -
# inaczej pasek z liczniejszą legendą robiłby się niższy od drugiego.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - klasyfikacja_temp_opad: klasa termiczna i opadowa każdego roku
#     hydrologicznego
# - kolory_klasyfikacja_opadowa: paleta kolorów klas opadowych
# - kolory_klasyfikacja_termiczna: paleta kolorów klas termicznych
# - krok_osi_lat: funkcja: krok podpisów osi lat dobrany do długości serii
# - lata_ryc_21: lata, w których rycina ma dane - z nich powstają
#     podziałki osi X
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - dane_ryc_21: klasyfikacja uzupełniona o lata bez pomiaru i o jawną
#     kategorię "brak danych"
# - ryc_21: gotowa rycina złożona z kilku paneli (obiekt cowplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - cowplot
# - forcats
# - ggplot2
# - tidyr
################################################################################

# Oś X jest liczbowa, od pierwszego do ostatniego roku z danymi tej ryciny (lata_ryc_21
# z przetwarzanie_danych.R). Podziałka ma stać przy KAŻDYM roku zakresu, także tym,
# dla którego stacja nie ma pomiaru - inaczej rok bez klasyfikacji znika z osi i pasek
# czyta się tak, jakby lat było mniej. Margines 0,5 roku to połowa szerokości kafelka,
# więc skrajne kafelki dotykają krawędzi panelu.
lata_os_x   = min(lata_ryc_21):max(lata_ryc_21)
zakres_os_x = range(lata_os_x) + c(-0.5, 0.5)

# Podpisy przerzedza krok_osi_lat (docelowo = 15, bo oś zajmuje całą szerokość
# ryciny), ale PODZIAŁKA zostaje przy każdym roku - rok bez pomiaru ma własną kreskę
# i jest widoczny także tam, gdzie nie wypadł na niego podpis. Siatki na tej rycinie
# nie ma (panel.grid.major wyłączona niżej), więc kreska osi jest jedynym znacznikiem.
krok_lat_21    = krok_osi_lat(length(lata_os_x), docelowo = 15)
podpisy_lat_21 = ifelse((seq_along(lata_os_x) - 1) %% krok_lat_21 == 0,
                        lata_os_x, "")

# Lata bez klasyfikacji dostają jawną kategorię "brak danych" zamiast NA. Bez
# tego rok bez danych zniknąłby z paska bez śladu (biała przerwa nie do odróżnienia
# od tła), a ggplot opisałby go w legendzie jako "NA". Jasnoszare wypełnienie
# odróżnia brak danych od klasy normalnej, a kafelek zostaje na swoim miejscu,
# więc oś X nadal zgadza się z latami.
BRAK_DANYCH = "brak danych"
kolory_21_termiczna = c(kolory_klasyfikacja_termiczna, setNames("#e6e6e6", BRAK_DANYCH))
kolory_21_opadowa   = c(kolory_klasyfikacja_opadowa,   setNames("#e6e6e6", BRAK_DANYCH))

# Kopia robocza - klasyfikacja_temp_opad trafia do dane_all.RData i nie powinna
# nieść kategorii dorobionej na potrzeby jednej ryciny.
# complete() dokłada wiersze za lata, których w klasyfikacji nie ma w ogóle.
# Bez nich rok bez pomiaru nie dostałby żadnego kafelka i zostałby biały - nie do
# odróżnienia od tła, więc pasek wyglądałby na przerwany. Z wierszem (o wartości NA)
# przechodzi niżej przez tę samą ścieżkę co rok z pustą klasyfikacją i dostaje
# szary kafelek "brak danych".
dane_ryc_21 = klasyfikacja_temp_opad |>
  complete(rok_hydro = lata_os_x)
dane_ryc_21$termiczna = fct_na_value_to_level(
  factor(dane_ryc_21$termiczna, levels = names(kolory_klasyfikacja_termiczna)),
  level = BRAK_DANYCH)
dane_ryc_21$opadowa = fct_na_value_to_level(
  factor(dane_ryc_21$opadowa, levels = names(kolory_klasyfikacja_opadowa)),
  level = BRAK_DANYCH)

# Pasek klas termicznych: jeden kafelek na rok. Oś Y jest sztuczna (y = 1) i ukryta.
ryc_21A = ggplot(dane_ryc_21, aes(x = rok_hydro, y = 1, fill = termiczna)) +
  geom_tile() +

  scale_y_continuous(expand = c(0, 0), limits = c(0.5, 1.5)) +
  scale_x_continuous(breaks = lata_os_x, labels = podpisy_lat_21,
                     limits = zakres_os_x, expand = expansion(add = 0)) +
  scale_fill_manual(values = kolory_21_termiczna, drop = TRUE) +
  labs(x = "", y = "", fill = "") +
  plot_theme() +
  theme(aspect.ratio = 0.11,
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        panel.border = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 90, vjust = 0.5),
        legend.position = "bottom",
        legend.spacing.x = unit(1, "cm"),
        # Czcionka i wielkość symboli legendy jak na rycinie 24. Odstępy zostają
        # własne: plot_theme() zastępuje legend.text w całości, więc element ten
        # nie dziedziczy domyślnego marginesu i bez jawnej wartości nazwy klas
        # nachodzą na kolejne próbki barwy.
        legend.text = element_text(size = 11, margin = margin(r = 20, l = 4, unit = "pt")),
        legend.key.size = unit(0.35, "cm"),
        plot.margin = margin(t = 10, r = 0, b = 0, l = 0, unit = "pt")) +
  guides(fill = guide_legend(byrow = TRUE, nrow = 3))

# Pasek klas opadowych, zbudowany tak samo.
ryc_21B = ggplot(dane_ryc_21, aes(x = rok_hydro, y = 1, fill = opadowa)) +
  geom_tile() +

  scale_y_continuous(expand = c(0, 0), limits = c(0.5, 1.5)) +
  scale_x_continuous(breaks = lata_os_x, labels = podpisy_lat_21,
                     limits = zakres_os_x, expand = expansion(add = 0)) +
  scale_fill_manual(values = kolory_21_opadowa, drop = TRUE) +
  labs(x = "", y = "", fill = "") +
  plot_theme() +
  theme(aspect.ratio = 0.11,
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        panel.border = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 90, vjust = 0.5),
        legend.position = "bottom",
        legend.spacing.x = unit(1, "cm"),
        # Czcionka i wielkość symboli legendy jak na rycinie 24. Odstępy zostają
        # własne: plot_theme() zastępuje legend.text w całości, więc element ten
        # nie dziedziczy domyślnego marginesu i bez jawnej wartości nazwy klas
        # nachodzą na kolejne próbki barwy.
        legend.text = element_text(size = 11, margin = margin(r = 20, l = 4, unit = "pt")),
        legend.key.size = unit(0.35, "cm"),
        plot.margin = margin(t = 10, r = 0, b = 0, l = 0, unit = "pt")) +
  guides(fill = guide_legend(byrow = TRUE, nrow = 2))

# Legendy wyjmujemy z paneli: zostawione w środku dzieliłyby z paskiem przydzieloną
# wysokość, a że legenda termiczna ma więcej klas, pasek A byłby niższy od B.
legenda_21A = get_legend(ryc_21A)
legenda_21B = get_legend(ryc_21B)

# Cztery wiersze siatki: pasek A, jego legenda, pasek B, jego legenda.
ryc_21 = plot_grid(
  ryc_21A + theme(legend.position = "none"),
  legenda_21A,
  ryc_21B + theme(legend.position = "none"),
  legenda_21B,
  ncol = 1,
  # Pasek ma stałe proporcje (aspect.ratio), więc nadmiar wysokości komórki
  # zostaje jako puste tło nad i pod nim. Wysokości wierszy są dobrane tak, żeby
  # komórka niewiele przekraczała to, co faktycznie zajmuje pasek z osią i legenda.
  rel_heights = c(1, 0.52, 1, 0.36),
  labels = c("A", "", "B", ""),
  label_x = 0, hjust = -0.3, vjust = 1.1
)

ryc_21

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_21)).
if (!(ma_dane(klasyfikacja_temp_opad$termiczna, klasyfikacja_temp_opad$opadowa))) ryc_21 <- NULL
