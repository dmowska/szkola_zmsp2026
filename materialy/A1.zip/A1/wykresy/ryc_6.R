################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 6
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Częstość kierunków wiatru (A) oraz średnia prędkość wiatru [m·s⁻¹] według
#   kierunków (B) w Stacji Bazowej ZMŚP {nazwa_stacji} w {analizowany_rok}
#   roku"
#
# Uwagi do kodu:
# Wartości podziałek są wypisywane wewnątrz wykresu, bo oś promieniowa nie ma
# własnych etykiet.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_wiatr_wg_kierunkow: liczebność, częstość i średnia prędkość
#     wiatru wg kierunków
# - plot_theme: funkcja: wspólny motyw wykresów raportu
################################################################################
# WYNIK
################################################################################
# - ryc_6: gotowa rycina złożona z kilku paneli (obiekt cowplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - cowplot
# - ggplot2
################################################################################

# Skala promieniowa co 5%, do maksimum zaokrąglonego w górę.
# max_lub zamiast max: przy stacji bez pomiarów wiatru max() dałby tu -Inf, na którym
# przerwałby się seq() w następnej linii - i to jeszcze przed warunkiem NULL
# z końca skryptu, więc padłby cały raport, zamiast pominąć jedną rycinę.
max_udzial = ceiling(max_lub(dane_wiatr_wg_kierunkow$`%`, 5)/5) * 5
a_etykiety = data.frame(liczba = seq(0, max_udzial, by = 5))

# Róża wiatrów - częstość kierunków. coord_polar zwija oś X w okrąg, a podziałki
# osi promieniowej trzeba dorysować samodzielnie (geom_hline + geom_text).
ryc_6A = ggplot(dane_wiatr_wg_kierunkow, aes(x = kierunek, y = `%`)) +
  geom_col(fill = "#3D74B6", color = "white") +
  coord_polar(start = -pi/16) +
  # Margines promieniowy nad ostatnią podziałką odsuwa etykiety kierunków od
  # skrajnej linii siatki - bez niego napisy leżą dokładnie na niej.
  scale_y_continuous(breaks = a_etykiety$liczba,
                     limits = c(0, max_udzial),
                     expand = expansion(mult = c(0, 0.12))) +
  geom_hline(yintercept = a_etykiety$liczba,
             color = "grey") +
  ggtitle("A: Kierunek wiatru [%]") +
  ylab("") +
  xlab("") +
  plot_theme() +
  theme(panel.grid.major.y = element_blank(),
        panel.grid.minor.y = element_blank(),
        axis.text.y = element_blank(),
        # Oś promieniowa nie ma etykiet, więc jej kreski podziałki zostawały
        # jako myślniki na lewo od róży - usuwamy je razem z etykietami.
        axis.ticks.y = element_blank(),
        axis.text.x = element_text(size = 10,
                                   margin = margin(t = 4, r = 4, b = 4, l = 4)),
        panel.border = element_blank(),
        plot.title = element_text(face = "plain")) +
  geom_text(data = a_etykiety,
            aes(x = 1,
                y = liczba,
                label = liczba),
            size = 3, hjust = 0.5, vjust = 0.5, family = "serif")

max_predkosc = ceiling(max_lub(dane_wiatr_wg_kierunkow$V, 1))

# Krok podziałki co 1 m/s - przy mniejszym okręgi na róży stoją tak gęsto, że
# wartości między nimi zlewają się w jedną plamę. Wyjątkiem są stacje o słabym
# wietrze: gdy najsilniejszy kierunek nie przekracza 2 m/s, krok metrowy zostawia
# na róży dwa okręgi i nie da się z niej nic odczytać - tam schodzimy na 0,5.
krok_predkosc = if (max_predkosc <= 2) 0.5 else 1
b_etykiety = data.frame(liczba = seq(0, max_predkosc, by = krok_predkosc))

# Etykiety prędkości to tekst rysowany przez geom_text, więc formatujemy go tutaj,
# a nie przez skalę. Przy kroku 1 m/s wszystkie podziałki są całkowite i zapisujemy
# je bez części dziesiętnej ("1", "2", "3"). Przy kroku 0,5 połowa wartości całkowita
# nie jest, więc jedno miejsce po przecinku dostaje CAŁA podziałka - inaczej "0,5"
# sąsiadowałoby z "1" i róża sugerowałaby dwie różne dokładności odczytu.
podzialka_calkowita = all(b_etykiety$liczba == round(b_etykiety$liczba))

b_etykiety$etykieta = ifelse(
  b_etykiety$liczba == 0, "0",
  if (podzialka_calkowita) formatC(b_etykiety$liczba, format = "d")
  else formatC(b_etykiety$liczba, format = "f", digits = 1, decimal.mark = ","))

# Róża wiatrów - średnia prędkość w każdym kierunku.
ryc_6B = ggplot(dane_wiatr_wg_kierunkow,aes(x = kierunek, y = V)) +
  geom_col(fill = "#CC3C22", color = "white") +
  coord_polar(start = -pi/16) +
  scale_y_continuous(breaks = b_etykiety$liczba,
                     limits = c(0, max_predkosc),
                     expand = expansion(mult = c(0, 0.12))) +
  geom_hline(yintercept = b_etykiety$liczba,
             color = "grey") +
  ggtitle(expression("B: Średnia prędkość wiatru ["*m %.% s^{-1}*"]")) +
  ylab("") +
  xlab("") +
  plot_theme() +
  theme(panel.grid.major.y = element_blank(),
        panel.grid.minor.y = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.x = element_text(size = 10,
                                   margin = margin(t = 4, r = 4, b = 4, l = 4)),
        panel.border = element_blank(),
        plot.title = element_text(face = "plain")) +
        geom_text(data = b_etykiety,
            aes(x = 1,
                y = liczba,
                label = etykieta),
            size = 3, hjust = 0.5, vjust = 0.5, family = "serif")

# Obie róże obok siebie.
ryc_6 = plot_grid(ryc_6A, ryc_6B, ncol=2)

ryc_6

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_6)).
if (!(ma_dane(dane_wiatr_wg_kierunkow$`%`, dane_wiatr_wg_kierunkow$V))) ryc_6 <- NULL
