################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 20
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Temperatura powietrza i opady atmosferyczne w Stacji Bazowej ZMŚP
#   {nazwa_stacji} w latach {zakres_lat(lata_ryc_20)} na tle okresu
#   referencyjnego {okres_referencyjny}, wyznaczonego na podstawie danych
#   {zrodlo_okresu_ref}"
#
# Uwagi do kodu:
# Siatka klas termicznych i opadowych jest wyznaczana z normy okresu
# referencyjnego, a nazwy klas trafiają na osie dodatkowe. Rok analizowany
# jest wyróżniony kolorem.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - a1_dane_agg_vw_roczne: wartości roczne (wiersze RH) wszystkich lat
#     analizy
# - analizowany_rok: parametr z parametry.xlsx: analizowany rok
#     hydrologiczny
# - sd_temp_okres_ref: odchylenie standardowe temperatury w okresie
#     referencyjnym
# - sredni_opad_okres_ref: norma sumy opadów okresu referencyjnego z bazy
# - srednia_temp_okres_ref: norma temperatury okresu referencyjnego z bazy
################################################################################
# WYNIK
################################################################################
# - ryc_20: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
# - ggrepel
################################################################################

# Rok analizowany wyróżniony kolorem punktu i etykiety.
kolor_punkt = ifelse(a1_dane_agg_vw_roczne$rok_hydro == analizowany_rok, "czerwony", "niebieski")
kolor_rok = ifelse(a1_dane_agg_vw_roczne$rok_hydro == analizowany_rok, "czerwony", "czarny")

zakres_temp = range(a1_dane_agg_vw_roczne$`TA_D avg`, na.rm = TRUE)
zakres_opad = range(a1_dane_agg_vw_roczne$`RR_T sum`, na.rm = TRUE)

# Progi klasyfikacji opadowej: procenty normy okresu referencyjnego.
procent = c(50, 75, 90, 100, 110, 125, 150)
etykiety_opad = round((sredni_opad_okres_ref * procent)/100, 1)

# Granice osi obejmują zarówno wszystkie punkty, jak i całą siatkę klas.
min_granica_y = min(zakres_opad[1], etykiety_opad[1] - 100)
max_granica_y = max(zakres_opad[2], etykiety_opad[7] + 100)

# Środki przedziałów - w tych miejscach staną nazwy klas na osi dodatkowej.
srodki_opad = c(
  (min_granica_y + etykiety_opad[1]) / 2,
  (etykiety_opad[1] + etykiety_opad[2]) / 2,
  (etykiety_opad[2] + etykiety_opad[3]) / 2,
  (etykiety_opad[3] + etykiety_opad[5]) / 2,
  (etykiety_opad[5] + etykiety_opad[6]) / 2,
  (etykiety_opad[6] + etykiety_opad[7]) / 2,
  (etykiety_opad[7] + max_granica_y) / 2
)
wartosc_procent = etykiety_opad[-4]

klasyfikacja_opad = c("skrajnie\nsuchy", "bardzo\nsuchy", "suchy", "normalny",
                      "wilgotny", "bardzo\nwilgotny", "skrajnie\nwilgotny")

# Progi klasyfikacji termicznej: wielokrotności odchylenia standardowego normy.
mnozniki_sd = c(2.5, 2.0, 1.5, 1.0, 0.5, 0.0, -0.5, -1.0, -1.5, -2.0, -2.5)

etykiety_temp = round(srednia_temp_okres_ref + (mnozniki_sd * sd_temp_okres_ref), 1)

min_granica_x = min(zakres_temp[1], etykiety_temp[11] - 0.5)
max_granica_x = max(zakres_temp[2], etykiety_temp[1] + 0.5)

# Środki przedziałów - jak wyżej, dla klas termicznych.
srodki_temp = c(
  (etykiety_temp[1] + max_granica_x) / 2,
  (etykiety_temp[1] + etykiety_temp[2]) / 2,
  (etykiety_temp[2] + etykiety_temp[3]) / 2,
  (etykiety_temp[3] + etykiety_temp[4]) / 2,
  (etykiety_temp[4] + etykiety_temp[5]) / 2,
  (etykiety_temp[5] + etykiety_temp[7]) / 2,
  (etykiety_temp[7] + etykiety_temp[8]) / 2,
  (etykiety_temp[8] + etykiety_temp[9]) / 2,
  (etykiety_temp[9] + etykiety_temp[10]) / 2,
  (etykiety_temp[10] + etykiety_temp[11]) / 2,
  (min_granica_x + etykiety_temp[11]) / 2
)

wartosc_sd = etykiety_temp[-6]

klasyfikacja_temp = c("ekstremalnie\nciepły", "anomalnie\nciepły", "bardzo\nciepły",
                      "ciepły", "lekko\nciepły", "normalny", "lekko\nchłodny",
                      "chłodny", "bardzo\nchłodny", "anomalnie\nchłodny", "ekstremalnie\nchłodny")

# Siatka klas rysowana liniami, lata punktami z etykietami. Nazwy klas trafiają
# na osie dodatkowe (sec_axis), a wartości progów na osie główne.
ryc_20 = ggplot(a1_dane_agg_vw_roczne, aes(x = `TA_D avg`,y = `RR_T sum`)) +
  geom_hline(yintercept = sredni_opad_okres_ref, color = "grey60", linetype = "dashed", linewidth = 0.4) +
  geom_hline(yintercept = wartosc_procent, color = "grey60") +
  geom_vline(xintercept = srednia_temp_okres_ref,color = "grey60", linetype = "dashed", linewidth = 0.4) +
  geom_vline(xintercept = wartosc_sd, color = "grey60") +
  geom_point(aes(color = kolor_punkt), size=2) +
  geom_text_repel(
    aes(label = rok_hydro, color = kolor_rok),
    size = 3,
    family = "serif",
    box.padding = 0.25,
    point.padding = 0.1,
    segment.color = 'grey30',
    segment.size = 0.3,
    min.segment.length = 0.2,
    force = 0.5,
    max.overlaps = Inf
  ) +
  xlab("Temperatura powietrza [°C]") +
  ylab("Opad atmosferyczny [mm]") +
  scale_color_manual(values = c("czerwony" = "#c65711",
                                "niebieski" = "#2f75b5",
                                "czarny" = "black")) +
  scale_y_continuous(breaks = etykiety_opad,
                     limits = c(min_granica_y, max_granica_y),
                     labels = function(x) {
                       ifelse(x == 0,"0",formatC(x, format = "f", digits = 1, decimal.mark = ","))
                     },
                     sec.axis = sec_axis(~ ., breaks = srodki_opad,
                                         labels = klasyfikacja_opad)) +
  scale_x_continuous(breaks = etykiety_temp,
                     limits = c(min_granica_x, max_granica_x),
                     labels = function(x) {
                       ifelse(x == 0,"0",formatC(x, format = "f", digits = 1, decimal.mark = ","))
                     },
                     sec.axis = sec_axis(~ ., breaks = srodki_temp,
                                         labels = klasyfikacja_temp)) +
  theme(text = element_text(family = "serif", size = 10),
        axis.title = element_text(size = 10),
        axis.text.x.top = element_text(size = 8, angle = 90, vjust = 0.5),
        axis.text.y.right = element_text(size = 8),
        axis.text.x = element_text(color = "black", size = 9),
        axis.text.y = element_text(color = "black", size = 9),
        panel.background = element_rect(fill = NA),
        panel.border = element_rect(colour = "black", fill = NA),
        legend.position = "none")

ryc_20

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_20)).
if (!(ma_dane(a1_dane_agg_vw_roczne$`TA_D avg`, a1_dane_agg_vw_roczne$`RR_T sum`))) ryc_20 <- NULL
