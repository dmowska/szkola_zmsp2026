################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 27
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Liczba dni charakterystycznych pod względem temperatury powietrza w
#   poszczególnych miesiącach i latach hydrologicznych w Stacji Bazowej ZMŚP
#   {nazwa_stacji} w okresie {zakres_lat(lata_ryc_27)}. Kryteria
#   wyznaczenia dni charakterystycznych znajdują się w tabeli 8"
#
# Uwagi do kodu:
# Kolor kafelka oddaje liczbę dni w miesiącu; miesiące bez takich dni zostają puste.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dni_charakterystyczne_temp_etykiety_kryteria: nazwy kategorii wraz
#     z kryterium temperatury - podpisy pasków faset
# - krok_osi_lat: funkcja: krok podpisów osi lat dobrany do długości serii
# - lata_ryc_27: lata, w których rycina ma dane - z nich powstaje zakres osi X
# - miesiace_hydro: miesiące w porządku roku hydrologicznego (11, 12,
#     1:10)
# - plot_theme: funkcja: wspólny motyw wykresów raportu
# - ryc_dni_ch_temp_m_r: liczba dni charakterystycznych temperatury w
#     układzie miesiąc x rok hydrologiczny
################################################################################
# WYNIK
################################################################################
# - dane_ryc_27: dane mapy bez kategorii, których nie odnotowano ani razu
#     w całym wieloleciu (nie dostają własnej fasety)
# - ryc_27: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
# - forcats
# - ggplot2
# - RColorBrewer
################################################################################

# Nazwy kategorii wypisywane na paskach faset, wraz z kryterium wyznaczenia
# (progiem temperatury) w nawiasie - tak jak w tabeli 8.
kategoria_etykiety <- as_labeller(dni_charakterystyczne_temp_etykiety_kryteria)

# Kategorie, których na stacji nie odnotowano ANI RAZU w całym wieloleciu, nie
# dostają własnej fasety - pusty panel niósłby tylko siatkę i podpis. Zero
# w pojedynczym miesiącu czy roku zostaje, bo to informacja sama w sobie.
dane_ryc_27 <- ryc_dni_ch_temp_m_r |>
  group_by(kategoria) |>
  filter(sum(wartosc, na.rm = TRUE) > 0) |>
  ungroup() |>
  mutate(kategoria = fct_drop(kategoria))

# Zakres osi X: od pierwszego do ostatniego roku z danymi tej ryciny (lata_ryc_27
# z przetwarzanie_danych.R), a nie całe wielolecie z parametrów. Krok podpisów
# dobrany do długości tej serii.
rok_od_27 <- min(lata_ryc_27)
rok_do_27 <- max(lata_ryc_27)
krok_lat_27 <- krok_osi_lat(rok_do_27 - rok_od_27 + 1)

# Mapa rok x miesiąc, osobny panel dla każdej kategorii. cut() dzieli liczbę dni
# na klasy; zero wypada poza pierwszym przedziałem i zostaje jako NA, czyli kafelek
# przezroczysty opisany w legendzie jako "brak". Siatkę rysujemy ręcznie, na stykach
# kafelków, bo domyślna trafiałaby w ich środki.
ryc_27 = ggplot(dane_ryc_27, aes(x = rok_hydro, y = miesiac, fill = cut(wartosc, breaks = c(0, 5, 10, 15, 20, 25, 31)))) +
  geom_tile() +

  geom_vline(xintercept = seq(rok_od_27 - 0.5, rok_do_27 + 0.5, by = 1), color = "lightgrey", linewidth = 0.2) +
  geom_hline(yintercept = seq(0.5, length(miesiace_hydro) + 0.5, by = 1), color = "lightgrey", linewidth = 0.2) +

  facet_wrap(~kategoria, labeller = kategoria_etykiety) +

  scale_fill_manual(name = "Liczba dni",
                    values = rev(brewer.pal(n = 7, name = "Spectral")), na.value = "transparent",
                    labels = c("1-5", "6-10", "11-15", "16-20", "21-25", "26-31", "brak")) +

  scale_x_continuous(
    breaks = seq(rok_od_27, rok_do_27, krok_lat_27)
  ) +

  # drop = FALSE zostawia na osi wszystkie miesiące roku hydrologicznego, także
  # te bez pomiaru - inaczej miesiąc bez danych znika z osi razem z podpisem.
  scale_y_discrete(drop = FALSE, labels = as.roman(miesiace_hydro)) +

  labs(x = "", y = "") +
  guides(fill=guide_legend(nrow=2,byrow=TRUE)) +
  plot_theme() +
  theme(
    strip.text = element_text(size = 10, color = "black", face = "bold.italic"),
    strip.background = element_rect(color="darkgrey", fill="white"),
    axis.text.x = element_text(angle = 90, hjust = 1, size = 9),
    axis.text.y = element_text(size = 9),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),

    legend.position = "bottom",
    # Czcionka i wielkość symboli legendy jak na rycinie 24. Margines tekstu
    # podajemy jawnie: plot_theme() zastępuje legend.text w całości, więc
    # element ten nie dziedziczy domyślnego odstępu od kolejnej próbki barwy.
    legend.text = element_text(size = 11, margin = margin(r = 6, l = 2, unit = "pt")),
    legend.title = element_text(size = 11),
    legend.key.size = unit(0.35, "cm")
  )

ryc_27

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_27)).
if (!(any(dane_ryc_27$wartosc > 0, na.rm = TRUE))) ryc_27 <- NULL
