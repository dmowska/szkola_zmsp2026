################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 28
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Liczba dni charakterystycznych pod względem opadu atmosferycznego w
#   poszczególnych miesiącach i latach hydrologicznych w Stacji Bazowej ZMŚP
#   {nazwa_stacji} w okresie {zakres_lat(lata_ryc_28)}"
#
# Uwagi do kodu:
# Kolory są przypisane po nazwie klasy, a nie po pozycji w palecie, więc ten
# sam kolor oznacza tę samą liczbę dni co na rycinie 27.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dni_charakterystyczne_opad_etykiety_mm: etykiety legendy: przedziały
#     opadu w mm
# - krok_osi_lat: funkcja: krok podpisów osi lat dobrany do długości serii
# - lata_ryc_28: lata, w których rycina ma dane - z nich powstaje zakres osi X
# - miesiace_hydro: miesiące w porządku roku hydrologicznego (11, 12,
#     1:10)
# - plot_theme: funkcja: wspólny motyw wykresów raportu
# - ryc_dni_ch_opad_m_r: liczba dni charakterystycznych opadu w układzie
#     miesiąc x rok hydrologiczny
################################################################################
# WYNIK
################################################################################
# - dane_ryc_28: dane mapy wraz z kolumną klasa_dni, bez kategorii, których
#     nie odnotowano ani razu w całym wieloleciu
# - ryc_28: gotowa rycina (obiekt ggplot)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
# - forcats
# - ggplot2
# - RColorBrewer
################################################################################

# Fasety podpisane przedziałami w mm, tak samo jak legenda ryciny 26.
kategoria_etykiety_opad <- as_labeller(dni_charakterystyczne_opad_etykiety_mm)

# Klasy liczby dni wspólne z ryciną 27 - miesiąc ma najwyżej 31 dni, więc podział
# jest ten sam dla dni z opadem i dla dni upalnych.
progi_liczby_dni = c(0, 5, 10, 15, 20, 25, 31)
klasy_liczby_dni = c("1-5", "6-10", "11-15", "16-20", "21-25", "26-31")

# Kolory przypisane po NAZWIE klasy, nie po pozycji w palecie. Przy opadzie górne
# przedziały bywają puste i przypisanie pozycyjne przesunęłoby barwy - ta sama
# liczba dni miałaby inny kolor niż na rycinie 27.
kolory_liczby_dni = c(setNames(rev(brewer.pal(n = 7, name = "Spectral"))[1:6],
                               klasy_liczby_dni),
                      "brak" = "transparent")

# Zero dni daje z cut() wartość NA. Zamieniamy je na zwykły poziom "brak", żeby
# legenda opisywała go tak samo jak na rycinie 27, a nie jako "NA".
ryc_dni_ch_opad_m_r$klasa_dni = ryc_dni_ch_opad_m_r$wartosc |>
  cut(breaks = progi_liczby_dni, labels = klasy_liczby_dni) |>
  fct_na_value_to_level(level = "brak")

# Mapa rok x miesiąc, osobny panel dla każdej kategorii. Siatkę rysujemy ręcznie,
# na stykach kafelków.
# Kategorie nieodnotowane na stacji ani razu nie dostają fasety - pusty panel
# niósłby tylko siatkę i podpis. Filtrujemy po surowej liczbie dni, a nie po
# klasie, bo klasa "brak" istnieje również dla miesięcy z zerem.
dane_ryc_28 <- ryc_dni_ch_opad_m_r |>
  group_by(kategoria) |>
  filter(sum(wartosc, na.rm = TRUE) > 0) |>
  ungroup() |>
  mutate(kategoria = fct_drop(kategoria))

# Zakres osi X: od pierwszego do ostatniego roku z danymi tej ryciny (lata_ryc_28
# z przetwarzanie_danych.R), a nie całe wielolecie z parametrów. Krok podpisów
# dobrany do długości tej serii.
rok_od_28 <- min(lata_ryc_28)
rok_do_28 <- max(lata_ryc_28)
krok_lat_28 <- krok_osi_lat(rok_do_28 - rok_od_28 + 1)

ryc_28 = ggplot(dane_ryc_28, aes(x = rok_hydro, y = miesiac, fill = klasa_dni)) +
  geom_tile() +

  geom_vline(xintercept = seq(rok_od_28 - 0.5, rok_do_28 + 0.5, by = 1), color = "lightgrey", linewidth = 0.2) +
  geom_hline(yintercept = seq(0.5, length(miesiace_hydro) + 0.5, by = 1), color = "lightgrey", linewidth = 0.2) +

  facet_wrap(~kategoria, labeller = kategoria_etykiety_opad) +

  scale_fill_manual(name = "Liczba dni", values = kolory_liczby_dni) +

  scale_x_continuous(
    breaks = seq(rok_od_28, rok_do_28, krok_lat_28)
  ) +

  # drop = FALSE zostawia na osi wszystkie miesiące roku hydrologicznego, także
  # te bez pomiaru - inaczej miesiąc bez danych znika z osi razem z podpisem.
  scale_y_discrete(drop = FALSE, labels = as.roman(miesiace_hydro)) +

  labs(x = "", y = "") +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE)) +
  plot_theme() +
  theme(
    strip.text = element_text(size = 12, color = "black", face = "bold.italic"),
    strip.background = element_rect(color = "darkgrey", fill = "white"),
    axis.text.x = element_text(angle = 90, hjust = 1, size = 9),
    axis.text.y = element_text(size = 9),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),

    legend.position = "bottom",
    # Czcionka i wielkość symboli legendy jak na rycinie 24. Margines tekstu
    # podajemy jawnie: plot_theme() zastępuje legend.text w całości, więc
    # element ten nie dziedziczy domyślnego odstępu od kolejnej próbki barwy.
    legend.text = element_text(size = 11, margin = margin(r = 6, l = 2, unit = "pt")),
    legend.title = element_text(size = 11),
    legend.key.size = unit(0.35, "cm")
  )

ryc_28

# Stacja bez pomiarów tego elementu dałaby pustą ramkę z podpisem. NULL sprawia,
# że tworzenie_raportu.qmd pomija chunk tej ryciny (eval = !is.null(ryc_28)).
if (!(any(dane_ryc_28$wartosc > 0, na.rm = TRUE))) ryc_28 <- NULL
