################################################################################
# OPIS SKRYPTU
################################################################################
# funkcje/formatowanie_tabel.R - domyślne ustawienia i formatowanie liczb w tabelach
#
# Ustawia domyślne parametry flextable dla całego raportu i definiuje funkcje
# doprowadzające zawartość komórek do jednolitego zapisu liczb. Funkcje są
# wywoływane w tworzenie_raportu.qmd, tuż przed zbudowaniem tabel.
#
# Uwagi do kodu:
# Formatowanie działa na tekście, a nie na liczbach, bo tabele są w tym miejscu
# już przetransponowane i przechowują wartości jako napisy. Puste komórki i
# braki danych zawsze zapisujemy kropką, żeby tabela nie miała dziur.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - brak - plik nie korzysta z żadnych obiektów zewnętrznych
################################################################################
# WYNIK
################################################################################
# - fmt_komorki: zamiana kolumn liczbowych na tekst z przecinkiem
#     dziesiętnym
# - num1: wymuszenie jednego miejsca po przecinku w komórkach tekstowych,
#     które są liczbą
# - fmt_tab7_komorka: format tabeli 7, gdzie w jednej komórce stoi suma
#     opadu i procent normy
# - domyślne ustawienia flextable obowiązujące w całym raporcie
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - flextable
################################################################################

# Domyślne ustawienia flextable
set_flextable_defaults(
  font.size = 9,
  padding = 2,
  theme_fun = NULL,
  decimal.mark = ",",
  big.mark = " ",
  na_str = ".",
  nan_str = "."
)

# Kolumny liczbowe na tekst z przecinkiem dziesiętnym; NA i puste komórki -> ".".
# Wywoływana w tworzenie_raportu.qmd, przed zbudowaniem każdej tabeli.
fmt_komorki <- function(df, digits = 1) {
  as.data.frame(lapply(df, function(col) {
    if (is.numeric(col)) {
      out <- formatC(col, format = "f", digits = digits, decimal.mark = ",")
      out[is.na(col) | trimws(out) %in% c("", "NA")] <- "."
      out
    } else {
      col <- as.character(col)
      col[is.na(col) | trimws(col) == ""] <- "."
      col
    }
  }), stringsAsFactors = FALSE, check.names = FALSE)
}

# Wymusza 1 miejsce po przecinku (separator ",") w komórkach tekstowych,
# które są liczbą (np. "5" -> "5,0", "5.3" -> "5,3"). Etykiety, daty, "." oraz
# komórki nieliczbowe pozostają bez zmian; NA -> ".".
num1 <- function(col) {
  col <- as.character(col)
  vapply(col, function(x) {
    if (is.na(x)) return(".")
    xt <- trimws(x)
    if (grepl("^-?\\d+(?:[.,]\\d+)?$", xt)) {
      formatC(as.numeric(gsub(",", ".", xt)), format = "f", digits = 1, decimal.mark = ",")
    } else {
      x
    }
  }, character(1), USE.NAMES = FALSE)
}

# Tabela 7 (wyjątek): część opadowa (mm) -> 1 miejsce po przecinku z ",",
# część procentowa (%) pozostaje bez miejsc po przecinku, np. "5,0\n(2%)".
fmt_tab7_komorka <- function(col) {
  col <- as.character(col)
  vapply(col, function(v) {
    if (is.na(v) || trimws(v) == "") return(".")
    m <- regmatches(v, regexec("^\\s*(-?\\d+(?:[.,]\\d+)?)(.*)$", v))[[1]]
    if (length(m) == 0) return(v)                 # brak części liczbowej -> bez zmian
    liczba <- suppressWarnings(as.numeric(gsub(",", ".", m[2])))
    if (is.na(liczba)) return(v)
    paste0(formatC(liczba, format = "f", digits = 1, decimal.mark = ","), m[3])
  }, character(1), USE.NAMES = FALSE)
}