################################################################################
# OPIS SKRYPTU
################################################################################
# funkcje/funkcje_pomocnicze.R - funkcje pomocnicze i palety kolorów
#
# Definicje używane w całym raporcie: przeliczanie miesięcy, wyznaczanie
# kierunku wiatru, przypisywanie kolorów komórkom tabel klasyfikacyjnych oraz
# palety i etykiety legend wspólne dla rycin. Plik nic nie liczy - tylko
# definiuje obiekty.
#
# Uwagi do kodu:
# Palety kolorów pełnią podwójną rolę: nadają barwy, a ich nazwy wyznaczają
# kolejność poziomów faktorów w danych. Dzięki temu kategorie na rycinach i w
# legendach zawsze stoją w tej samej kolejności, a lista kategorii nie może
# rozjechać się z listą barw.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - brak - plik nie korzysta z żadnych obiektów zewnętrznych
################################################################################
# WYNIK
################################################################################
# - nr_miesiaca, miesiac_rzymski: numer miesiąca kalendarzowego i jego
#     zapis rzymski
# - kierunek_wiatru: nazwa kierunku róży wiatrów dla wartości wektorowej
#     WID
# - koloruj_temp, koloruj_czcionka_temp: kolory tła i czcionki tabeli 6
# - koloruj_miesiac_opad, koloruj_rok_opad, koloruj_czcionka_m_opad,
#     koloruj_czcionka_r_opad: kolory tła i czcionki tabeli 7
# - kolory_klasyfikacja_termiczna, kolory_klasyfikacja_opadowa: palety
#     klas
# - kolory_dni_charakterystyczne_temp, kolory_dni_charakterystyczne_opad:
#     palety kategorii dni
# - kolory_kompletnosc: paleta klas kompletności serii (ryciny 29 i 30)
# - opisy_elementow: jedyny słownik opisów elementów meteorologicznych;
#     nazwy wyznaczają też kolejność elementów na rycinach 29 i 30
# - jednostki_elementow: jednostka każdego elementu, doklejana przy symbolu
# - opis_elementow_txt: lista "SYMBOL [jednostka] - opis" do bloków objaśnień
# - kolory_perc_doy, kolory_linii_doy: palety wstęg i linii rycin 10-14
# - dni_charakterystyczne_temp_etykiety,
#     dni_charakterystyczne_opad_etykiety_mm: etykiety legend
# - dni_charakterystyczne_temp_etykiety_kryteria: te same kategorie wraz
#     z kryterium temperatury - podpisy faset ryciny 27
# - kompletnosc_temperatura: wykaz elementów temperaturowych, czyli podział
#     materiału między ryciny 29 i 30
# - ma_dane: czy seria ma cokolwiek do narysowania
# - min_lub, max_lub: skrajne wartości serii, odporne na komplet braków
# - krok_osi_lat: krok podpisów osi lat dobrany do długości serii
# - zakres_lat: zwięzły zapis zbioru lat ("1995-2024" albo wykaz z lukami)
# - lata_z_danymi: lata obecne w danych ryciny - zakres jej osi lat
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
################################################################################

# Pomocnicze funkcje

# Miesiąc jest w danych faktorem o poziomach miesiace_hydro (konwersja zbiorcza
# na początku przetwarzanie_danych.R). Poziomy są ułożone w porządku roku
# hydrologicznego (11, 12, 1-10), więc KOD POZIOMU NIE JEST NUMEREM MIESIĄCA -
# as.integer() na takim faktorze zwróciłby 1 dla listopada. Poniższe funkcje
# zdejmują tę pułapkę wszędzie tam, gdzie potrzebny jest numer kalendarzowy.
# Używana w: przetwarzanie_danych.R (sortowanie tabeli 8 wg miesiąca kalendarzowego
# oraz numery miesięcy dla tabel 9 i 10) i w miesiac_rzymski() poniżej.
nr_miesiaca = function(x) as.integer(as.character(x))

# Numer miesiąca zapisem rzymskim - postać używana w nagłówkach i kolumnach tabel
# Używana w: przetwarzanie_danych.R (nagłówki i etykiety tabel 1, 2, 4 i 8 oraz
# terminy w tabelach 9 i 10) i w wykresy/ryc_1-5 oraz ryc_10-14 (podpisy osi X).
miesiac_rzymski = function(x) as.character(as.roman(nr_miesiaca(x)))

# funkcja do określania kierunku wiatru na podstawie wartości wektorowych
# Używana w: przetwarzanie_danych.R (kolumna kierunek w a1_wiatr_dobowe_vw, na której
# opierają się tabele 2 i 3 oraz rycina 6).
kierunek_wiatru = function(x) {
  case_when(
    x >= 347.76 | x <= 11.25 ~ "N",
    x >= 11.26 & x <= 33.75 ~ "NNE",
    x >= 33.76 & x <= 56.25 ~ "NE",
    x >= 56.26 & x <= 78.75 ~ "ENE",
    x >= 78.76 & x <= 101.25 ~ "E",
    x >= 101.26 & x <= 123.75 ~ "ESE",
    x >= 123.76 & x <= 146.25 ~ "SE",
    x >= 146.26 & x <= 168.75 ~ "SSE",
    x >= 168.76 & x <= 191.25 ~ "S",
    x >= 191.26 & x <= 213.75 ~ "SSW",
    x >= 213.76 & x <= 236.25 ~ "SW",
    x >= 236.26 & x <= 258.75 ~ "WSW",
    x >= 258.76 & x <= 281.25 ~ "W",
    x >= 281.26 & x <= 303.75 ~ "WNW",
    x >= 303.76 & x <= 326.25 ~ "NW",
    x >= 326.26 & x <= 348.75 ~ "NNW")
}

# Tło komórek MIESIĘCZNYCH tabeli 7 (klasyfikacja opadowa), wg procentu normy.
# Używana w: przetwarzanie_danych.R (macierz kolory_bg_miesiace_opad); tabelę 7 malują
# nią tworzenie_raportu.qmd i zapis_tabel.R.
koloruj_miesiac_opad = function(x) {
  case_when(
    x < 25 ~ "#c65711",
    x >= 25 & x <= 49 ~ "#ffd966",
    x >= 50 & x <= 74 ~ "#ffff99",
    x >= 75 & x <= 124 ~ "#99cc00",
    x >= 125 & x <= 149 ~ "#99ccff",
    x >= 150 & x <= 175 ~ "#2f75b5",
    x > 175 ~ "#203764",
    TRUE ~ "#ffffff")
}

# Czcionka w komórkach miesięcznych tabeli 7 - biała na najciemniejszym tle.
# Używana w: przetwarzanie_danych.R (macierz kolory_czcionka_m_opad).
koloruj_czcionka_m_opad = function(x) {
  case_when(
    x > 175 ~ "white",
    TRUE ~ "black")
}

# Tło kolumny ROCZNEJ tabeli 7 - progi roczne są inne niż miesięczne.
# Używana w: przetwarzanie_danych.R (macierz kolory_bg_lata_opad).
koloruj_rok_opad = function(x) {
  case_when(
    x < 50 ~ "#c65711",
    x >= 50 & x <= 74 ~ "#ffd966",
    x >= 75 & x <= 89 ~ "#ffff99",
    x >= 90 & x <= 110 ~ "#99cc00",
    x >= 111 & x <= 125 ~ "#99ccff",
    x >= 126 & x <= 150 ~ "#2f75b5",
    x > 150 ~ "#203764",
    TRUE ~ "#ffffff")
}

# Czcionka w kolumnie rocznej tabeli 7 - biała na najciemniejszym tle.
# Używana w: przetwarzanie_danych.R (macierz kolory_czcionka_r_opad).
koloruj_czcionka_r_opad = function(x) {
  case_when(
    x > 150 ~ "white",
    TRUE ~ "black")
}

# Tło komórek tabeli 6 (klasyfikacja termiczna), przypisywane po nazwie klasy.
# Używana w: przetwarzanie_danych.R (macierz kolory_bg_temp); tabelę 6 malują nią
# tworzenie_raportu.qmd i zapis_tabel.R.
koloruj_temp = function(x) {
  case_when(
    x == "ekstremalnie ciepły" ~ "#ff0000",
    x == "anomalnie ciepły"    ~ "#ff9900", 
    x == "bardzo ciepły"       ~ "#ffcc00", 
    x ==  "ciepły"             ~ "#ffff00", 
    x ==  "lekko ciepły"       ~ "#ffff99", 
    x == "normalny"            ~ "#ccffcc",
    x == "lekko chłodny"       ~ "#ccffff", 
    x == "chłodny"             ~ "#00ccff", 
    x == "bardzo chłodny"      ~ "#0000ff", 
    x == "anomalnie chłodny"   ~ "#3c3c9e", 
    x == "ekstremalnie chłodny"~ "#00007d",
    TRUE ~ "#ffffff")
}

# Czcionka w tabeli 6 - biała na ciemnych klasach chłodnych.
# Używana w: przetwarzanie_danych.R (macierz kolory_czcionka_temp).
koloruj_czcionka_temp = function(x) {
  case_when(
    x%in%c("bardzo chłodny", 
           "anomalnie chłodny", 
           "ekstremalnie chłodny") ~ "white",
    TRUE ~ "black")
}

# Barwy wstęg (zakres i percentyle wielolecia) oraz linii na rycinach 10-14.
# Używane w: wykresy/ryc_10.R - ryc_14.R (kolory wstęg i kolory trzech linii;
# nazwy linii dokłada nazwy_linii_doy z przetwarzanie_danych.R).
kolory_perc_doy <- c(
  "Minimum-Maksimum" = "#87CEFA", 
  "Percentyle: 05-95" = "#75b3d9", 
  "Percentyle: 25-75" = "#335572")

kolory_linii_doy <- c(
  "analizowany_rok"  = "red", 
  "Średnia"          = "darkblue", 
  "Mediana"          = "#00FFFF")


# Kompletność serii danych (ryciny 29 i 30). Paleta nie jest ozdobą, tylko niesie
# GRANICĘ UŻYTECZNOŚCI DANYCH: 90% i 100% to progi, od których baza zgadza się
# policzyć agregat (100% dla opadu, 90% dla pozostałych elementów). Dlatego klasy
# poniżej progu są ciepłe (bordo, czerwień, pomarańcz), a te od progu w górę chłodne
# (błękit, granat) - przejście z ciepłych na chłodne wypada dokładnie tam, gdzie
# dane zaczynają się nadawać do liczenia, i widać je jednym rzutem oka.
# Dwie klasy chłodne różnią się między sobą jasnością, bo to one rozstrzygają
# o opadzie: 90-99% wystarcza wszystkim elementom poza RR_T, 100% - także RR_T.
# "brak pomiaru" (NULL w bazie) dostaje jasny szary - celowo spoza skali, bo to nie
# jest najniższa wartość, tylko brak wartości, i nie może udawać zera.
#
# Dobór sprawdzony liczbowo, nie na oko: przy każdej parze kolorów (nie tylko
# sąsiednich, bo na mapie sąsiadują ze sobą dowolne klasy) odległość barwna wynosi
# co najmniej 19 dla widzenia normalnego i 13 przy symulacji protanopii, deuteranopii
# i tritanopii - także między szarością "brak pomiaru" a klasą najniższą.
# Używana w: przetwarzanie_danych.R (nazwy klas wyznaczają etykiety w klasa_kompletnosci())
# oraz wykresy/ryc_29.R i ryc_30.R (kolory kafelków).
kolory_kompletnosc = c(
  "0%"           = "#7f0000",
  "1-49%"        = "#d7301f",
  "50-89%"       = "#fc8d59",
  "90-99%"       = "#74a9cf",
  "100%"         = "#023858",
  "brak pomiaru" = "#f0f0f0")

# Podział elementów między dwie ryciny miesięczne: osiem elementów temperaturowych
# (powietrze, przy gruncie, w gruncie) i cała reszta. Komplet piętnastu paneli na
# jednej rycinie dałby kafelki tak wąskie, że nie dałoby się odczytać pojedynczego
# miesiąca; po podziale każda rycina ma trzy rzędy paneli.
# Używany w: wykresy/ryc_29.R (bierze te elementy) i wykresy/ryc_30.R (bierze resztę).
kompletnosc_temperatura = c("TA_D", "TA_N", "TA_X", "TA_G",
                            "T_S 5", "T_S 10", "T_S 20", "T_S 50")

# Kolory dla klasyfikacji termicznej
# Używana w: przetwarzanie_danych.R (poziomy faktora klas, legenda tabeli 6 i klasy
# skrajne w tabeli 9), tworzenie_raportu.qmd oraz zapis_tabel.R (barwy w legendzie)
# i wykresy/ryc_21.R (pasek klas panelu A).
kolory_klasyfikacja_termiczna = c(
  "ekstremalnie ciepły"= "#ff0000",
  "anomalnie ciepły"   = "#ff9900", 
  "bardzo ciepły"      = "#ffcc00", 
  "ciepły"             = "#ffff00", 
  "lekko ciepły"       = "#ffff99", 
  "normalny"           = "#ccffcc",
  "lekko chłodny"       = "#ccffff", 
  "chłodny"             = "#00ccff", 
  "bardzo chłodny"      = "#0000ff", 
  "anomalnie chłodny"   = "#3c3c9e", 
  "ekstremalnie chłodny"= "#00007d"
)

# Kolory dla klasyfikacji opadowej 
# Używana w: przetwarzanie_danych.R (poziomy faktora klas i legenda tabeli 7),
# tworzenie_raportu.qmd oraz zapis_tabel.R (barwy w legendzie) i wykresy/ryc_21.R
# (pasek klas panelu B).
kolory_klasyfikacja_opadowa = c(
  "skrajnie suchy"     = "#c65711",
  "bardzo suchy"       = "#ffd966",
  "suchy"              = "#ffff99",
  "normalny"           = "#99cc00",
  "wilgotny"           = "#99ccff",
  "bardzo wilgotny"    = "#2f75b5",
  "skrajnie wilgotny" = "#203764")

# Czy jest cokolwiek do narysowania. Stacje mierzą różne zestawy elementów, więc
# dla części z nich rycina wyszłaby pusta - sama ramka z podpisem. Skrypt takiej
# ryciny podstawia na końcu NULL, a tworzenie_raportu.qmd pomija odpowiadający jej
# chunk (eval = !is.null(ryc_N)), dzięki czemu do raportu nie trafia ani rysunek,
# ani podpis, ani podział strony.
#
# Uwaga: dla liczb dni charakterystycznych zero jest informacją ("nie było takich
# dni"), a nie brakiem danych - tam warunek jest zapisany wprost jako suma > 0,
# a nie przez tę funkcję.
# Używana w: ostatniej linii każdego pliku wykresy/ryc_*.R poza rycinami dni
# charakterystycznych (22, 23, 25-28) i miesięcznymi rycinami kompletności (29, 30),
# które mają własne warunki, oraz w przetwarzanie_danych.R (funkcje liczba_dni()
# i skrajna() budujące tabele 9 i 10).
ma_dane = function(...) {
  wartosci <- unlist(list(...), use.names = FALSE)
  length(wartosci) > 0 && any(!is.na(wartosci))
}

# Skrajna wartość serii, odporna na komplet braków. min() i max() na samych NA
# zwracają Inf i -Inf, a to wywraca każde miejsce, w którym z zakresu powstaje ciąg
# podziałek: seq(0, -Inf, by = 5) przerywa pracę komunikatem "'to' must be a finite
# number". Skrypt ryciny nie doszedłby wtedy do własnego warunku NULL w ostatniej
# linii i cały raport przerwałby się na stacji, która danego elementu nie mierzy.
# Wartość zastępcza służy wyłącznie do bezpiecznego dokończenia budowy obiektu -
# rycina bez danych i tak zostanie na końcu skryptu zastąpiona przez NULL i nie
# trafi do raportu.
# Używane w: wykresy/ryc_7.R i ryc_8.R (zakres osi Y), ryc_15.R (zakres osi Y
# panelu B); samo max_lub() także w wykresy/ryc_6.R (skala promieniowa obu róż wiatrów).
min_lub = function(x, zastepczy = 0) if (any(is.finite(x))) min(x, na.rm = TRUE) else zastepczy
max_lub = function(x, zastepczy = 1) if (any(is.finite(x))) max(x, na.rm = TRUE) else zastepczy

# Krok podziałki osi lat dobierany do długości serii, a nie zaszyty na sztywno.
# Stały krok co 4-5 lat dobrze wygląda przy trzydziestoletnim wieloleciu, ale
# przy serii dziesięcioletniej lub krótszej zostawia dwie, trzy podpisane
# wartości. Celujemy w mniej więcej `docelowo` podpisów.
# Używana w KAŻDEJ rycinie z osią lat - żadna nie ma kroku wpisanego na sztywno:
#  - wykresy/ryc_27.R - ryc_30.R: oś dzieli się na trzy wąskie panele faset w rzędzie,
#    więc zostaje przy domyślnych 7 podpisach,
#  - wykresy/ryc_15.R - ryc_19.R, ryc_21.R, ryc_25.R i ryc_26.R: oś zajmuje
#    całą szerokość ryciny, a podpisy stoją pionowo, więc mieści ich więcej
#    (docelowo = 15).
krok_osi_lat = function(n_lat, docelowo = 7) {
  max(1, ceiling(n_lat / docelowo))
}

# Zwięzły zapis zbioru lat: ciągły przedział jako "1995-2024", z lukami jako wykaz.
# Używana w: pobieranie_danych.R (komunikaty o dostępnych latach) oraz w podpisach
# tabel 5-7 i rycin wieloletnich w tworzenie_raportu.qmd - do sesji Quarto trafia
# przez dane/dane_all.RData.
zakres_lat = function(lata) {
  lata <- sort(unique(as.integer(lata)))
  lata <- lata[!is.na(lata)]
  if (length(lata) == 0) return("brak")
  if (length(lata) == 1) return(as.character(lata))
  if (identical(lata, min(lata):max(lata))) paste0(min(lata), "-", max(lata))
  else paste(lata, collapse = ", ")
}

# Lata, dla których źródło danych ryciny ma wiersz - podstawa osi lat tej ryciny.
# Każda rycina wieloletnia dostaje zakres z WŁASNYCH danych, od pierwszego do
# ostatniego roku, w którym je ma: widoki bazy pomijają lata niezależnie od siebie,
# więc wspólna oś rozciągnięta na całe wielolecie zostawiałaby na rycinach z krótszą
# serią długie puste odcinki. Luka w środku serii zostaje na osi pustym miejscem.
# Pusty zbiór lat zastępuje rok analizowany - rycina bez danych i tak zostaje na końcu
# swojego skryptu zastąpiona przez NULL, a oś musi dać się zbudować (min() z pustego
# wektora daje Inf i przerywa seq()).
# Używana w: przetwarzanie_danych.R (obiekty lata_ryc_*).
lata_z_danymi = function(rok, zastepczy) {
  lata <- sort(unique(as.integer(rok[!is.na(rok)])))
  if (length(lata) == 0) as.integer(zastepczy) else lata
}

# Dni charakterystyczne - temperatura
# Używana w: przetwarzanie_danych.R (poziomy faktora kategorii) oraz wykresy/ryc_22.R,
# ryc_24.R i ryc_25.R.
kolory_dni_charakterystyczne_temp =  
  c("bardzo upalne"  = "#67000D",
    "upalne"         = "#B2182B",
    "gorace"         = "#F4A582",
    "przymrozkowe"   = "#92C5DE",
    "mrozne"         = "#2166AC",
    "bardzo mrozne"  = "#053061")

# Używana w: przetwarzanie_danych.R (poziomy faktora kategorii) oraz wykresy/ryc_23.R,
# ryc_24.R i ryc_26.R.
kolory_dni_charakterystyczne_opad = c(
  "bardzo slaby"       = "#ffd966", 
  "slaby"              = "#ffff99",
  "umiarkowanie silny" = "#99cc00",
  "silny"              = "#99ccff",
  "bardzo silny"       = "#2f75b5")

# Etykiety legendy opadowej używane na rycinach: same przedziały w mm, bez opisu
# słownego. Jednostka podawana raz, przy drugiej liczbie (np. "5,0 - 9,9 mm").
# Używane w: wykresy/ryc_23.R, ryc_24.R i ryc_26.R (legendy) oraz ryc_28.R (podpisy faset).
dni_charakterystyczne_opad_etykiety_mm = c(
  "bardzo slaby"       = "0,1 - 0,9 mm",
  "slaby"              = "1,0 - 4,9 mm",
  "umiarkowanie silny" = "5,0 - 9,9 mm",
  "silny"              = "10,0 - 19,9 mm",
  "bardzo silny"       = "powyżej 20 mm")

# Używane w: wykresy/ryc_22.R, ryc_24.R i ryc_25.R (legendy). Rycina 27 podpisuje
# fasety wariantem z kryteriami - patrz koniec pliku.
dni_charakterystyczne_temp_etykiety =
  c("bardzo upalne"  = "bardzo upalne",
    "upalne"         = "upalne",
    "gorace"         = "gorące",
    "przymrozkowe"   = "przymrozkowe",
    "mrozne"         = "mroźne",
    "bardzo mrozne"  = "bardzo mroźne")

# JEDYNE miejsce, w którym opisano elementy meteorologiczne. Każdy symbol ma tu
# dokładnie jeden opis i wszystkie objaśnienia w raporcie oraz w arkuszu
# wyniki/a1_tabele.xlsx są z niego składane, więc ten sam symbol jest wszędzie
# opisany identycznie. Nowy element albo poprawkę opisu wpisujemy TUTAJ, a nie
# w poszczególnych blokach objaśnień.
#
# Treść opisów odpowiada tabeli 6.1.1 metodyk ZMŚP (jej dosłowne brzmienie cytuje
# osobna kolumna arkusza, budowana z parametry_metodyka w zapis_tabel.R). Wysokość
# lub głębokość pomiaru zostaje w nawiasie, bo odróżnia elementy mierzone tym samym
# przyrządem na różnych poziomach.
#
# Opis mówi, CZYM JEST element, i niczego więcej nie dopowiada. Statystyki ("suma
# miesięczna", "średnia roczna") w objaśnieniach nie ma: wynika ona z tabeli, w której
# element stoi, a dopisywana po przecinku zlewałaby się z przecinkami rozdzielającymi
# pozycje listy - "usłonecznienie, suma miesięczna, SOL_T [W·m²] - ..." czytałoby się
# jak trzy pozycje zamiast dwóch.
#
# Kolejność ma znaczenie: wyznacza poziomy faktora elementów, czyli układ paneli
# rycin 29 i 30. Idzie od temperatury powietrza przez grunt do pozostałych
# elementów - tak jak w tabeli 1.
# Używany w: przetwarzanie_danych.R (kolumna Uwagi tabeli 1 oraz kolejność elementów
# na rycinach 29 i 30), zapis_tabel.R (arkusz Objaśnienia) i opis_elementow_txt() niżej;
# do sesji Quarto trafia przez dane/dane_all.RData.
opisy_elementow = c(
  "TA_D"   = "temperatura powietrza (2 m)",
  "TA_N"   = "minimalna temperatura powietrza (2 m)",
  "TA_X"   = "maksymalna temperatura powietrza (2 m)",
  "TA_G"   = "minimalna temperatura przy gruncie (5 cm)",
  "T_S 5"  = "temperatura gruntu na głębokości 5 cm",
  "T_S 10" = "temperatura gruntu na głębokości 10 cm",
  "T_S 20" = "temperatura gruntu na głębokości 20 cm",
  "T_S 50" = "temperatura gruntu na głębokości 50 cm",
  "HH"     = "wilgotność względna powietrza (2 m)",
  "RR_T"   = "opad atmosferyczny",
  "SC_H"   = "grubość pokrywy śnieżnej",
  "WIV"    = "prędkość wiatru (10 m)",
  "SOL_P"  = "usłonecznienie",
  "SOL_T"  = "natężenie promieniowania słonecznego",
  "PRES"   = "ciśnienie atmosferyczne (zredukowane do poziomu morza)"
)

# Jednostka jest cechą elementu, a nie tabeli, więc stoi obok opisu - dzięki temu
# w objaśnieniach symbol wygląda tak samo jak w nagłówku tabeli, w której występuje.
# Używany w: opis_elementow_txt() niżej - to jedyne miejsce, w którym jest czytany.
jednostki_elementow = c(
  "TA_D" = "[°C]", "TA_N" = "[°C]", "TA_X" = "[°C]", "TA_G" = "[°C]",
  "T_S 5" = "[°C]", "T_S 10" = "[°C]", "T_S 20" = "[°C]", "T_S 50" = "[°C]",
  "HH" = "[%]", "RR_T" = "[mm]", "SC_H" = "[cm]", "WIV" = "[m·s⁻¹]",
  "SOL_P" = "[h]", "SOL_T" = "[W·m²]", "PRES" = "[hPa]"
)

# Gotowa lista "SYMBOL [jednostka] - opis, ..." do bloków objaśnień pod tabelami
# i rycinami. Domyślnie wszystkie elementy; tabela lub rycina pokazująca tylko część
# podaje swój zestaw symboli, żeby nie objaśniać czegoś, czego na niej nie ma.
# Pozycje rozdziela ŚREDNIK, a nie przecinek: pod tabelą 1 opis niesie jeszcze
# statystykę dopisaną po przecinku i przy przecinkowej liście "usłonecznienie, suma
# miesięczna, SOL_T [W·m²] - ..." czytałoby się jak trzy pozycje zamiast dwóch.
# Ten sam separator we wszystkich blokach, żeby objaśnienia wyglądały jednakowo.
# Używana w: tworzenie_raportu.qmd (bloki objaśnień pod tabelami 5, 8, 9 i 10 oraz
# pod rycinami 29 i 30). Sesja Quarto nie wczytuje tego pliku - funkcja i oba słowniki
# trafiają do niej przez dane/dane_all.RData (lista obiektów w uruchamianie_skryptow.R).
opis_elementow_txt = function(symbole = names(opisy_elementow)) {
  paste(paste0(symbole, " ", jednostki_elementow[symbole], " - ", opisy_elementow[symbole]),
        collapse = "; ")
}


# Etykiety z kryterium wyznaczenia w nawiasie - używane na paskach faset ryciny 27,
# gdzie sama nazwa kategorii nie mówi, jaki próg temperatury o niej decyduje.
# Kryteria muszą być zgodne z tabelą 8 (tab8_nazwy_wierszy w przetwarzanie_danych.R).
# Używane w: wykresy/ryc_27.R (podpisy faset).
dni_charakterystyczne_temp_etykiety_kryteria =
  c("bardzo upalne"  = "bardzo upalne\n(TA_X > 35°C)",
    "upalne"         = "upalne\n(TA_X > 30°C)",
    "gorace"         = "gorące\n(TA_X > 25°C)",
    "przymrozkowe"   = "przymrozkowe\n(TA_N < 0°C)",
    "mrozne"         = "mroźne\n(TA_X < 0°C)",
    "bardzo mrozne"  = "bardzo mroźne\n(TA_N < -10°C)")
