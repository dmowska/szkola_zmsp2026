################################################################################
# OPIS SKRYPTU
################################################################################
# funkcje/slownik_stacji.R - stacje bazowe ZMŚP i źródło danych okresu referencyjnego
#
# Dla każdego identyfikatora stacji bazowej podaje jej pełną nazwę oraz źródło
# danych, z których wyznaczono okres referencyjny 1991-2020. Nazwa stacji bazowej
# trafia do tytułu raportu, podpisów rycin i tytułów tabel; źródło okresu
# referencyjnego - do podpisów rycin 20 i 21 oraz tytułów tabel 6 i 7, czyli
# wszędzie tam, gdzie raport odwołuje się do okresu referencyjnego.
#
# Uwagi do kodu:
# Jedna ramka zamiast dwóch wektorów nazwanych: obie wartości stoją w tym samym
# wierszu, więc nie da się ich rozjechać przy dopisywaniu kolejnej stacji.
# Wyszukiwanie idzie przez match() po kolumnie kod - nieznany identyfikator daje
# wiersz samych NA, a pobieranie_danych.R nie przerywa wtedy pracy: podstawia
# wartości zastępcze i zgłasza ostrzeżenie.
#
# Kolumna zrodlo_ref niesie GOTOWY FRAGMENT ZDANIA, a nie samą nazwę stacji.
# W podpisie stoi po frazie "wyznaczonego na podstawie danych", więc daje zdanie
# "...na podstawie danych ze stacji IMGW Suwałki". Osobna kolumna z samą nazwą
# stacji IMGW nie wystarczy: trzy stacje bazowe (Parsęta, Beskid Niski, Pogórze
# Karpackie) mają własną serię 1991-2020 i nie korzystają z danych IMGW, więc
# nie ma czego w niej wpisać.
#
# Te trzy stacje mają w zrodlo_ref sam znacznik "własne". Pełną frazę
# "ze Stacji Bazowej ZMŚP <nazwa>" składa z niego pobieranie_danych.R - nazwa
# stacji stoi wtedy w podpisie raz, wzięta z kolumny nazwa, i nie da się jej
# rozjechać z nazwą użytą w pierwszej połowie tego samego podpisu.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - brak - plik nie korzysta z żadnych obiektów zewnętrznych
################################################################################
# WYNIK
################################################################################
# - slownik_stacji: ramka danych o kolumnach
#     kod        - identyfikator stacji bazowej ZMŚP, np. "06ZM"
#     nazwa      - pełna nazwa stacji bazowej, np. "Parsęta"
#     zrodlo_ref - źródło danych okresu referencyjnego: fragment zdania
#                  "ze stacji IMGW Suwałki" albo znacznik "własne"
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - brak (plik nie wywołuje funkcji spoza R base)
################################################################################

slownik_stacji = data.frame(
  kod = c("01ZM", "05ZM", "06ZM", "07ZM", "08ZM", "09ZM",
          "10ZM", "11ZM", "12ZM", "13ZM", "14ZM", "15ZM"),
  nazwa = c("Puszcza Borecka", "Wigry", "Parsęta", "Pojezierze Chełmińskie",
            "Kampinos", "Łysogóry", "Beskid Niski", "Wolin", "Roztocze",
            "Poznań Morasko", "Karkonosze", "Pogórze Karpackie"),
  zrodlo_ref = c("ze stacji IMGW Suwałki",         # 01ZM Puszcza Borecka
                 "ze stacji IMGW Suwałki",         # 05ZM Wigry
                 "własne",                         # 06ZM Parsęta
                 "ze stacji IMGW Toruń",           # 07ZM Pojezierze Chełmińskie
                 "ze stacji IMGW Legionowo",       # 08ZM Kampinos
                 "ze stacji IMGW Święty Krzyż",    # 09ZM Łysogóry
                 "własne",                         # 10ZM Beskid Niski
                 "ze stacji IMGW Świnoujście",     # 11ZM Wolin
                 "ze stacji IMGW Lublin-Radawiec", # 12ZM Roztocze
                 "ze stacji IMGW Poznań",          # 13ZM Poznań Morasko
                 "ze stacji IMGW Jelenia Góra",    # 14ZM Karkonosze (st. 002)
                 "własne"),                        # 15ZM Pogórze Karpackie
  stringsAsFactors = FALSE
)
