################################################################################
# OPIS SKRYPTU
################################################################################
# funkcje/plot_theme.R - wspólny motyw rycin
#
# Definiuje motyw nadawany wszystkim rycinom raportu: krój Times New Roman, ramka
# panelu, jasna siatka, jednolite rozmiary czcionek i legenda pod wykresem.
#
# Uwagi do kodu:
# Motyw jest funkcją, a nie obiektem, żeby każde wywołanie zwracało świeżą kopię
# - wspólny obiekt motywu byłby modyfikowany przez kolejne ryciny.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - brak - plik nie korzysta z żadnych obiektów zewnętrznych
################################################################################
# WYNIK
################################################################################
# - plot_theme: funkcja zwracająca motyw ggplot2
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
################################################################################

plot_theme = function() {
  theme_linedraw() %+replace%
    theme(
      text = element_text(family = "serif", size = 12, colour = "black"),
      panel.background = element_rect(fill = NA, colour = NA),
      # ramka panelu i sama siatka główna - siatka pomocnicza zagęszczałaby wykres
      panel.border = element_rect(colour = "black", fill = NA),
      panel.grid.major = element_line(colour = "grey60", linewidth = 0.2),
      panel.grid.minor = element_blank(),
      # jednakowa wielkość czcionki we wszystkich elementach opisu
      axis.text = element_text(size = 12),
      axis.title = element_text(size = 12),
      legend.title = element_text(size = 12),
      legend.text = element_text(size = 12),
      plot.title = element_text(size = 12, face = "bold"),
      legend.position = "bottom",
      legend.margin = margin(t = -1),    # Ujemny margines górny legendy (przyciąga ją do osi)
      legend.box.spacing = unit(0, "pt"),  # Zredukowanie przestrzeni między obszarem wykresu a legendą
      plot.margin = margin(b = 5, t = 5, l = 5, r = 5) # Opcjonalnie: ogólne marginesy wykresu
    )
}

