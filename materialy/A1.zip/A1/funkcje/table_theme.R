################################################################################
# OPIS SKRYPTU
################################################################################
# funkcje/table_theme.R - wspólny wygląd tabel
#
# Definiuje formatowanie nadawane tabelom raportu: przecinek jako separator
# dziesiętny, wyśrodkowanie, krój Times New Roman, pełne linie siatki i
# zmniejszone marginesy komórek.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - brak - plik nie korzysta z żadnych obiektów zewnętrznych
################################################################################
# WYNIK
################################################################################
# - table_theme: funkcja przyjmująca i zwracająca obiekt flextable
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - flextable
################################################################################

table_theme = function(ft) {
  ft |>
    colformat_num(big.mark = "", decimal.mark = ",",na_str = "") |> # przecinek jako znak dziesiętny
    align(part = "all", align = "center") |> # wypośrodkowanie nagłówków
    font(fontname = "Times New Roman", part = "all") |>
    # dodanie pionowych i poziomych linii
    border_outer(part = "all") |>
    border_inner_h(part = "all") |>
    border_inner_v(part = "all") |>
    padding(padding.left = 0.5, padding.right = 0.5) # zmniejszenie marginesów
}