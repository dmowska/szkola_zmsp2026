################################################################################
# OPIS SKRYPTU
################################################################################
# tworzenie_wykresow.R - wygenerowanie i zapis rycin
#
# Uruchamia po kolei wszystkie skrypty z katalogu wykresy/, a powstałe obiekty
# rycin zapisuje do plików PNG i SVG w katalogu wyniki/.
#
# Uwagi do kodu:
# Pliki są źródłowane w kolejności alfabetycznej nazw, więc ryc_10 wykonuje się
# przed ryc_2 - żaden skrypt ryciny nie może polegać na obiekcie tworzonym przez
# inny. Domyślny rozmiar zapisu to 8x5 cala; odstępstwa zbiera lista wymiary,
# dzięki czemu nie trzeba ich powtarzać przy każdym wywołaniu ggsave.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - wykresy/ryc_*.R: skrypty rycin, po jednym na rycinę
# - obiekty danych utworzone przez przetwarzanie_danych.R, z których
#     korzystają skrypty rycin
################################################################################
# WYNIK
################################################################################
# - ryc_1 ... ryc_30: obiekty rycin w środowisku, używane potem przez
#     tworzenie_raportu.qmd
# - wyniki/png/ryc_*.png oraz wyniki/svg/ryc_*.svg: ryciny zapisane do
#     plików
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
################################################################################

source("funkcje/plot_theme.R")

# Skrypty rycin. Filtr po rozszerzeniu jest istotny: bez niego pętla próbowałaby
# wykonać każdy plik leżący w katalogu, także notatkę czy kopię zapasową.
pliki_wykresy = list.files("wykresy", pattern = "\\.R$")

for (plik in pliki_wykresy) {
  source(file.path("wykresy", plik))
}

# Ryciny wymagające innego rozmiaru niż domyślne 8 x 5 cala (szerokość, wysokość).
wymiary <- list(
  ryc_4  = c(8, 6.5),
  ryc_21 = c(8, 5.5),
  ryc_25 = c(8, 7),
  ryc_26 = c(8, 7),
  # Ryciny 29 i 30 mają po jednej fasecie na element meteorologiczny, po trzy rzędy
  # paneli każda.
  ryc_29 = c(8, 7),
  ryc_30 = c(8, 7)
)

# Zapis w obu formatach jedną pętlą. Nazwa obiektu bierze się z nazwy pliku:
# ryc_15.R -> obiekt ryc_15 -> wyniki/png/ryc_15.png i wyniki/svg/ryc_15.svg.
for (format in c("png", "svg")) {
  katalog = file.path("wyniki", format)
  if (!dir.exists(katalog)) dir.create(katalog, showWarnings = FALSE, recursive = TRUE)

  for (plik in pliki_wykresy) {
    nazwa_obiektu = sub("\\.R$", "", plik)
    # Rycina bez danych jest NULL (skrypty ryc_*.R) - nie ma czego zapisywać,
    # a ggsave przerwałby pracę na "plot should be a ggplot object".
    if (is.null(get(nazwa_obiektu))) next
    wym = if (!is.null(wymiary[[nazwa_obiektu]])) wymiary[[nazwa_obiektu]] else c(8, 5)
    ggsave(file.path(katalog, paste0(nazwa_obiektu, ".", format)),
           get(nazwa_obiektu), width = wym[1], height = wym[2], dpi = 300)
  }
}
