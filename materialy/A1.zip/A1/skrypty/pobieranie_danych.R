################################################################################
# OPIS SKRYPTU
################################################################################
# pobieranie_danych.R - pobranie danych z bazy ZMŚP
#
# Wczytuje parametry raportu, łączy się z bazą ZMŚP i pobiera dziewięć widoków
# ograniczonych do wybranej stacji. Widoki wraz z parametrami zapisuje do pliku
# dane/dane.RData, z którego korzysta przetwarzanie_danych.R.
#
# Uwagi do kodu:
# Dane dostępowe do bazy nigdy nie trafiają do kodu - skrypt czyta je ze
# zmiennych środowiskowych z pliku .Renviron (wzór: .Renviron.example) i
# przerywa działanie z czytelnym komunikatem, gdy brakuje pliku parametrów albo
# hasła. Każde zapytanie zawęża widok do jednej stacji, więc dalsze skrypty nie
# muszą już filtrować po stacji.
# Po pobraniu skrypt sprawdza, czego baza nie ma za rok analizowany, i wymienia to
# w jednym ostrzeżeniu - raport powstaje wtedy bez tych elementów. Pracę przerywa
# tylko stacja bez żadnych danych albo wielolecie rozłączne z danymi stacji.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - parametry/parametry.xlsx: kod stacji bazowej, analizowany rok oraz
#     pierwszy i ostatni rok wielolecia
# - .Renviron: dane dostępowe do bazy (ZMSP_DB_USER, ZMSP_DB_PASSWORD,
#     ZMSP_DB_HOST, ZMSP_DB_PORT, ZMSP_DB_NAME)
# - slownik_stacji: ramka z nazwami stacji bazowych i źródłem danych okresu
#     referencyjnego (kod, nazwa, zrodlo_ref)
################################################################################
# WYNIK
################################################################################
# - dane/dane.RData: dziewięć widoków a1_*_vw oraz parametry raportu
# - stacja, nazwa_stacji, zrodlo_okresu_ref, analizowany_rok, rok_poczatek,
#     rok_koniec: parametry dostępne w środowisku
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - readxl
# - RPostgres
################################################################################

# 1. WCZYTANIE PARAMETRÓW
if(!file.exists("parametry/parametry.xlsx")) stop("Brak pliku parametry/parametry.xlsx!")

parametry <- read_excel("parametry/parametry.xlsx")
stacja       <- parametry$wartosc[parametry$parametr == 'kod stacji bazowej']
analizowany_rok  <- as.integer(parametry$wartosc[parametry$parametr == 'analizowany rok'])
rok_poczatek <- as.integer(parametry$wartosc[parametry$parametr == 'rok początkowy'])
rok_koniec   <- as.integer(parametry$wartosc[parametry$parametr == 'rok końcowy'])

# Jeden wiersz słownika niesie nazwę stacji bazowej i źródło danych, z których
# wyznaczono jej okres referencyjny (stacja IMGW albo seria własna stacji bazowej).
# Nieznany kod daje wiersz samych NA.
wiersz_stacji     <- slownik_stacji[match(stacja, slownik_stacji$kod), ]
nazwa_stacji      <- wiersz_stacji$nazwa
zrodlo_okresu_ref <- wiersz_stacji$zrodlo_ref

# Zabezpieczenie na wypadek nieznanego kodu. Nazwą zastępczą stacji bazowej jest SAM
# KOD: w raporcie wartość ta stoi zawsze po frazie "w Stacji Bazowej ZMŚP", więc każdy
# dopisek dałby tam zdanie w rodzaju "w Stacji Bazowej ZMŚP Stacja 15ZM". Źródło okresu
# referencyjnego stoi w podpisach po frazie "wyznaczonego na podstawie danych", gdzie
# sam kod ZMŚP byłby mylący - stąd inna wartość zastępcza, domykająca zdanie.
if(is.na(nazwa_stacji)) {
  nazwa_stacji      <- stacja
  zrodlo_okresu_ref <- "z nieznanego źródła"
  warning("Nie rozpoznano kodu stacji ", stacja,
          " - w raporcie zamiast nazwy pojawi się sam kod, ",
          "a zamiast źródła okresu referencyjnego napis \"z nieznanego źródła\". ",
          "Uzupełnij funkcje/slownik_stacji.R.", call. = FALSE)
}

# Stacje z własną serią 1991-2020 mają w słowniku sam znacznik "własne" - pełną frazę
# składamy tutaj, z nazwy wziętej z tego samego wiersza. Gdyby stała gotowa w słowniku,
# poprawka nazwy stacji w kolumnie nazwa zostawiłaby w podpisie starą nazwę po frazie
# "na podstawie danych ze Stacji Bazowej ZMŚP".
if(zrodlo_okresu_ref == "własne") {
  zrodlo_okresu_ref <- paste0("ze Stacji Bazowej ZMŚP ", nazwa_stacji)
}

message(paste("   Wybrana stacja:", nazwa_stacji, "(", stacja, ")"))

# 2. POŁĄCZENIE Z BAZĄ DANYCH
message("   Łączenie z bazą danych ZMŚP...")

# Dane dostępowe są przechowywane poza skryptem, w pliku .Renviron
# (wzór: .Renviron.example). R wczytuje go automatycznie przy starcie sesji;
# poniższa linia zabezpiecza przypadek, gdy sesja została uruchomiona
# w innym katalogu roboczym.
if(Sys.getenv("ZMSP_DB_PASSWORD") == "" && file.exists(".Renviron")) readRenviron(".Renviron")

if(Sys.getenv("ZMSP_DB_PASSWORD") == "") {
  stop("Brak danych dostępowych do bazy! Utwórz plik .Renviron na wzór .Renviron.example i zrestartuj sesję R.")
}

# Błąd połączenia przechwytujemy, bo surowy komunikat sterownika jest po angielsku
# i nie mówi, co poprawić: "password authentication failed" i "could not connect to
# server" wymagają zupełnie różnych działań (hasło kontra dostęp sieciowy do portu).
# Oryginalny komunikat serwera zostaje w treści - bez niego nie da się odróżnić
# jednego przypadku od drugiego.
con <- tryCatch(
  dbConnect(RPostgres::Postgres(),
            user     = Sys.getenv("ZMSP_DB_USER"),
            password = Sys.getenv("ZMSP_DB_PASSWORD"),
            host     = Sys.getenv("ZMSP_DB_HOST"),
            port     = as.integer(Sys.getenv("ZMSP_DB_PORT")),
            dbname   = Sys.getenv("ZMSP_DB_NAME")),
  error = function(e) {
    stop("Nie udało się połączyć z bazą danych ZMŚP (SIMSP).\n",
         "  Komunikat serwera: ", conditionMessage(e),
         "  Sprawdź kolejno:\n",
         "  1. login i hasło w pliku .Renviron (ZMSP_DB_USER i ZMSP_DB_PASSWORD) -",
         " każda stacja ma własne konto;\n",
         "  2. czy po zmianie .Renviron sesja R została zrestartowana",
         " (Session -> Restart R) - R czyta ten plik tylko przy starcie;\n",
         "  3. połączenie z internetem oraz dostęp do serwera ",
         Sys.getenv("ZMSP_DB_HOST"), " na porcie ", Sys.getenv("ZMSP_DB_PORT"),
         " - w sieci instytucjonalnej bywa zablokowany i potrzebny jest VPN",
         " albo zgłoszenie do działu IT.",
         call. = FALSE)
  })


# 3. POBIERANIE DANYCH
message("   Pobieranie widoków danych...")

# Wszystkie widoki pobieramy jedną funkcją: warunek WHERE stoi wtedy w jednym
# miejscu i nie może rozjechać się między dziewięcioma zapytaniami.
# Widoki oddają jedno stanowisko na stację, więc zawężenie do kodu stacji wystarcza:
# dalsze skrypty dostają dokładnie jeden wiersz na (rok, miesiąc).
pobierz_widok <- function(widok) {
  dbGetQuery(con, paste0("SELECT * FROM raportowanie.", widok,
                         " WHERE stacja = '", stacja, "';"))
}

a1_dane_dobowe_vw                 <- pobierz_widok("a1_dane_dobowe_vw")
a1_dane_agg_vw                    <- pobierz_widok("a1_dane_agg_vw")
a1_dane_wieloletnie_dobowe_vw     <- pobierz_widok("a1_dane_wieloletnie_dobowe_vw")
a1_dni_charakterystyczne_opady_vw <- pobierz_widok("a1_dni_charakterystyczne_opady_vw")
a1_dni_charakterystyczne_temp_vw  <- pobierz_widok("a1_dni_charakterystyczne_temp_vw")

a1_klasyfikacja_opadowa_vw        <- pobierz_widok("a1_klasyfikacja_opadowa_vw")
a1_klasyfikacja_termiczna_vw      <- pobierz_widok("a1_klasyfikacja_termiczna_vw")
a1_pokrywa_sniezna_vw             <- pobierz_widok("a1_pokrywa_sniezna_vw")
a1_wiatr_dobowe_vw                <- pobierz_widok("a1_wiatr_dobowe_vw")

dbDisconnect(con)
message("   Połączenie z bazą zakończone.")


# 4. KONTROLA I DOPASOWANIE PARAMETRÓW
# Trzy sytuacje, trzy sposoby postępowania:
#
#  - STACJA BEZ ŻADNYCH DANYCH (zagregowanych, dobowych i wiatru) - jedyny przypadek,
#    w którym przerywamy pracę: z niczego nie da się złożyć raportu, a zmiana roku
#    w parametrach nic tu nie pomoże.
#
#  - ROK ANALIZOWANY (albo jego miesiące) nieobecny w części widoków - baza pomija
#    lata i miesiące zakwestionowane, a widoki dobowe mają rok wpisany na sztywno
#    w definicji. Raport i tak powstaje: tabele i ryciny pomijają to, czego nie ma.
#    Użytkownik musi jednak wiedzieć, których elementów zabraknie, dlatego jedno
#    ostrzeżenie wymienia je wprost.
#
#  - WIELOLECIE zawężamy do tego, co jest w bazie, i liczymy analizę dla takiego
#    okresu. Użytkownik nie musi znać zakresu danych swojej stacji: gdy poda
#    1990-2024, a stacja ma dane od 2010, analiza obejmie 2010-2024. Zawężenie jest
#    widoczne w raporcie, bo rok_poczatek i rok_koniec trafiają do tytułów i podpisów
#    tabel oraz rycin. Wielolecie rozłączne z danymi to błąd parametrów - przerywamy.
#
# rok_hydro jest tu jeszcze tekstem - konwersję na liczby robi przetwarzanie_danych.R.
if (rok_poczatek > rok_koniec) {
  stop("Wielolecie w parametry.xlsx jest puste: rok początkowy (", rok_poczatek,
       ") jest późniejszy niż końcowy (", rok_koniec, ").", call. = FALSE)
}

if (nrow(a1_dane_agg_vw) == 0 && nrow(a1_dane_dobowe_vw) == 0 && nrow(a1_wiatr_dobowe_vw) == 0) {
  stop("Baza nie zawiera żadnych danych A1 dla stacji ", nazwa_stacji, " (", stacja, ").",
       "\n  Raportu nie da się przygotować dla żadnego roku - zmiana roku",
       " w parametry/parametry.xlsx nie pomoże.",
       "\n  Sprawdź kod stacji w parametry.xlsx, a jeśli jest poprawny, zgłoś brak",
       " danych opiekunowi bazy.", call. = FALSE)
}

# Lata obecne w widoku (dla widoków z typem okresu - tylko wiersze danego typu).
lata_widoku <- function(widok, typ = NULL) {
  wiersze <- if (is.null(typ)) widok else widok[widok$okres_typ %in% typ, , drop = FALSE]
  sort(unique(as.integer(wiersze$rok_hydro)))
}

braki <- character(0)
if (!analizowany_rok %in% lata_widoku(a1_dane_dobowe_vw)) {
  braki <- c(braki, paste0(
    "danych dobowych (a1_dane_dobowe_vw) - ryciny 1-5, 10-14 i 24 nie powstaną,",
    " a w tabelach 9 i 10 zjawiska liczone z danych dobowych zostaną puste"))
}
if (!analizowany_rok %in% lata_widoku(a1_wiatr_dobowe_vw)) {
  braki <- c(braki, paste0(
    "dobowych danych o wietrze (a1_wiatr_dobowe_vw) - tabele 2 i 3 zostaną pominięte,",
    " a rycina 6 nie powstanie"))
}
if (!analizowany_rok %in% lata_widoku(a1_dane_agg_vw, "RH")) {
  braki <- c(braki, paste0(
    "danych rocznych (a1_dane_agg_vw) - w tabeli 1 kolumna XI-X i w tabeli 4",
    " kolumna roku zostaną puste, a tabela 5 i ryciny 15-20 nie obejmą tego roku"))
}
miesiace_roku <- a1_dane_agg_vw$miesiac[a1_dane_agg_vw$okres_typ == "M" &
                                        as.integer(a1_dane_agg_vw$rok_hydro) == analizowany_rok]
brakujace_miesiace <- setdiff(c(11, 12, 1:10), as.integer(miesiace_roku))
if (length(brakujace_miesiace) == 12) {
  braki <- c(braki, paste0(
    "danych miesięcznych (a1_dane_agg_vw) - tabela 4 zostanie pominięta, ryciny 7-9",
    " nie powstaną, a ryciny 15, 16, 29 i 30 nie obejmą tego roku"))
} else if (length(brakujace_miesiace) > 0) {
  braki <- c(braki, paste0(
    "danych miesięcznych za miesiące: ",
    paste(as.character(as.roman(brakujace_miesiace)), collapse = ", "),
    " - tabele i ryciny miesięczne pominą te miesiące"))
}
if (!analizowany_rok %in% lata_widoku(a1_dni_charakterystyczne_temp_vw, c("M", "RH"))) {
  braki <- c(braki, paste0(
    "dni charakterystycznych (a1_dni_charakterystyczne_*_vw) - w tabeli 8 kolumny",
    " roku zostaną puste, ryciny 22 i 23 nie powstaną, a ryciny 25 i 26 stracą",
    " panel z miesiącami roku"))
}
if (!analizowany_rok %in% lata_widoku(a1_klasyfikacja_termiczna_vw, "RH")) {
  braki <- c(braki, paste0(
    "klasyfikacji termicznej i opadowej (a1_klasyfikacja_*_vw) - tabele 6 i 7 oraz",
    " rycina 21 nie obejmą tego roku"))
}

if (length(braki) > 0) {
  warning("Baza nie zawiera za rok hydrologiczny ", analizowany_rok, " (stacja ",
          stacja, "):\n  - ", paste(braki, collapse = ";\n  - "), ".",
          "\n  Raport powstanie bez tych elementów. Dane roczne są dostępne dla lat: ",
          zakres_lat(lata_widoku(a1_dane_agg_vw, "RH")), ".", call. = FALSE)
}

# Zawężenie wielolecia do lat faktycznie obecnych w danych zagregowanych - rocznych
# albo miesięcznych, bo baza pomija rok zakwestionowany niezależnie w każdym typie
# okresu. Granice tylko przycinamy - nigdy nie rozszerzamy poza to, o co poprosił
# użytkownik. Ewentualne luki w środku zakresu zostają: filtry po prostu nie znajdą
# dla nich wierszy, a tabele i ryciny pominą te lata.
lata_agg <- lata_widoku(a1_dane_agg_vw, c("RH", "M"))
lata_w_wieloleciu <- lata_agg[lata_agg >= rok_poczatek & lata_agg <= rok_koniec]

if (length(lata_w_wieloleciu) == 0) {
  stop("Wielolecie podane w parametry.xlsx (", rok_poczatek, "-", rok_koniec,
       ") nie pokrywa się z danymi stacji.",
       "\n  Dane zagregowane są dostępne dla lat: ", zakres_lat(lata_agg), ".",
       "\n  Popraw w parametry.xlsx wiersze 'rok początkowy' i 'rok końcowy'.",
       call. = FALSE)
}

rok_poczatek <- min(lata_w_wieloleciu)
rok_koniec   <- max(lata_w_wieloleciu)

rm(lata_widoku, braki, miesiace_roku, brakujace_miesiace, lata_agg, lata_w_wieloleciu)
message("   Wielolecie użyte w analizie: ", rok_poczatek, "-", rok_koniec,
        ", rok analizowany: ", analizowany_rok, ".")


# 5. ZAPIS DANYCH DO PLIKU
message("   Zapisywanie danych do pliku 'dane/dane.RData'...")

save(
  # Dane z bazy
  a1_dane_dobowe_vw,
  a1_dane_agg_vw,
  a1_dane_wieloletnie_dobowe_vw,
  a1_dni_charakterystyczne_opady_vw,
  a1_dni_charakterystyczne_temp_vw,  
  a1_klasyfikacja_opadowa_vw,
  a1_klasyfikacja_termiczna_vw,
  a1_pokrywa_sniezna_vw,
  a1_wiatr_dobowe_vw,
  
  # Parametry konfiguracyjne
  stacja, 
  nazwa_stacji,
  zrodlo_okresu_ref,
  analizowany_rok, 
  rok_poczatek, 
  rok_koniec,
  
  file = "dane/dane.RData"
)

message(">>> [pobieranie_danych.R] Zakończono sukcesem.")