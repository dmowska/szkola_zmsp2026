################################################################################
# OPIS SKRYPTU
################################################################################
# zapis_tabel.R - eksport tabel 1-10 do pliku wyniki/a1_tabele.xlsx
#
# Zapisuje tabele w takiej postaci, w jakiej trafiają do raportu: te same wiersze,
# kolumny i nagłówki, a w tabelach 6 i 7 także te same kolory tła i czcionki.
# Każda tabela ląduje w osobnym arkuszu. Tabele 2, 3 i 4 bez danych za rok
# analizowany są pomijane - tak samo jak w raporcie.
#
# Uwagi do kodu:
# Trzy rzeczy odróżniają arkusz od raportu. Po pierwsze liczby zapisujemy jako
# LICZBY, a nie tekst, więc Excel pokazuje je z separatorem dziesiętnym ustawionym
# na komputerze użytkownika - w raporcie separator jest wpisany na stałe przecinkiem.
# Po drugie kropka, którą raport wstawia w miejsce braku danych, staje się pustą
# komórką. Po trzecie komórki tabeli 7 łączą dwie wartości ("5,0\n(2%)"), więc
# muszą zostać tekstem - to jedyne miejsce, gdzie liczby nie są liczbami.
# Kolumny bywają niejednorodne: w tabelach 1 i 8 wiersz "Data wystąpienia" jest
# tekstem, a pozostałe wiersze liczbami. Dlatego kolumna trafia do arkusza jako
# liczbowa tylko wtedy, gdy wszystkie jej wartości są liczbami; w przeciwnym razie
# zapisujemy ją komórka po komórce, zachowując typ każdej z osobna.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - tab_1_dane ... tab_10_dane: dane tabel przygotowane przez przetwarzanie_danych.R
# - naglowek_tab_1, naglowek_tab_8: układ nagłówka grupującego (lata kalendarzowe
#     miesięcy oraz wspólna grupa "Rok" dla podsumowań rocznych)
# - kolory_bg_temp, kolory_czcionka_temp: kolory komórek tabeli 6
# - kolory_bg_miesiace_opad, kolory_bg_lata_opad, kolory_czcionka_m_opad,
#     kolory_czcionka_r_opad: kolory komórek tabeli 7
# - tab_6_legenda, tab_7_legenda: opisy klas termicznych i opadowych
# - kolory_klasyfikacja_termiczna, kolory_klasyfikacja_opadowa: barwy klas w legendach
# - analizowany_rok, rok_poczatek, rok_koniec: podstawiane w objaśnieniach tabel 4 i 5
# - fmt_tab7_komorka: funkcja z funkcje/formatowanie_tabel.R, nadaje komórkom
#     tabeli 7 tę samą postać co w raporcie
################################################################################
# WYNIK
################################################################################
# - wyniki/a1_tabele.xlsx: do trzynastu arkuszy - dziesięć tabel, dwie legendy klas
#     (tabele 6 i 7) oraz objaśnienia symboli używanych w tabelach 1, 4 i 5
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - openxlsx
################################################################################

suppressWarnings(suppressMessages(library(openxlsx)))

# funkcje formatujące współdzielone z raportem (fmt_tab7_komorka)
source("funkcje/formatowanie_tabel.R")

# ------------------------------------------------------------------------------
# Funkcje pomocnicze
# ------------------------------------------------------------------------------

# Wartość komórki jako liczba albo NA. Akceptuje oba separatory dziesiętne, bo
# tabele przychodzą tu częściowo już sformatowane przecinkiem.
na_liczbe <- function(x) {
  x <- trimws(as.character(x))
  liczba <- grepl("^-?[0-9]+([.,][0-9]+)?$", x)
  wynik <- rep(NA_real_, length(x))
  wynik[liczba] <- as.numeric(gsub(",", ".", x[liczba]))
  wynik
}

# Puste komórki raportu: kropka, pusty napis i NA znaczą to samo - brak danych.
pusta <- function(x) {
  x <- trimws(as.character(x))
  is.na(x) | x %in% c("", ".", "NA")
}

# Wspólny wygląd komórek: krój i obramowanie jak w raporcie. Argumenty podane przy
# wywołaniu nadpisują domyślne, dzięki czemu ta sama funkcja obsługuje nagłówek,
# wyrównanie do lewej i kolory klas.
styl_ramka <- function(...) {
  domyslne <- list(fontName = "Times New Roman", fontSize = 9,
                   border = "TopBottomLeftRight", borderColour = "black",
                   halign = "center", valign = "center", wrapText = TRUE)
  do.call(createStyle, modifyList(domyslne, list(...)))
}

# ------------------------------------------------------------------------------
# Zapis jednej tabeli do arkusza
# ------------------------------------------------------------------------------
# dane            - ramka z zawartością tabeli (bez wiersza nagłówka)
# naglowek        - podpisy kolumn
# naglowek_grupy  - opcjonalny wiersz nadrzędny: data.frame(grupa, kolumn) jak
#                   naglowek_tab_1; pierwsza kolumna zostaje wtedy scalona pionowo
# tlo, czcionka   - macierze kolorów dla kolumn 2:n (tabele 6 i 7)
# cyfry           - liczba miejsc po przecinku wymuszona na liczbach. Jedna wartość
#                   dotyczy całej tabeli, wektor - kolejnych kolumn (NA = format
#                   ogólny). Bez tego w jednej kolumnie sąsiadowałyby "19,9" i "6"
# wys_naglowka   - wysokość wiersza nagłówka; dłuższe podpisy zawijają się na kilka
#                  linii, a bez jawnej wysokości nachodzą na wiersz z danymi
# wys_wiersza    - wysokość wierszy danych; potrzebna tam, gdzie komórka ma dwie
#                  linie (tabela 7: opad w mm i procent normy pod spodem)
# szerokosc      - szerokość kolumn z danymi
# kol_etykiet    - ile pierwszych kolumn opisuje wiersze, a nie niesie danych.
#                  Tabela 1 ma dwie takie kolumny (symbol i jego objaśnienie),
#                  pozostałe po jednej. Nagłówek grupujący zaczyna się dopiero za nimi.
# szerokosc_1    - szerokość kolumn etykiet: jedna liczba albo wektor
# wiersze_calkowite - numery wierszy danych, w których liczby są licznikami i mają
#                  zostać bez miejsc po przecinku mimo formatu reszty tabeli
#                  (wiersz "n" w tabeli 5: liczba lat, a nie wartość elementu)
dodaj_tabele <- function(wb, arkusz, dane, naglowek, naglowek_grupy = NULL,
                         tlo = NULL, czcionka = NULL, cyfry = NULL,
                         pogrub_ostatni = FALSE, szerokosc_1 = 22,
                         szerokosc = 9, wys_naglowka = 30, wys_wiersza = NULL,
                         kol_etykiet = 1, wiersze_calkowite = NULL) {
  addWorksheet(wb, arkusz)

  wiersz_naglowka <- if (is.null(naglowek_grupy)) 1L else 2L
  pierwszy_wiersz <- wiersz_naglowka + 1L
  n_kol <- ncol(dane)

  # nagłówek nadrzędny: podpis grupy nad odpowiadającymi jej kolumnami
  if (!is.null(naglowek_grupy)) {
    od <- kol_etykiet + 1L
    for (i in seq_len(nrow(naglowek_grupy))) {
      do <- od + naglowek_grupy$kolumn[i] - 1L
      writeData(wb, arkusz, naglowek_grupy$grupa[i], startCol = od, startRow = 1)
      if (do > od) mergeCells(wb, arkusz, cols = od:do, rows = 1)
      od <- do + 1L
    }
    # podpisy kolumn etykiet scalone pionowo przez oba wiersze nagłówka
    for (j in seq_len(kol_etykiet)) {
      writeData(wb, arkusz, naglowek[j], startCol = j, startRow = 1)
      mergeCells(wb, arkusz, cols = j, rows = 1:2)
    }
  }

  writeData(wb, arkusz, as.list(naglowek), startCol = 1, startRow = wiersz_naglowka,
            colNames = FALSE)

  # Kolumna liczbowa idzie do arkusza w całości; niejednorodna - komórka po komórce,
  # żeby liczba została liczbą, a tekst tekstem.
  for (j in seq_len(n_kol)) {
    kol <- as.character(dane[[j]])
    kol[pusta(kol)] <- NA
    liczby <- na_liczbe(kol)
    if (all(is.na(kol) | !is.na(liczby))) {
      writeData(wb, arkusz, liczby, startCol = j, startRow = pierwszy_wiersz, colNames = FALSE)
    } else {
      for (i in seq_along(kol)) {
        wartosc <- if (!is.na(liczby[i])) liczby[i] else kol[i]
        if (!is.na(wartosc)) {
          writeData(wb, arkusz, wartosc, startCol = j, startRow = pierwszy_wiersz + i - 1L)
        }
      }
    }
  }

  n_wierszy <- nrow(dane)
  wiersze_danych <- pierwszy_wiersz:(pierwszy_wiersz + n_wierszy - 1L)

  addStyle(wb, arkusz, styl_ramka(textDecoration = "bold", fgFill = "#F2F2F2"),
           rows = 1:wiersz_naglowka, cols = 1:n_kol, gridExpand = TRUE)
  # Format bez miejsc po przecinku to samo "0": zapis "0." zostawia w komórce
  # separator dziesiętny bez cyfr po nim, przez co rok 1995 pokazywałby się
  # w kolumnie z latami jako "1995,".
  format_liczby <- function(c) {
    if (is.na(c)) "GENERAL" else if (c == 0) "0" else paste0("0.", strrep("0", c))
  }
  cyfry_kol <- if (is.null(cyfry)) rep(NA_real_, n_kol) else rep_len(cyfry, n_kol)
  # Kolumny etykiet niosą lata, nazwy parametrów, kierunki wiatru lub objaśnienia.
  # Rok ma zostać liczbą całkowitą, więc nie dziedziczy formatu z reszty tabeli:
  # przy cyfry = 1 wyświetlałby się jako "1995,0".
  cyfry_kol[seq_len(kol_etykiet)] <- 0

  for (j in seq_len(n_kol)) {
    addStyle(wb, arkusz,
             styl_ramka(numFmt = format_liczby(cyfry_kol[j]),
                        halign = if (j <= kol_etykiet) "left" else "center"),
             rows = wiersze_danych, cols = j, gridExpand = TRUE)
  }

  # Wiersze z licznikami nadpisują format kolumn: "30" zamiast "30,0".
  if (!is.null(wiersze_calkowite) && length(wiersze_calkowite)) {
    wiersze_n <- pierwszy_wiersz + wiersze_calkowite - 1L
    addStyle(wb, arkusz, styl_ramka(numFmt = format_liczby(0), halign = "left"),
             rows = wiersze_n, cols = seq_len(kol_etykiet), gridExpand = TRUE)
    addStyle(wb, arkusz, styl_ramka(numFmt = format_liczby(0), halign = "center"),
             rows = wiersze_n, cols = (kol_etykiet + 1):n_kol, gridExpand = TRUE)
  }

  # kolory komórek - tabele klasyfikacyjne. Jeden styl na każdą kombinację barw,
  # bo openxlsx przypisuje styl do zakresu komórek, a nie do pojedynczej wartości.
  if (!is.null(tlo)) {
    czcionka <- if (is.null(czcionka)) matrix("black", nrow(tlo), ncol(tlo)) else czcionka
    pary <- unique(data.frame(bg = as.vector(tlo), fg = as.vector(czcionka)))
    for (k in seq_len(nrow(pary))) {
      wybor <- which(tlo == pary$bg[k] & czcionka == pary$fg[k], arr.ind = TRUE)
      addStyle(wb, arkusz,
               styl_ramka(fgFill = pary$bg[k], fontColour = pary$fg[k],
                          numFmt = format_liczby(cyfry_kol[2])),
               rows = pierwszy_wiersz + wybor[, "row"] - 1L,
               cols = kol_etykiet + wybor[, "col"], gridExpand = FALSE)
    }
  }

  if (pogrub_ostatni) {
    addStyle(wb, arkusz, styl_ramka(textDecoration = "bold", halign = "left"),
             rows = max(wiersze_danych), cols = seq_len(kol_etykiet))
  }

  setColWidths(wb, arkusz, cols = seq_len(kol_etykiet), widths = szerokosc_1)
  setColWidths(wb, arkusz, cols = (kol_etykiet + 1):n_kol, widths = szerokosc)
  setRowHeights(wb, arkusz, rows = 1:wiersz_naglowka, heights = wys_naglowka)
  if (!is.null(wys_wiersza)) setRowHeights(wb, arkusz, rows = wiersze_danych, heights = wys_wiersza)
  freezePane(wb, arkusz, firstActiveRow = pierwszy_wiersz, firstActiveCol = kol_etykiet + 1)

  # Tabele są szerokie, więc wydruk domyślnie rozjeżdżałby się na kilka stron.
  pageSetup(wb, arkusz, orientation = "landscape", fitToWidth = TRUE, fitToHeight = FALSE)
}

# ------------------------------------------------------------------------------
# Złożenie skoroszytu
# ------------------------------------------------------------------------------
wb <- createWorkbook()

# TABELA 1 - elementy meteorologiczne w roku analizowanym.
# Pierwszy wiersz ramki niesie podpisy miesięcy, więc trafia do nagłówka, a nie do danych.
# W raporcie kolumna Uwagi jest pomijana, w arkuszu zostaje: obok symbolu stoi jego
# objaśnienie, więc tabelę da się czytać bez zaglądania do arkusza "Objaśnienia".
tab1 <- tab_1_dane[, c("Element", "Uwagi", paste0("V", 1:16))]
dodaj_tabele(wb, "Tabela 1", dane = tab1[-1, ],
             naglowek = c("Element", "Uwagi", "XI", "XII", "I", "II", "III", "IV", "V",
                          "VI", "VII", "VIII", "IX", "X", "XI", "XII", "XI-X", "I-XII"),
             naglowek_grupy = naglowek_tab_1, kol_etykiet = 2,
             szerokosc_1 = c(24, 38))

# Tabele 2, 3 i 4 bywają puste - rok analizowany bez dób w widoku wiatru albo bez
# miesięcy w widoku zagregowanym (przetwarzanie_danych.R). Pustej tabeli nie
# zapisujemy wcale: arkusz z samym nagłówkiem sugerowałby, że dane są, tylko się nie
# zapisały. Raport pomija te same tabele, więc arkusz i dokument się zgadzają.

# TABELA 2 - częstość kierunków wiatru i cisz
if (nrow(tab_2_dane) > 0) {
  dodaj_tabele(wb, "Tabela 2", dane = tab_2_dane,
               naglowek = c("Mc", names(tab_2_dane)[-1]), cyfry = 1, szerokosc_1 = 8)
}

# TABELA 3 - częstość i prędkość wiatru według kierunków
if (nrow(tab_3_dane) > 0) {
  dodaj_tabele(wb, "Tabela 3", dane = tab_3_dane,
               naglowek = c("Kierunek", "Liczba pomiarów (N)", "Częstość [%]",
                            "Średnia prędkość wg kierunków (V)"),
               cyfry = c(NA, NA, 1, 1), szerokosc_1 = 12, szerokosc = 18,
               wys_naglowka = 34)
}

# TABELA 4 - temperatura i opad roku analizowanego na tle wielolecia
if (nrow(tab_4_dane) > 0) {
  dodaj_tabele(wb, "Tabela 4", dane = tab_4_dane, naglowek = names(tab_4_dane),
               cyfry = 1, szerokosc_1 = 24)
}

# TABELA 5 - elementy meteorologiczne w kolejnych latach
dodaj_tabele(wb, "Tabela 5", dane = tab_5_dane,
             naglowek = c("Lata", "PRES [hPa]", "TA_D [°C]", "HH [%]", "RR_T [mm]",
                          "WIV [m·s⁻¹]", "SOL_P [h]", "SOL_T [W·m²]"),
             cyfry = 1, szerokosc_1 = 12, szerokosc = 12,
             wiersze_calkowite = which(tab_5_dane$Lata == "n"))

# TABELA 6 - klasyfikacja termiczna, z kolorami klas
dodaj_tabele(wb, "Tabela 6", dane = tab_6_dane, naglowek = names(tab_6_dane),
             tlo = kolory_bg_temp, czcionka = kolory_czcionka_temp,
             cyfry = 1, pogrub_ostatni = TRUE, szerokosc_1 = 10)

# TABELA 7 - klasyfikacja opadowa. Komórka łączy opad w mm i procent normy, więc
# pozostaje tekstem; kolory tła miesięcy i kolumny rocznej mają osobne progi.
tab7 <- tab_7_dane
tab7[, 2:14] <- lapply(tab7[, 2:14, drop = FALSE], fmt_tab7_komorka)
dodaj_tabele(wb, "Tabela 7", dane = tab7, naglowek = names(tab_7_dane),
             tlo = cbind(kolory_bg_miesiace_opad, kolory_bg_lata_opad),
             czcionka = cbind(kolory_czcionka_m_opad, kolory_czcionka_r_opad),
             pogrub_ostatni = TRUE, szerokosc_1 = 10, wys_wiersza = 28)

# TABELA 8 - liczba dni charakterystycznych. Jak w raporcie: zero dni to brak,
# czyli w arkuszu pusta komórka.
tab8 <- tab_8_dane
tab8[-1, -1] <- lapply(tab8[-1, -1, drop = FALSE],
                       function(kol) ifelse(trimws(as.character(kol)) == "0", NA, kol))
dodaj_tabele(wb, "Tabela 8", dane = tab8[-1, ],
             naglowek = c("Dni", as.character(tab_8_dane[1, -1])),
             naglowek_grupy = naglowek_tab_8, szerokosc_1 = 26)


# Tabele 9 i 10 - ekstremalne zjawiska pogodowe. W odróżnieniu od pozostałych tabel
# nie mają kolumn liczbowych ani nagłówka grupującego: każdy wiersz to zjawisko
# opisane tekstem, a próg podaje kolumna "Kryterium". Dlatego kolumny są szerokie,
# a wiersz nagłówka niski - nie ma tu czego łamać na dwie linie.
# Nagłówki grup tabeli 10 ("Opad atmosferyczny", "Pokrywa śnieżna") zostają zwykłymi
# wierszami: w arkuszu, gdzie da się filtrować i sortować, scalanie ich przeszkadza.
dodaj_tabele(wb, "Tabela 9", dane = tab_9_dane, naglowek = names(tab_9_dane),
             szerokosc_1 = 30, szerokosc = 30, wys_naglowka = 15)

dodaj_tabele(wb, "Tabela 10", dane = tab_10_dane, naglowek = names(tab_10_dane),
             szerokosc_1 = 30, szerokosc = 30, wys_naglowka = 15)

# ------------------------------------------------------------------------------
# Arkusze pomocnicze: legendy klas i objaśnienia symboli
# ------------------------------------------------------------------------------

# Legenda: kolumna "kolor" zostaje pusta, a jej znaczeniem jest samo tło komórki -
# tak samo jak w raporcie.
dodaj_legende <- function(wb, arkusz, dane, naglowek, kolumny_koloru, palety, szerokosci) {
  addWorksheet(wb, arkusz)
  writeData(wb, arkusz, as.list(naglowek), startCol = 1, startRow = 1, colNames = FALSE)
  writeData(wb, arkusz, dane, startCol = 1, startRow = 2, colNames = FALSE)

  wiersze <- 2:(nrow(dane) + 1)
  addStyle(wb, arkusz, styl_ramka(textDecoration = "bold", fgFill = "#F2F2F2"),
           rows = 1, cols = seq_along(naglowek), gridExpand = TRUE)
  addStyle(wb, arkusz, styl_ramka(halign = "left"), rows = wiersze,
           cols = seq_along(naglowek), gridExpand = TRUE)

  for (i in seq_along(kolumny_koloru)) {
    barwy <- palety[[i]]
    for (w in seq_along(barwy)) {
      addStyle(wb, arkusz, styl_ramka(fgFill = unname(barwy[w])),
               rows = 1 + w, cols = kolumny_koloru[i])
    }
  }

  setColWidths(wb, arkusz, cols = seq_along(naglowek), widths = szerokosci)
  setRowHeights(wb, arkusz, rows = 1, heights = 30)
  pageSetup(wb, arkusz, orientation = "landscape", fitToWidth = TRUE, fitToHeight = FALSE)
}

# LEGENDA TABELI 6 - klasy termiczne i odpowiadające im przedziały odchyleń
dodaj_legende(wb, "Legenda tab. 6", tab_6_legenda,
              naglowek = c("Klasa termiczna", "Zakres", "Kolor"),
              kolumny_koloru = 3, palety = list(kolory_klasyfikacja_termiczna),
              szerokosci = c(24, 26, 10))

# LEGENDA TABELI 7 - klasy opadowe; progi miesięczne i roczne są różne, dlatego
# legenda ma dwa zestawy kolumn
dodaj_legende(wb, "Legenda tab. 7", tab_7_legenda,
              naglowek = c("Okres", "Kolor", "Zakres", "Klasa opadowa",
                           "Okres", "Kolor", "Zakres", "Klasa opadowa"),
              kolumny_koloru = c(2, 6),
              palety = list(kolory_klasyfikacja_opadowa, kolory_klasyfikacja_opadowa),
              szerokosci = c(10, 8, 12, 20, 10, 8, 12, 20))

# OBJAŚNIENIA SYMBOLI
# Nazwy parametrów pochodzą z tabeli 6.1.1 "Parametry obligatoryjne programu
# pomiarowego A1 - Meteorologia" w metodykach ZMŚP (wydanie 2021).
lata_wielolecia_txt <- paste0(rok_poczatek, "-", rok_koniec)

# Nazwy parametrów wg tabeli 6.1.1 metodyk ZMŚP. To jedyne miejsce, gdzie są
# wypisane: kolumna z parametrem powstaje przez dopasowanie oznaczenia z tabeli
# (np. "TA_G min abs.5cm [°C]") do najdłuższego pasującego kodu (TA_G).
parametry_metodyka <- c(
  SOL_P = "SOL_P - usłonecznienie",
  SOL_T = "SOL_T - natężenie promieniowania słonecznego",
  TA_X  = "TA_X - maksymalna temperatura powietrza na 2 m",
  TA_D  = "TA_D - temperatura powietrza na 2 m",
  TA_N  = "TA_N - minimalna temperatura powietrza na 2 m",
  TA_G  = "TA_G - temperatura minimalna przy powierzchni gruntu (5 cm nad gruntem)",
  T_S   = "T_S - temperatura gruntu na głębokościach 5, 10, 20 i 50 cm",
  HH    = "HH - wilgotność względna powietrza na 2 m",
  RR_T  = "RR_T - wysokość opadów na 1 m",
  SC_H  = "SC_H - grubość pokrywy śnieżnej",
  PRES  = "PRES - ciśnienie atmosferyczne (zredukowane do poziomu morza)",
  WIV   = "WIV - prędkość wiatru na 10 m"
)

# Klucze sortujemy malejąco po długości, żeby "SC_Hśr" trafiło na SC_H, a nie żeby
# krótszy kod przypadkiem wygrał z dłuższym.
parametr_wg_metodyki <- function(oznaczenia) {
  klucze <- names(parametry_metodyka)[order(nchar(names(parametry_metodyka)), decreasing = TRUE)]
  vapply(oznaczenia, function(o) {
    trafienie <- klucze[startsWith(o, klucze)]
    if (length(trafienie) == 0) "" else unname(parametry_metodyka[trafienie[1]])
  }, character(1), USE.NAMES = FALSE)
}

# Blok tabeli 1 budujemy z samych danych: oznaczenia i ich objaśnienia to kolumny
# Element i Uwagi z tab_1_dane, więc arkusz nie może rozjechać się z tabelą.
# Pierwszy wiersz ramki niesie podpisy nagłówka, dlatego go pomijamy.
opisy_tab1 <- tab_1_dane[-1, c("Element", "Uwagi")]

# Kolumny tabeli 5 opisujemy osobno: tam wartości są roczne, a nie miesięczne.
kolumny_tab5 <- c("Lata", "PRES [hPa]", "TA_D [°C]", "HH [%]", "RR_T [mm]",
                  "WIV [m·s⁻¹]", "SOL_P [h]", "SOL_T [W·m²]")

# Blok tabeli 4 tylko wtedy, gdy tabela trafiła do skoroszytu - objaśnienia
# nieistniejącej tabeli byłyby mylące (a jej pusta kolumna Parametr nie zgadzałaby
# się z sześcioma opisami).
blok_tab_4 <- if (nrow(tab_4_dane) == 0) NULL else rbind(
  data.frame(a = "TABELA 4 - temperatura i opad roku analizowanego na tle wielolecia",
             b = "", c = ""),
  data.frame(a = "Oznaczenie", b = "Znaczenie", c = "Parametr wg tab. 6.1.1 metodyk ZMŚP"),
  data.frame(
    a = tab_4_dane$Parametr,
    b = c(paste0("Średnia miesięczna temperatura powietrza w roku ", analizowany_rok),
          paste0("Średnia miesięczna temperatura powietrza w wieloleciu ", lata_wielolecia_txt),
          "Odchylenie temperatury roku analizowanego od średniej wieloletniej",
          paste0("Miesięczna suma opadów w roku ", analizowany_rok),
          paste0("Średnia miesięczna suma opadów w wieloleciu ", lata_wielolecia_txt),
          "Suma opadów roku analizowanego jako procent średniej wieloletniej"),
    c = c(parametry_metodyka[["TA_D"]], parametry_metodyka[["TA_D"]], "",
          parametry_metodyka[["RR_T"]], parametry_metodyka[["RR_T"]], "")),
  data.frame(a = "", b = "", c = ""))

objasnienia <- rbind(
  data.frame(a = "TABELA 1 - średnie miesięczne i roczne wartości elementów meteorologicznych",
             b = "", c = ""),
  data.frame(a = "Oznaczenie", b = "Znaczenie", c = "Parametr wg tab. 6.1.1 metodyk ZMŚP"),
  data.frame(a = opisy_tab1$Element, b = opisy_tab1$Uwagi,
             c = parametr_wg_metodyki(opisy_tab1$Element)),
  data.frame(a = "", b = "", c = ""),
  blok_tab_4,
  data.frame(a = "TABELA 5 - wybrane elementy meteorologiczne w kolejnych latach",
             b = "", c = ""),
  data.frame(a = "Nazwa kolumny", b = "Znaczenie", c = "Parametr wg tab. 6.1.1 metodyk ZMŚP"),
  data.frame(
    a = kolumny_tab5,
    # Opisy elementów bierzemy ze słownika opisy_elementow - tak samo jak kolumna
    # "Uwagi" tabeli 1 i wszystkie objaśnienia w raporcie. Dzięki temu arkusz i raport
    # opisują ten sam element identycznie, bez drugiej listy pisanej ręcznie.
    b = c("Rok hydrologiczny (XI-X) lub wiersz podsumowania wielolecia",
          opisy_elementow[["PRES"]],
          opisy_elementow[["TA_D"]],
          opisy_elementow[["HH"]],
          opisy_elementow[["RR_T"]],
          opisy_elementow[["WIV"]],
          opisy_elementow[["SOL_P"]],
          opisy_elementow[["SOL_T"]]),
    c = parametr_wg_metodyki(kolumny_tab5)),
  data.frame(a = "", b = "", c = ""),
  data.frame(a = "Wiersze podsumowania w tabeli 5", b = "", c = ""),
  data.frame(a = c(lata_wielolecia_txt, "STD", "CV", "n"),
             b = c("Średnia z wielolecia, bez roku analizowanego",
                   "Odchylenie standardowe wartości rocznych w wieloleciu",
                   "Współczynnik zmienności: odchylenie standardowe jako procent średniej [%]",
                   paste0("Liczba lat wielolecia ", lata_wielolecia_txt,
                          " z pomiarem, z których policzono średnią, STD i CV")),
             c = c("", "", "", "")),
  data.frame(a = "", b = "", c = ""),
  data.frame(a = "Źródło nazw parametrów: tabela 6.1.1 \"Parametry obligatoryjne programu pomiarowego A1 - Meteorologia\", Metodyki ZMŚP 2021 (centrumzmsp.web.amu.edu.pl)",
             b = "", c = "")
)

addWorksheet(wb, "Objaśnienia")
writeData(wb, "Objaśnienia", objasnienia, startCol = 1, startRow = 1, colNames = FALSE)

styl_opis <- createStyle(fontName = "Times New Roman", fontSize = 9,
                         valign = "top", wrapText = TRUE, halign = "left")
addStyle(wb, "Objaśnienia", styl_opis, rows = 1:nrow(objasnienia), cols = 1:3, gridExpand = TRUE)

# Nagłówki sekcji i wiersze z podpisami kolumn - pogrubione.
naglowki_sekcji <- which(grepl("^TABELA |^Wiersze |^Oznaczenie$|^Nazwa kolumny$|^Źródło ",
                               objasnienia$a))
addStyle(wb, "Objaśnienia",
         createStyle(fontName = "Times New Roman", fontSize = 9, textDecoration = "bold",
                     valign = "top", wrapText = TRUE, halign = "left"),
         rows = naglowki_sekcji, cols = 1:3, gridExpand = TRUE)

# Tytuły sekcji i przypis o źródle są dłuższe niż kolumna, więc scalamy je na całą
# szerokość arkusza - inaczej zawijałyby się i nachodziły na wiersz poniżej.
tytuly <- which(grepl("^TABELA |^Wiersze |^Źródło ", objasnienia$a))
for (w in tytuly) mergeCells(wb, "Objaśnienia", cols = 1:3, rows = w)
addStyle(wb, "Objaśnienia",
         createStyle(fontName = "Times New Roman", fontSize = 9, textDecoration = "bold",
                     valign = "center", wrapText = FALSE, halign = "left"),
         rows = tytuly, cols = 1:3, gridExpand = TRUE)

setColWidths(wb, "Objaśnienia", cols = 1:3, widths = c(22, 50, 52))
pageSetup(wb, "Objaśnienia", orientation = "landscape", fitToWidth = TRUE, fitToHeight = FALSE)

saveWorkbook(wb, "wyniki/a1_tabele.xlsx", overwrite = TRUE)
message("   Tabele zapisane do wyniki/a1_tabele.xlsx")
