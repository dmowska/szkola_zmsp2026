################################################################################
# OPIS SKRYPTU
################################################################################
# przetwarzanie_danych.R - przygotowanie danych do tabel i rycin
#
# Zamienia surowe widoki pobrane z bazy ZMŚP na gotowe zestawy danych raportu.
# Uruchamiany przez uruchamianie_skryptow.R, zaraz po pobieranie_danych.R.
#
# Uwagi do kodu:
#
# UKŁAD PLIKU
#   SEKCJA 1 - przygotowanie danych na podstawie widoków z bazy,
#   SEKCJA 2 - dane do tabel, w kolejności numerów tabel,
#   SEKCJA 3 - dane do rycin.
#
# ROK HYDROLOGICZNY
#   Raport opisuje lata hydrologiczne (XI-X). Parametry analizowany_rok, rok_poczatek
#   i rok_koniec są latami HYDROLOGICZNYMI, więc tabele i ryciny filtrujemy po
#   rok_hydro. Kolumna rok_kal to rok kalendarzowy (I-XII) - korzystają z niej
#   wyłącznie tabele 1 i 8.
#
# TYPY OKRESU (kolumna okres_typ)
#   M       - miesiąc,
#   RH      - podsumowanie roku hydrologicznego (XI-X),
#   RK      - podsumowanie roku kalendarzowego (I-XII),
#   MH / MK - miesiąc w widokach klasyfikacji, przypisany do roku hydro / kalendarzowego.
#   W wierszach RH i RK miesiac jest NA, a wypełniona jest tylko ta kolumna roku,
#   która pasuje do typu okresu.
#
# TYPY KOLUMN CZASOWYCH
#   Baza zwraca rok_hydro, rok_kal i miesiac jako tekst (miesiąc z zerem wiodącym:
#   "01"). Sekcja 1 konwertuje je RAZ, dla wszystkich widoków naraz:
#     rok_hydro, rok_kal -> liczby całkowite,
#     miesiac            -> faktor o poziomach miesiace_hydro.
#   Dzięki temu każdy obiekt pochodny dziedziczy gotowe typy i nigdzie dalej nie
#   trzeba niczego rzutować: filtry porównują liczby, złączenia po roku i miesiącu
#   nie wymagają zgodności formatu, a sortowania i pivot_wider() same układają
#   miesiące w porządku roku hydrologicznego.
#   PUŁAPKA: kod poziomu faktora NIE jest numerem miesiąca - listopad ma kod 1.
#   Numer kalendarzowy daje nr_miesiaca(), zapis rzymski - miesiac_rzymski()
#   (obie funkcje w funkcje/funkcje_pomocnicze.R).
#
# KOLEJNOŚĆ I ZAPIS MIESIĘCY
#   Wszystkie tabele i ryciny używają porządku roku hydrologicznego (XI, XII, I-X)
#   i zapisu rzymskiego. Wyjątkiem są tabele 1 i 8: pokazują 14 miesięcy dwóch lat
#   kalendarzowych oraz oba podsumowania roczne, więc filtrują po rok_hydro LUB
#   rok_kal i sortują miesiące KALENDARZOWO, przez nr_miesiaca().
#
# WIELOLECIE A OKRES REFERENCYJNY - TO NIE TO SAMO
#   lata_wielolecia i lata_analizy pochodzą z parametry.xlsx i wyznaczają zakres
#   raportu. okres_referencyjny to okres normowy zapisany w bazie (np. "1991-2020"),
#   do którego widoki klasyfikacji odnoszą swoje wartości. Zmienne liczone względem
#   tego drugiego mają w nazwie przyrostek _okres_ref.
#
# SEPARATOR DZIESIĘTNY
#   options(OutDec = ",") ustawia uruchamianie_skryptow.R oraz chunk setup w qmd,
#   więc nigdzie nie podmieniamy kropek na przecinki ręcznie.
################################################################################
# DANE WEJŚCIOWE
################################################################################
#   Plik dane/dane.RData zapisany przez pobieranie_danych.R. Zawiera dziewięć widoków
#   a1_*_vw, każdy zawężony do jednej stacji, oraz parametry raportu. Skrypt wczytuje
#   go sam, więc można go uruchomić bez ponownego pobierania danych z bazy.
#   Zakres lat w widokach bywa szerszy niż potrzebny w raporcie - zawęża go sekcja 1.
#
#   Dane dobowe - jeden wiersz na dzień:
#     a1_dane_dobowe_vw
#         Pomiary dobowe roku analizowanego: temperatura powietrza (średnia TA_D,
#         maksymalna TA_X, minimalna TA_N), przy gruncie (TA_G) i gruntu na czterech
#         głębokościach (T_S 5/10/20/50 cm), opad RR_T, wilgotność HH, ciśnienie PRES,
#         prędkość wiatru WIV, usłonecznienie SOL_P i grubość pokrywy śnieżnej SC_H.
#     a1_wiatr_dobowe_vw
#         Dobowa prędkość (WIV) i kierunek wektorowy (WID) wiatru w roku analizowanym,
#         wraz z flagami jakości. Kierunek w stopniach - na nazwy róży wiatrów zamienia
#         go kierunek_wiatru().
#     a1_dane_wieloletnie_dobowe_vw
#         Przebieg roku hydrologicznego uśredniony po latach: dla każdego z 365 dni
#         (bez 29 II) minimum, maksimum, średnia i percentyle 05/25/50/75/95 dla TA_D,
#         TA_N, TA_X, HH i WIV. Kluczem jest dzien_miesiac w formacie "DD-MM", bo widok
#         nie odnosi się do konkretnego roku.
#
#   Agregaty miesięczne i roczne - typ okresu w kolumnie okres_typ (M, RH, RK):
#     a1_dane_agg_vw
#         Średnie, sumy i ekstrema wszystkich elementów meteorologicznych, plus flagi
#         jakości i kompletność każdego z nich. Podstawa tabel 1, 4 i 5.
#     a1_dni_charakterystyczne_temp_vw
#         Liczba dni bardzo upalnych, upalnych, gorących, przymrozkowych, mroźnych
#         i bardzo mroźnych, wraz z charakterystykami temperatury dla okresu.
#     a1_dni_charakterystyczne_opady_vw
#         Liczba dni z opadem przekraczającym kolejne progi (0,1 / 1 / 5 / 10 / 20 /
#         30 / 50 / 100 mm) - narastająco, więc liczby dni w przedziałach powstają jako
#         różnice progów. Do tego maksymalny opad dobowy i data jego wystąpienia.
#
#   Klasyfikacje względem okresu normowego - miesiące (MH, MK) i lata (RH, RK):
#     a1_klasyfikacja_termiczna_vw
#         Temperatura okresu, średnia i odchylenie standardowe wielolecia normowego,
#         różnica między nimi oraz nazwa klasy termicznej. Podstawa tabeli 6.
#     a1_klasyfikacja_opadowa_vw
#         Suma opadu okresu, norma wielolecia, opad jako procent normy i nazwa klasy
#         opadowej. Podstawa tabeli 7.
#
#   Pozostałe:
#     a1_pokrywa_sniezna_vw
#         Roczne charakterystyki pokrywy śnieżnej: średnia i maksymalna grubość, liczba
#         dni z pokrywą oraz z pokrywą co najmniej 1 cm i 20 cm, suma grubości dobowych
#         i wskaźnik śnieżności zimy Wsn (rycina 17).
#
#   Poza widokami:
#     - parametry z parametry.xlsx: analizowany_rok, rok_poczatek, rok_koniec, stacja,
#     - funkcje pomocnicze i palety kolorów z katalogu funkcje/.
#
#   KOLUMNY integer64
#   Kolumny z liczbą dni w a1_dni_charakterystyczne_opady_vw oraz w
#   a1_pokrywa_sniezna_vw baza oddaje jako int8, które RPostgres mapuje na integer64.
#   Działania na takim typie wymagają wczytanej przestrzeni nazw pakietu bit64 - bez
#   niej R czyta surowe bity i wychodzą bezsensowne wartości. Sekcja 1 sprowadza więc
#   te kolumny do zwykłych liczb od razu przy konwersji typów (liczba dni nigdy nie
#   przekracza 366, więc zamiana jest bezstratna).
#   Dlaczego to konieczne: obiekty rycin trafiają do dane_all.RData i są rysowane
#   ponownie w OSOBNEJ sesji R przez quarto_render, gdzie bit64 nie jest wczytany.
#   Kolumna integer64 na osi oznaczałaby tam, że skala czyta surowe bity: podziałki
#   wypadłyby poza zakres, a oś ryciny (np. 23) pokazałaby w raporcie samo "0".
################################################################################
# WYNIK
################################################################################
#   - tab_<nr>_dane            - dane tabel; formatuje je potem tworzenie_raportu.qmd,
#   - naglowek_tab_1 / _8      - układ nagłówka grupującego tych dwóch tabel,
#   - kolory_*                 - macierze kolorów komórek tabel 6 i 7,
#   - tab_<nr>_legenda         - legendy tabel 6 i 7,
#   - ryc_* oraz dane_*        - dane rycin; rysują je potem pliki wykresy/ryc_*.R,
#   - nazwy_linii_doy          - nazwy linii w legendzie rycin 10-14,
#   - tad_trend, tad_trend_txt - trend Theila-Sena dla ryciny 15 i jej podpisu,
#   - lata_ryc_<nr>            - lata z danymi rycin wieloletnich (15-21 i 25-30):
#                                zakres osi lat i wykaz lat w podpisie ryciny.
#
# BRAKUJĄCE LATA I MIESIĄCE
#   Baza pomija lata i miesiące zakwestionowane niezależnie w każdym widoku, a widoki
#   dobowe mają rok wpisany na sztywno w definicji. Skrypt nie przerywa wtedy pracy:
#   tabele i ryciny pomijają to, czego nie ma. Tabele 2, 3 i 4 bez danych roku
#   analizowanego zostają puste (raport i arkusz je pomijają), tabele 1 i 8 mają stały
#   szkielet 16 okresów z kropkami w miejscu braków, a ryciny wieloletnie mają oś
#   z własnych lat (lata_ryc_*). Ostrzeżenie z wykazem braków daje pobieranie_danych.R.
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - dplyr
# - forcats
# - magrittr
# - purrr
# - tibble
# - tidyr
# - trend
################################################################################

# ------------------------------------------------------------------------------
# Wczytanie danych
# ------------------------------------------------------------------------------
# Widoki z bazy i parametry raportu przygotowane przez pobieranie_danych.R.
# Wczytujemy je z pliku, zamiast polegać na tym, że zostały w środowisku po
# poprzednim kroku - dzięki temu ten skrypt można uruchomić samodzielnie, bez
# ponownego łączenia się z bazą, na przykład po zmianie sposobu liczenia tabeli
# albo ryciny. W pełnym przebiegu wczytanie niczego nie psuje: plik został
# zapisany chwilę wcześniej i zawiera dokładnie te same obiekty.
# UWAGA: rok_poczatek i rok_koniec pochodzą z pliku już po ewentualnym zawężeniu
# do lat dostępnych w bazie - patrz sekcja 4 w pobieranie_danych.R.
if (!file.exists("dane/dane.RData")) {
  stop("Brak pliku dane/dane.RData. Uruchom najpierw pobieranie_danych.R.",
       call. = FALSE)
}

load("dane/dane.RData")


# ------------------------------------------------------------------------------
# Stałe używane w całym skrypcie
# ------------------------------------------------------------------------------

# Miesiące w porządku roku hydrologicznego. Służą jako poziomy faktora miesiac,
# przez co wyznaczają kolejność miesięcy w każdej tabeli i na każdej rycinie.
miesiace_hydro = c(11, 12, 1:10)

# Te same miesiące zapisem rzymskim - nagłówki kolumn tabel 4, 6 i 7.
miesiace_rzymskie = as.character(as.roman(miesiace_hydro))

# Zakres lat raportu: wielolecie z parametry.xlsx oraz to samo wielolecie
# powiększone o rok analizowany.
lata_wielolecia = rok_poczatek:rok_koniec
lata_analizy    = c(lata_wielolecia, analizowany_rok)

# Kierunki wiatru w porządku kompasowym - poziomy faktora kierunek. Dzięki nim
# tabele 2 i 3 oraz rycina 6 mają tę samą kolejność kierunków, a wiersze i kolumny
# doklejane do tabel trafiają na właściwe pozycje.
kierunki_wiatru = c("N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW",
                    "W","WNW","NW","NNW")


# ==============================================================================
# SEKCJA 1: PRZYGOTOWANIE DANYCH NA PODSTAWIE WIDOKÓW Z BAZY
#
# Powstają tu obiekty używane dalej przez sekcje 2 i 3. Część widoków jest
# nadpisywana w miejscu (filtracja, dodanie kolumn), część służy do zbudowania
# nowych ramek.
# ==============================================================================

# ------------------------------------------------------------------------------
# Konwersja typów kolumn - jedna dla wszystkich widoków
# ------------------------------------------------------------------------------
# CO ROBI TEN BLOK
# Doprowadza kolumny rok_hydro, rok_kal i miesiac do docelowych typów - w każdym
# widoku pobranym z bazy, jednym przebiegiem. Baza oddaje je jako tekst; po tym
# bloku lata są liczbami całkowitymi, a miesiąc faktorem o poziomach miesiace_hydro.
# Uzasadnienie obu konwersji: sekcja "TYPY KOLUMN CZASOWYCH" w opisie skryptu.
# Przy okazji sprowadza kolumny typu integer64 do zwykłych liczb - patrz sekcja
# "KOLUMNY integer64" w opisie skryptu.
#
# JAK DZIAŁA
# Widoki są osobnymi obiektami w środowisku globalnym, a nie elementami jednej listy,
# więc nie da się ich przetworzyć jednym potokiem. Pętla obchodzi to, operując na
# NAZWACH obiektów - widoki_a1 to wektor napisów, nie ramek danych:
#   get(widok)    - pobiera ramkę o tej nazwie ze środowiska,
#   mutate(...)   - przekształca w niej kolumny czasowe,
#   assign(widok) - zapisuje wynik z powrotem pod tą samą nazwą, nadpisując widok.
# across() z any_of() przekształca tylko te kolumny, które w danym widoku faktycznie
# istnieją. Dzięki temu jedna pętla obsługuje widoki o różnym składzie kolumn:
# dobowe mają sam rok_hydro, agregaty i klasyfikacje mają oba lata i miesiąc.
# Gdyby użyć all_of(), brak którejkolwiek kolumny przerwałby działanie skryptu.
#
# ZAKRES
# Lista jest jawna, żeby konwersja nie objęła przypadkiem obiektu, który nie jest
# widokiem z bazy. Nie ma na niej a1_dane_wieloletnie_dobowe_vw: ten widok opisuje
# przebieg roku bez podziału na lata, więc nie ma kolumn z rokiem, a jego kolumna
# miesiac i tak zostaje niżej usunięta jako kolidująca w złączeniu.
# Miesiąc jest NA wyłącznie w wierszach podsumowań rocznych (RH, RK), a NA przechodzi
# przez as.integer() i factor() bez ostrzeżenia, więc konwersja jest cicha.
# Zmienne robocze pętli usuwamy, żeby nie trafiły do zapisywanego środowiska.
widoki_a1 = c("a1_dane_agg_vw", "a1_dane_dobowe_vw",
              "a1_dni_charakterystyczne_opady_vw", "a1_dni_charakterystyczne_temp_vw",
              "a1_klasyfikacja_opadowa_vw", "a1_klasyfikacja_termiczna_vw",
              "a1_pokrywa_sniezna_vw", "a1_wiatr_dobowe_vw")

for (widok in widoki_a1) {
  assign(widok,
         get(widok) |>
           mutate(across(any_of(c("rok_hydro", "rok_kal")), as.integer),
                  across(any_of("miesiac"),
                         \(x) factor(as.integer(x), levels = miesiace_hydro)),
                  across(where(\(x) inherits(x, "integer64")), as.numeric)))
}

rm(widoki_a1, widok)


# ------------------------------------------------------------------------------
# Dane dobowe: klasyfikacja dni charakterystycznych
# ------------------------------------------------------------------------------
# Progi temperatury i opadu przypisujące każdemu dniu kategorię. Kolejność warunków
# w case_when() jest istotna - pierwszy pasujący wygrywa. Kategorie zostają faktorami
# o poziomach z palet kolorów, więc rycina 24 rysuje je zawsze w tej samej kolejności.
a1_dane_dobowe_vw <- a1_dane_dobowe_vw |>
  mutate(dch_temp = case_when(
    TA_X > 35 ~ "bardzo upalne",
    TA_X > 30 ~ "upalne",
    TA_X > 25 ~ "gorace",
    TA_N < -10 ~ "bardzo mrozne",
    TA_X < 0   ~ "mrozne",
    TA_N < 0   ~ "przymrozkowe"
  )) |>
  mutate(dch_opad = case_when(
    RR_T == 0 ~ "opad sladowy",
    RR_T >= 0.1 & RR_T < 1.0 ~ "bardzo slaby",
    RR_T >= 1 & RR_T < 5.0 ~ "slaby",
    RR_T >= 5 & RR_T < 10 ~ "umiarkowanie silny",
    RR_T >= 10 & RR_T < 20 ~ "silny",
    RR_T >= 20 ~ "bardzo silny",
    TRUE ~ "brak opadu"
  )) |>
  mutate(dch_opad = factor(dch_opad,levels = c(names(kolory_dni_charakterystyczne_opad), "brak opadu")),
         dch_temp = factor(dch_temp,levels = names(kolory_dni_charakterystyczne_temp)))


# ------------------------------------------------------------------------------
# Dane dobowe roku analizowanego na tle wielolecia
# ------------------------------------------------------------------------------
# UWAGA NA KOLEJNOŚĆ: oba poniższe bloki muszą pozostać w tej kolejności. Najpierw
# przygotowujemy dane dobowe roku analizowanego, a dopiero potem doklejamy je do
# wielolecia - złączenie korzysta z ramki JUŻ przefiltrowanej do roku analizowanego
# i z uzupełnionymi pomiarami pokrywy śnieżnej.

# Dane dobowe roku analizowanego. dzien_roku numeruje dni od 1 XI - używają go
# ryciny 1-5. Dzień przychodzi jako tekst z zerem wiodącym, a rycina 24 potrzebuje
# liczby. Brak pomiaru pokrywy śnieżnej oznacza jej brak, więc NA zamieniamy na 0.
a1_dane_dobowe_vw = a1_dane_dobowe_vw |>
  filter(rok_hydro == analizowany_rok) |>
  mutate(dzien_roku = row_number(),
         dzien = as.integer(dzien))

a1_dane_dobowe_vw$SC_H[is.na(a1_dane_dobowe_vw$SC_H)] = 0

# Statystyki wielolecia dla każdego dnia roku, z doklejonym przebiegiem roku
# analizowanego (ryciny 10-14).
# Widok opisuje przebieg jednego roku hydrologicznego uśredniony po latach i oddaje
# dokładnie 365 wierszy: od 01-11 do 31-10, po jednym na dzień, bez 29 II.
# Łączymy po dniu i miesiącu, a nie po numerze dnia w roku: w roku hydrologicznym
# z lutym przestępnym rok analizowany ma 366 dni, więc numeracja rozjechałaby się
# o jeden dzień począwszy od 29 II, a ostatni dzień w ogóle wypadłby z zestawienia.
# Przy złączeniu po dacie 29 II roku przestępnego po prostu nie znajduje odpowiednika
# w wieloleciu - i tak ma być, bo wielolecie nie ma dla tego dnia statystyk.
# Kolumny dzien i miesiac usuwamy, bo kolidują z kolumnami dokładanymi w złączeniu;
# kluczem zostaje dzien_miesiac w formacie "DD-MM".
a1_dane_wieloletnie_dobowe_vw = a1_dane_wieloletnie_dobowe_vw |>
  select(-stacja, -stanowisko, -dzien, -miesiac) |>
  mutate(dzien_roku = row_number()) |>
  left_join(a1_dane_dobowe_vw |>
              select(-dzien_roku) |> # numer dnia bierzemy z wielolecia (1-365)
              mutate(dzien_miesiac = paste0(substring(data_pomiar, 9, 10), "-",
                                            substring(data_pomiar, 6, 7))),
            by = "dzien_miesiac") |>
  relocate(dzien_roku)


# ------------------------------------------------------------------------------
# Agregaty roczne i miesięczne
# ------------------------------------------------------------------------------
# Trzy wycinki widoku zagregowanego, używane wielokrotnie w sekcjach 2 i 3.

# Wiersze roczne (RH) wielolecia i roku analizowanego - po jednym na rok.
a1_dane_agg_vw_roczne = a1_dane_agg_vw |>
  filter(rok_hydro %in% lata_analizy & okres_typ == "RH")

# Miesiące roku analizowanego, w porządku XI, XII, I-X.
a1_dane_agg_vw_rok = a1_dane_agg_vw |>
  filter(rok_hydro == analizowany_rok & okres_typ == "M") |>
  arrange(miesiac)

# Miesiące wszystkich lat analizy - dane do boxplotów na rycinach 15 i 16.
a1_dane_agg_vw_m = a1_dane_agg_vw |>
  filter(rok_hydro %in% lata_analizy & okres_typ == "M")

# Średnie miesięczne z samego wielolecia (bez roku analizowanego) - punkt odniesienia
# dla odchyleń miesięcznych w tabeli 4 oraz na rycinach 7, 8 i 9.
wielolecie_miesieczne = a1_dane_agg_vw |>
  filter(rok_hydro %in% lata_wielolecia & okres_typ == "M") |>
  group_by(miesiac) |>
  summarise(RR_T_wielolecie = round(mean(`RR_T sum`, na.rm = TRUE),2),
            TA_D_wielolecie = round(mean(`TA_D avg`, na.rm = TRUE),2),
            SOL_P_wielolecie = round(mean(`SOL_P h sum`, na.rm = TRUE),2),
            .groups = "drop")

# Odchylenia miesięczne roku analizowanego od średnich wielolecia: opad jako procent
# i jako różnica, temperatura jako różnica.
a1_dane_agg_vw_rok = a1_dane_agg_vw_rok |>
  left_join(wielolecie_miesieczne, by = "miesiac") |>
  mutate(RR_T_proc = (`RR_T sum`/RR_T_wielolecie)*100,
         RR_T_roznica = `RR_T sum` - RR_T_wielolecie,
         TA_D_roznica = `TA_D avg`-TA_D_wielolecie)


# ------------------------------------------------------------------------------
# Dwa punkty odniesienia: okres referencyjny i średnia z lat analizy
# ------------------------------------------------------------------------------
# Raport posługuje się DWIEMA różnymi normami i nie wolno ich mieszać:
#
#  1. OKRES REFERENCYJNY (np. 1991-2020) - okres normowy zapisany w bazie.
#     Używa go WYŁĄCZNIE klasyfikacja termiczna i opadowa: tabele 6 i 7 oraz
#     rycina 20, gdzie wyznacza siatkę klas i linie średniej.
#  2. ŚREDNIA Z WIELOLECIA - średnia z lat rok_poczatek..rok_koniec, czyli BEZ roku
#     analizowanego. To dokładnie ta sama wartość, którą tabela 5 podaje w wierszu
#     podsumowania wielolecia. Używają jej anomalie roczne (ryciny 18 i 19) oraz
#     czerwona linia przerywana na rycinach 15 i 16, dzięki czemu tabela i ryciny
#     odnoszą rok analizowany do tego samego punktu odniesienia.

# Ad 1. Wartości normowe okresu referencyjnego. Wszystkie cztery czytamy z wiersza
# rocznego (RH) roku analizowanego. Norma nie zależy od klasyfikowanego roku - każdy
# wiersz RH niesie te same wartości - więc gdy baza nie ma wiersza za rok analizowany
# (rok zakwestionowany), bierzemy najpóźniejszy dostępny. Bez tego etykieta okresu
# byłaby pusta, a podpisy rycin 20 i 21 oraz tabel 6 i 7 urwałyby się w pół zdania.
wiersz_normy = function(widok) {
  roczne = filter(widok, okres_typ == "RH")
  wiersz = filter(roczne, rok_hydro == analizowany_rok)
  if (nrow(wiersz) == 0) wiersz = slice_max(roczne, rok_hydro, n = 1, with_ties = FALSE)
  wiersz
}

okres_ref_opad = wiersz_normy(a1_klasyfikacja_opadowa_vw)
okres_ref_temp = wiersz_normy(a1_klasyfikacja_termiczna_vw)

okres_referencyjny     = unique(okres_ref_opad$wielolecie) # etykieta okresu, np. "1991-2020"
sredni_opad_okres_ref  = okres_ref_opad$opad_wielolecie
srednia_temp_okres_ref = okres_ref_temp$`TA_D wielolecie`
sd_temp_okres_ref      = okres_ref_temp$`TA_D SD wielolecie`

rm(okres_ref_opad, okres_ref_temp, wiersz_normy)

# Ad 2. Średnie z wielolecia. a1_dane_agg_vw_roczne obejmuje wielolecie WRAZ z rokiem
# analizowanym, więc rok analizowany trzeba najpierw odfiltrować - inaczej wpływałby
# na własny punkt odniesienia. Ten sam filtr stosuje tabela 5 przy liczeniu wiersza
# podsumowania, więc obie wartości są z definicji zgodne.
wielolecie_roczne = a1_dane_agg_vw_roczne |>
  filter(rok_hydro %in% lata_wielolecia)

srednia_temp_wielolecia = mean(wielolecie_roczne$`TA_D avg`, na.rm = TRUE)
srednia_opad_wielolecia = mean(wielolecie_roczne$`RR_T sum`, na.rm = TRUE)

rm(wielolecie_roczne)

# Anomalie roczne (ryciny 18 i 19) - odchylenie każdego roku od średniej wielolecia,
# a nie od normy okresu referencyjnego.
a1_dane_agg_vw_roczne = a1_dane_agg_vw_roczne |>
  mutate(TA_D_anomalie = `TA_D avg` - srednia_temp_wielolecia,
         RR_T_anomalie = `RR_T sum` - srednia_opad_wielolecia)


# ------------------------------------------------------------------------------
# Dni charakterystyczne
# ------------------------------------------------------------------------------
# Dni charakterystyczne temperatury i opadu w jednej ramce. Z nazw kolumn widoku
# temperatury zdejmujemy przedrostek "dni ", żeby pasowały do nazw kategorii
# w paletach kolorów. Liczby dni w przedziałach opadu liczymy jako różnice
# progów kumulowanych, które podaje widok (">= 0,1mm" minus ">= 1,0mm" itd.).
# Kluczem złączenia są oba lata, miesiąc i typ okresu; w wierszach RH i RK jedno
# z lat jest NA po obu stronach, a domyślne na_matches = "na" łączy je poprawnie.
dni_charakterystyczne = a1_dni_charakterystyczne_temp_vw |>
  select(rok_kal, rok_hydro, miesiac, okres_typ, `dni bardzo upalne`, `dni upalne`,
         `dni gorace`, `dni przymrozkowe`, `dni mrozne`, `dni bardzo mrozne`) |>
  rename_with(~ gsub("dni ", "", .x)) |>
  full_join(a1_dni_charakterystyczne_opady_vw,
            by = c("rok_kal", "rok_hydro", "miesiac", "okres_typ")) |>
  relocate(stacja, stanowisko) |>
  select(-`kompletnosc danych`, -`flaga jakosci`, -`data_ref`) |>
  mutate(`bardzo slaby`  = `>= 0,1mm`-`>= 1,0mm`,
         `slaby`  = `>= 1,0mm`-`>= 5,0mm`,
         `umiarkowanie silny`  = `>= 5,0mm`-`>= 10,0mm`,
         `silny`  = `>= 10,0mm`-`>= 20,0mm`,
         `bardzo silny`  = `>= 20,0mm`)

# Trzy wycinki o różnej ziarnistości, z których korzystają ryciny 22, 23 i 25-28.
# Miesiące roku analizowanego (XI, XII, I-X):
dni_charakterystyczne_analizowany_rok = dni_charakterystyczne  |>
  filter(rok_hydro == analizowany_rok & `okres_typ` == "M")  |>
  arrange(miesiac)

# Miesiące wszystkich lat analizy:
dni_charakterystyczne_m = dni_charakterystyczne  |>
  filter(rok_hydro %in% lata_analizy & `okres_typ` == "M")  |>
  arrange(rok_hydro, miesiac)

# Sumy roczne (wiersze RH):
dni_charakterystyczne_r = dni_charakterystyczne |>
  filter(rok_hydro %in% lata_analizy & `okres_typ` == "RH") |>
  arrange(rok_hydro)


# ------------------------------------------------------------------------------
# Klasyfikacja termiczna i opadowa
# ------------------------------------------------------------------------------
# Widok klasyfikacji opadowej zwraca wiersze w kolejności przypadkowej, dlatego
# sortujemy oba widoki jawnie i nigdzie nie polegamy na kolejności z bazy.
# Miesiąc jest faktorem, więc sortowanie układa miesiące w porządku roku
# hydrologicznego - tym samym, w którym stoją kolumny tabel 6 i 7.
a1_klasyfikacja_opadowa_vw = a1_klasyfikacja_opadowa_vw |>
  arrange(rok_hydro, miesiac)

a1_klasyfikacja_termiczna_vw = a1_klasyfikacja_termiczna_vw |>
  arrange(rok_hydro, miesiac)


# ------------------------------------------------------------------------------
# Pokrywa śnieżna i wiatr
# ------------------------------------------------------------------------------

# Wskaźnik śnieżności zimy dla lat analizy (rycina 17).
a1_pokrywa_sniezna_vw = a1_pokrywa_sniezna_vw |>
  filter(rok_hydro %in% lata_analizy)

# Pomiary wiatru z roku analizowanego (tabele 2 i 3, rycina 6). Kierunek wyznaczamy
# z wartości wektorowej WID i zapisujemy jako faktor o poziomach kierunki_wiatru,
# dzięki czemu każde group_by() i pivot_wider() daje tę samą, kompasową kolejność.
a1_wiatr_dobowe_vw = a1_wiatr_dobowe_vw |>
  filter(rok_hydro == analizowany_rok) |>
  mutate(kierunek = factor(kierunek_wiatru(WID), levels = kierunki_wiatru))

# Doba bez wyznaczonego kierunku (brak pomiaru WID) NIE JEST osobną klasą róży
# wiatrów, a group_by() i pivot_wider() zrobiłyby z niej kolejną kategorię: w tabeli 2
# kolumnę o nagłówku "NA", w tabeli 3 wiersz bez nazwy, a na rycinie 6 słupek obok
# kierunków. Do zestawień kierunkowych bierzemy więc tylko doby z wyznaczonym
# kierunkiem - dzięki temu częstości opisują pomiary, a nie mieszankę pomiarów i luk.
# Ciszy to nie dotyczy: liczy się ją z prędkości (WIV), a nie z kierunku, więc jej
# licznik zostaje przy pełnym zbiorze dób.
wiatr_kierunki = a1_wiatr_dobowe_vw |>
  filter(!is.na(kierunek))


# ==============================================================================
# SEKCJA 2: DANE DO TABEL
#
# Tabele w kolejności numerów. Każda kończy się obiektem tab_<nr>_dane, który
# tworzenie_raportu.qmd zamienia na flextable - tu ustalamy wyłącznie zawartość,
# kolejność wierszy i kolumn oraz zaokrąglenia.
# ==============================================================================

# ------------------------------------------------------------------------------
# Funkcje wspólne dla kilku tabel
# ------------------------------------------------------------------------------

# Układ nagłówka grupującego tabel 1 i 8. Zwraca kolejne grupy kolumn wraz z liczbą
# kolumn w każdej: dla miesięcy jest to rok kalendarzowy z kolumny rok_kal, dla obu
# podsumowań rocznych wspólna grupa "Rok". Ramka jest już w docelowej kolejności,
# więc wystarczy policzyć serie wartości (rle). Dzięki temu podpisy ORAZ rozpiętości
# w qmd zawsze odpowiadają temu, co faktycznie znalazło się w tabeli - nic nie
# zakłada, że lat są dokładnie dwa, po 2 i 12 miesięcy.
uklad_naglowka = function(df) {
  # rok_kal jest liczbą, a druga gałąź if_else() tekstem - bez as.character() obie
  # gałęzie miałyby różny typ i funkcja przerwałaby działanie
  serie = rle(if_else(df$okres_typ == "M", as.character(df$rok_kal), "Rok"))
  data.frame(grupa = serie$values, kolumn = serie$lengths)
}

# Wiersz "Średnia" ze średnich kolumnowych, doklejony na końcu ramki (tabele 6, 7A, 7B).
# rbind() sam nie nadaje nazwy wiersza, a rownames(x)[nrow(x)] <- ... zależy od tego,
# że wiersz dołożono chwilę wcześniej - tutaj obie operacje są w jednym miejscu.
# Tabela 7B zaokrągla do pełnych procentów, pozostałe do jednego miejsca po przecinku.
dodaj_srednia = function(df, cyfry = 1) {
  df |>
    rbind(colMeans(df, na.rm = TRUE)) |>
    mutate(across(where(is.numeric), \(x) round(x, cyfry))) |>
    magrittr::set_rownames(c(rownames(df), "Średnia"))
}

# Nazwy wierszy (lata hydrologiczne plus wiersze podsumowań) przeniesione do kolumny
# "Lata", bo flextable nie drukuje nazw wierszy. Tak kończą tabele 5, 6, 6B i 7.
# Nazwa "Rok" jest zarezerwowana dla KOLUMN z pojedynczym podsumowaniem rocznym.
kolumna_lata = function(df) {
  df |> mutate(Lata = rownames(df)) |> relocate(Lata)
}

# Szkielet tabel 6, 6B, 7A i 7B: wartości miesięczne (okres_typ "MH") rozłożone
# na kolumny XI, XII, I-X plus kolumna "Rok" z podsumowania rocznego ("RH").
# Tabele różnią się wyłącznie widokiem i nazwą kolumny z wartością.
#  - miesiac jako faktor + names_expand = TRUE gwarantuje komplet 12 kolumn
#    w porządku roku hydrologicznego, także gdy któregoś miesiąca brakuje w danych,
#  - kolumnę roczną dołączamy złączeniem po rok_hydro, a nie pozycyjnie.
tabela_klasyfikacji = function(widok, kolumna) {
  miesieczne = widok |>
    filter(rok_hydro %in% lata_analizy & okres_typ == "MH") |>
    select(rok_hydro, miesiac, wartosc = all_of(kolumna)) |>
    pivot_wider(names_from = miesiac, values_from = wartosc, names_expand = TRUE)

  roczne = widok |>
    filter(rok_hydro %in% lata_analizy & okres_typ == "RH") |>
    select(rok_hydro, Rok = all_of(kolumna))

  # names_expand dokłada brakujące miesiące tylko wtedy, gdy jest z czego rozkładać.
  # Bez ani jednego wiersza miesięcznego pivot_wider nie tworzy żadnej kolumny
  # miesiąca, a nadanie tabeli nazw 12 miesięcy przerwałoby pracę - dokładamy je jawnie.
  for (m in setdiff(as.character(miesiace_hydro), names(miesieczne))) {
    miesieczne[[m]] = if (is.character(roczne$Rok)) NA_character_ else NA_real_
  }
  miesieczne = miesieczne[, c("rok_hydro", as.character(miesiace_hydro))]

  miesieczne |>
    left_join(roczne, by = "rok_hydro") |>
    arrange(rok_hydro) |>
    column_to_rownames(var = "rok_hydro")
}


# ------------------------------------------------------------------------------
# TABELA 1: elementy meteorologiczne w roku analizowanym
# ------------------------------------------------------------------------------
# Tabela wyjątkowa (razem z tabelą 8): obejmuje miesiące dwóch lat kalendarzowych
# - XI i XII roku poprzedzającego oraz I-XII roku analizowanego - i oba podsumowania
# roczne, XI-X (RH) oraz I-XII (RK). Elementy meteorologiczne są wierszami, a miesiące
# kolumnami, więc ramkę na końcu transponujemy.

# Wiersze tabeli: skrót elementu i jego opis. Kolejność musi odpowiadać kolejności
# kolumn wybranych w tab_1_zrodlo. Pierwsza pozycja to podpis samego nagłówka.
tab1_nazwy_wierszy = c("Element", "SOL_P [h]","SOL_T [W·m²]","TA_X max abs [°C]","TA_X max [°C]",
            "TA_D [°C]","TA_N min [°C]","TA_N min abs. [°C]","TA_G min 5 cm [°C]",
            "TA_G min abs.5cm [°C]","T_S 5cm [°C]","T_S 20cm [°C]","T_S 50cm [°C]",
            "HH [%]","RR_T [mm]","SC_Hśr [cm]","SC_H max [cm]","PRES [hPa]",
            "WIV [m·s⁻¹]")
# Opisy bierzemy ze słownika opisy_elementow (funkcje/funkcje_pomocnicze.R), żeby
# element był w całym raporcie i w arkuszu opisany identycznie, a dopisujemy statystykę
# danego wiersza. Tabela 1 jest jedynym miejscem, gdzie statystyka jest niezbędna:
# ten sam element występuje tu w kilku wierszach i tylko ona je odróżnia (TA_X max abs
# to wartość najwyższa w miesiącu, TA_X max - średnia z maksimów dobowych).
# Kolejność musi odpowiadać tab1_nazwy_wierszy.
uwagi = c("Uwagi",
          paste0(opisy_elementow[["SOL_P"]],  ", suma miesięczna"),
          paste0(opisy_elementow[["SOL_T"]],  ", średnia miesięczna"),
          paste0(opisy_elementow[["TA_X"]],   ", wartość najwyższa w miesiącu"),
          paste0(opisy_elementow[["TA_X"]],   ", średnia miesięczna z maksimów dobowych"),
          paste0(opisy_elementow[["TA_D"]],   ", średnia miesięczna"),
          paste0(opisy_elementow[["TA_N"]],   ", średnia miesięczna z minimów dobowych"),
          paste0(opisy_elementow[["TA_N"]],   ", wartość najniższa w miesiącu"),
          paste0(opisy_elementow[["TA_G"]],   ", średnia miesięczna z minimów dobowych"),
          paste0(opisy_elementow[["TA_G"]],   ", wartość najniższa w miesiącu"),
          paste0(opisy_elementow[["T_S 5"]],  ", średnia miesięczna"),
          paste0(opisy_elementow[["T_S 20"]], ", średnia miesięczna"),
          paste0(opisy_elementow[["T_S 50"]], ", średnia miesięczna"),
          paste0(opisy_elementow[["HH"]],     ", średnia miesięczna"),
          paste0(opisy_elementow[["RR_T"]],   ", suma miesięczna"),
          paste0(opisy_elementow[["SC_H"]],   ", średnia miesięczna"),
          paste0(opisy_elementow[["SC_H"]],   ", wartość maksymalna w miesiącu"),
          paste0(opisy_elementow[["PRES"]],   ", średnia miesięczna"),
          paste0(opisy_elementow[["WIV"]],    ", średnia miesięczna"))

# Tabela 1 ma ZAWSZE 16 kolumn okresów: XI i XII roku poprzedzającego, I-XII roku
# analizowanego oraz dwa podsumowania (XI-X i I-XII). Dlatego nie filtrujemy widoku,
# tylko dokładamy dane do gotowego szkieletu tych 16 okresów - okres, którego stacja
# nie ma w bazie, zostaje pustym wierszem i wychodzi w raporcie jako kolumna kropek.
# Bez szkieletu tabela miałaby tyle kolumn, ile okresów akurat znalazłoby się
# w danych, a dalszy kod (qmd i zapis_tabel.R) wybiera kolumny po nazwach V1...V16
# i przerwałby pracę na "undefined columns selected". Dotyczy to każdej stacji, której
# seria kończy się na analizowanym roku hydrologicznym: w bazie nie ma wtedy XI i XII
# tego roku KALENDARZOWEGO, bo należą już do następnego roku hydrologicznego.
#
# Kolejność wierszy szkieletu jest kolejnością kolumn po transpozycji: miesiące
# rosnąco wg roku i miesiąca KALENDARZOWEGO, potem XI-X, na końcu I-XII.
#
# Ten sam szkielet dostaje tabela 8 - ma identyczny układ 16 kolumn i bez szkieletu
# rok analizowany nieobecny w widokach dni charakterystycznych przerwałby jej budowę.
szkielet_okresow = function() bind_rows(
  data.frame(
    okres_typ = "M",
    rok_kal   = c(rep(analizowany_rok - 1L, 2), rep(analizowany_rok, 12)),
    # XI i XII roku kalendarzowego należą już do NASTĘPNEGO roku hydrologicznego
    rok_hydro = c(rep(analizowany_rok, 12), rep(analizowany_rok + 1L, 2)),
    miesiac   = factor(c(11, 12, 1:12), levels = miesiace_hydro)),
  data.frame(okres_typ = "RH", rok_kal = NA_integer_, rok_hydro = analizowany_rok,
             miesiac = factor(NA, levels = miesiace_hydro)),
  data.frame(okres_typ = "RK", rok_kal = analizowany_rok, rok_hydro = NA_integer_,
             miesiac = factor(NA, levels = miesiace_hydro))
)

tab_1_szkielet = szkielet_okresow()

tab_1_zrodlo = tab_1_szkielet |>
  left_join(
    a1_dane_agg_vw |>
      select(rok_kal, rok_hydro, miesiac, okres_typ,
             `SOL_P h sum`,`SOL_T avg`,`TA_X max`,`TA_X avg`, `TA_D avg`,`TA_N avg`, `TA_N min`,
             `TA_G avg`,`TA_G min`,`T_S 5 avg`,`T_S 20 avg`,`T_S 50 avg`,`HH avg`,
             `RR_T sum`,`SC_H avg`,`SC_H max`,`PRES avg`,`WIV avg`),
    by = c("okres_typ", "rok_kal", "rok_hydro", "miesiac"))

rm(tab_1_szkielet)

naglowek_tab_1 = uklad_naglowka(tab_1_zrodlo)

# Nagłówki kolumn: miesiące rzymskimi, podsumowania roczne opisowo. Kolumny
# pomocnicze (lata i typ okresu) znikają przed transpozycją.
tab_1_dane = tab_1_zrodlo |>
  mutate(
    miesiac = case_when(
      okres_typ == "RH" ~ "XI-X",
      okres_typ == "RK" ~ "I-XII",
      !is.na(miesiac) ~ miesiac_rzymski(miesiac),
      TRUE ~ NA_character_
    )) |>
  select(-rok_hydro, -rok_kal, -okres_typ) |>
  mutate(across(where(is.numeric), \(x) round(x, 1)),
         across(2:19, as.character)) |>
  t() |>
  as.data.frame() |>
  mutate(Uwagi = uwagi,
         Element = tab1_nazwy_wierszy)


# ------------------------------------------------------------------------------
# TABELA 2: częstość kierunków wiatru i cisz (C) w %
# ------------------------------------------------------------------------------
# Wiersze to miesiące roku hydrologicznego plus wiersz roczny, kolumny to kierunki
# wiatru plus kolumna C z liczbą cisz. Za ciszę uznajemy prędkość <= 0,2 m/s.

# Częstość kierunków w skali całego roku - posłuży za wiersz "Rok".
# .drop = FALSE zostawia w zestawieniu WSZYSTKIE 16 kierunków róży, także te, z których
# ani razu nie zawiało - bez tego kierunek bez ani jednej doby wypadłby z ramki i zniknął
# zarówno z tabeli, jak i z róży wiatrów na rycinie 6.
# Sama częstość takiego kierunku to jednak NA, a nie 0: w tabeli ma stać kropka, zgodnie
# z objaśnieniem, że kropka oznacza również brak wystąpienia zjawiska. Zero zostaje tam,
# gdzie jest wartością - na rycinie 6, jako słupek zerowej długości.
czestosc_rok = wiatr_kierunki |>
  group_by(kierunek, .drop = FALSE) |>
  summarise(N = n(), .groups = "drop") |>
  mutate(czestosc = ifelse(N == 0, NA_real_, 100 * N/sum(N)))

# Liczba cisz w kolejnych miesiącach i w całym roku, złożona w jedną kolumnę
# odpowiadającą wierszom tabeli.
# na.rm w OBU sumach: bez niego jeden brakujący pomiar prędkości w roku wystarczy,
# żeby roczna liczba cisz wyszła NA - w tabeli 2 zostałaby po niej kropka w wierszu
# "Rok", a w tabeli 3 pusty wiersz "Cisza", choć sumy miesięczne liczą się dobrze.
# .drop = FALSE również tutaj, i to nie dla kosmetyki: cisza_3 wchodzi do tabeli jako
# gotowa kolumna, więc musi mieć dokładnie tyle wartości, ile tabela ma wierszy.
# Bez tego miesiąc bez pomiarów wiatru wypadłby z cisza_m i kolumna C zrobiłaby się
# o jeden element za krótka.
# Miesiąc bez ANI JEDNEGO pomiaru prędkości daje NA, a nie zero: sum(na.rm = TRUE)
# z pustego zbioru zwraca 0, a "zero cisz" w miesiącu bez pomiarów to nieprawda -
# w takim wierszu wszystkie kierunki mają kropkę i cisza ma ją mieć również.
cisza_m = a1_wiatr_dobowe_vw |>
  group_by(miesiac, .drop = FALSE) |>
  summarise(cisza = if (all(is.na(WIV))) NA_integer_ else sum(WIV <= 0.2, na.rm = TRUE),
            .groups = "drop")

cisza_r = sum(a1_wiatr_dobowe_vw$WIV <= 0.2, na.rm = TRUE)
cisza_3 = c(cisza_m$cisza, cisza_r)

# Częstości miesięczne. names_sort = TRUE porządkuje kolumny wg poziomów faktora
# (kompasowo); domyślnie pivot_wider układa je wg pierwszego wystąpienia w danych.
# .drop = FALSE działa tu na obu faktorach naraz: daje komplet 12 miesięcy i komplet
# 16 kierunków, więc żaden kierunek ani miesiąc nie wypada z tabeli.
# Kierunek, z którego w danym miesiącu nie zawiało, dostaje NA - w tabeli kropkę, tak
# jak mówi objaśnienie pod nią. Miesiąc BEZ ANI JEDNEGO pomiaru ma sum(N) = 0, więc
# częstość i tak wychodzi NaN; jedno i drugie kończy w tabeli tą samą kropką.
tab_2_dane = wiatr_kierunki |>
  group_by(miesiac, kierunek, .drop = FALSE) |>
  summarise(N = n(), .groups = "drop") |>
  group_by(miesiac) |>
  mutate(czestosc = ifelse(N == 0, NA_real_, 100 * N/sum(N))) |>
  ungroup() |>
  select(-N) |>
  pivot_wider(names_from = kierunek,
              values_from = czestosc,
              names_sort = TRUE) |>
  mutate(miesiac = miesiac_rzymski(miesiac)) |>
  tibble::column_to_rownames(var = "miesiac")

# Wiersz roczny dopasowujemy po NAZWACH kolumn, a nie pozycyjnie: kolejność kolumn
# w tab_2_dane wynika z pivot_wider, a w czestosc_rok z group_by - gdyby się
# rozjechały, częstości trafiłyby pod niewłaściwe kierunki.
wiersz_roczny = czestosc_rok$czestosc[match(names(tab_2_dane),
                                            as.character(czestosc_rok$kierunek))]

tab_2_dane = tab_2_dane |>
  rbind(wiersz_roczny) |>
  mutate(C = cisza_3) |>
  mutate(across(where(is.numeric), \(x) round(x, 1)))

rownames(tab_2_dane)[nrow(tab_2_dane)] <- "Rok"

tab_2_dane = tab_2_dane |> rownames_to_column(var = "miesiac") |> relocate(miesiac)


# ------------------------------------------------------------------------------
# TABELA 3: częstość kierunków wiatru i cisz (C) oraz prędkość wiatru
# ------------------------------------------------------------------------------
# Układ pionowy: wiersze to kierunki wiatru (na końcu cisza C), kolumny to liczba
# pomiarów, częstość i średnia prędkość. Kierunki są w porządku kompasowym, bo
# kierunek jest faktorem. Podpisy kolumn ustawia qmd przez set_header_labels.

# Wszystkie trzy charakterystyki w jednym summarise, żeby prędkość nie była
# doklejana pozycyjnie z osobnej ramki.
# .drop = FALSE jak w tabeli 2: kierunek bez ani jednej doby zostaje w zestawieniu
# z N = 0 i częstością 0,0%, zamiast wypadać z tabeli i z róży wiatrów na rycinie 6.
# Zera zostają TUTAJ, bo z tej ramki rysowana jest rycina 6 i słupek zerowej długości
# jest tam poprawną informacją; na kropki zamienia je dopiero tab_3_dane niżej.
# Prędkość jest wtedy średnią z pustego zbioru, czyli NaN - w tabeli kropka, bo dla
# kierunku bez pomiarów nie ma czego uśredniać.
dane_wiatr_wg_kierunkow = wiatr_kierunki |>
  group_by(kierunek, .drop = FALSE) |>
  summarise(N = n(), V = mean(WIV, na.rm = TRUE), .groups = "drop") |>
  mutate("%" = (N/sum(N)) * 100) |>
  relocate(kierunek, N, `%`, V) |>
  mutate(across(c(`%`, V), \(x) round(x, 1)))

# Wiersz ciszy. Częstość liczona względem tej samej liczby pomiarów co częstości
# kierunków, czyli wobec dób z wyznaczonym kierunkiem; prędkość z definicji zerowa.
cisza = round(c(cisza_r, (cisza_r/nrow(wiatr_kierunki)) * 100, 0),1)

# Kierunek, z którego ani razu nie zawiało, dostaje w tabeli kropkę zamiast zera -
# liczba pomiarów i częstość idą na NA. Wiersz "Cisza" zostaje nietknięty: jego zera
# są wartościami (prędkość podczas ciszy z definicji wynosi 0), a nie brakiem
# wystąpienia kierunku.
tab_3_dane = dane_wiatr_wg_kierunkow |>
  mutate(kierunek = as.character(kierunek),
         `%` = ifelse(N == 0, NA_real_, `%`),
         N   = ifelse(N == 0, NA_integer_, N)) |>
  rbind(data.frame(kierunek = "Cisza", N = cisza[1], `%` = cisza[2], V = cisza[3],
                   check.names = FALSE))

# Rok analizowany bez ani jednej doby w widoku wiatru (widok dobowy ma rok wpisany na
# sztywno w definicji) dałby tabele 2 i 3 wypełnione samymi kropkami. Zostawiamy je
# puste - raport i arkusz pomijają wtedy obie tabele w całości.
if (nrow(a1_wiatr_dobowe_vw) == 0) {
  tab_2_dane = tab_2_dane[0, ]
  tab_3_dane = tab_3_dane[0, ]
}


# ------------------------------------------------------------------------------
# TABELA 4: temperatura i opad roku analizowanego na tle wielolecia
# ------------------------------------------------------------------------------
# Sześć wierszy (temperatura roku, średnia wieloletnia, ich różnica; to samo dla
# opadu, z tym że zamiast różnicy procent normy) w układzie miesiąc po miesiącu,
# plus kolumna "Rok" z podsumowaniem rocznym.

# Wartości roczne: rok analizowany wprost z wiersza RH, wielolecie policzone
# ze średnich miesięcznych, żeby kolumna "Rok" zgadzała się z sumą kolumn miesięcznych.
# Rok bez wiersza RH w bazie (rok zakwestionowany) daje NA, a nie wektor pusty -
# pusty wypadłby z c() niżej i przesunąłby wartości wiersza "Rok" o kolumnę.
wartosc_roku = function(kolumna) {
  x = a1_dane_agg_vw_roczne |> filter(rok_hydro == analizowany_rok) |> pull(all_of(kolumna))
  if (length(x) == 0) NA_real_ else x[1]
}
rok_suma_opadu = wartosc_roku("RR_T sum")
rok_temp_t_ad = wartosc_roku("TA_D avg")

# Wielolecie ze WSZYSTKICH miesięcy wielolecia, a nie tylko z tych, które ma rok
# analizowany - inaczej miesiąc zakwestionowany w roku analizowanym zaniżyłby
# wieloletnią sumę opadu.
wielolecie_suma_opadu = sum(wielolecie_miesieczne$RR_T_wielolecie, na.rm = TRUE)
wielolecie_t_ad = mean(wielolecie_miesieczne$TA_D_wielolecie, na.rm = TRUE)

# Wiersz "Rok" doklejany na końcu ramki miesięcznej - kolejność wartości musi
# odpowiadać kolejności kolumn w tab_4_zrodlo (pierwsze NA to kolumna miesiac).
dane_rok = c(NA, rok_temp_t_ad,  wielolecie_t_ad, rok_temp_t_ad -  wielolecie_t_ad, rok_suma_opadu, wielolecie_suma_opadu, (rok_suma_opadu/wielolecie_suma_opadu)*100)

nazwy_wierszy = c(paste0("T ",analizowany_rok),
                  paste0("T śr (",rok_poczatek,"-",rok_koniec, ")"),
                  paste0("T ",analizowany_rok,"- Tśr"),
                  paste0("P ",analizowany_rok),
                  paste0("P śr (",rok_poczatek,"-",rok_koniec, ")"),
                  paste0("P (",analizowany_rok,"/ P śr)*100"))

# Szkielet 12 miesięcy daje tabeli komplet kolumn miesięcznych w porządku roku
# hydrologicznego - tak jak tabele 6 i 7, gdzie robi to names_expand w pivot_wider.
# Wartości roku i wielolecia dokładamy do szkieletu OSOBNO: miesiąc, którego rok
# analizowany nie ma w bazie, zostaje w wierszach roku kropką, ale średnia wieloletnia
# tego miesiąca nadal stoi w swoim wierszu.
tab_4_zrodlo = tibble(miesiac = factor(miesiace_hydro, levels = miesiace_hydro)) |>
  left_join(select(a1_dane_agg_vw_rok, miesiac, `TA_D avg`, `RR_T sum`), by = "miesiac") |>
  left_join(select(wielolecie_miesieczne, miesiac, TA_D_wielolecie, RR_T_wielolecie),
            by = "miesiac") |>
  mutate(TA_D_roznica = `TA_D avg` - TA_D_wielolecie,
         RR_T_proc = (`RR_T sum`/RR_T_wielolecie)*100) |>
  select(miesiac, `TA_D avg`, TA_D_wielolecie, TA_D_roznica, `RR_T sum`, RR_T_wielolecie, RR_T_proc) |>
  as.data.frame() |> # tibble -> data.frame, bo rbind niżej dokłada zwykły wektor
  rbind(dane_rok) |>
  mutate(across(where(is.numeric), \(x) round(x, 1)),
         miesiac = fct_na_value_to_level(miesiac, level = "Rok"))

# Transponujemy WYŁĄCZNIE część liczbową, a nazwy kolumn bierzemy z kolumny miesiac.
# t() na całej ramce (z kolumną tekstową) zamieniłoby wszystkie wartości na napisy,
# a przy options(OutDec = ",") powstałyby napisy typu "4,4", których as.numeric()
# już nie odczyta - cała tabela wyszłaby pusta.
tab_4_dane = as.data.frame(t(tab_4_zrodlo[, -1]))

# Nazwy kolumn: etykiety miesięcy zapisem rzymskim, wiersz podsumowania jako "Rok".
# Bierzemy je z danych, więc nie zakładamy tu, ile kolumn miesięcznych ma tabela.
etykiety_tab_4 = as.character(tab_4_zrodlo$miesiac)
etykiety_tab_4[etykiety_tab_4 != "Rok"] = miesiac_rzymski(etykiety_tab_4[etykiety_tab_4 != "Rok"])
colnames(tab_4_dane) = etykiety_tab_4

tab_4_dane$Parametr = nazwy_wierszy
tab_4_dane = tab_4_dane |> relocate(Parametr)

# Tabela zestawia miesiące roku analizowanego z wieloleciem. Rok, dla którego baza nie
# ma ani jednego miesiąca, dałby tabelę z samymi kropkami w wierszach roku - zostawiamy
# ją pustą, a raport i arkusz pomijają ją wtedy w całości (patrz tworzenie_raportu.qmd).
if (nrow(a1_dane_agg_vw_rok) == 0) tab_4_dane = tab_4_dane[0, ]

rm(etykiety_tab_4, wartosc_roku)


# ------------------------------------------------------------------------------
# TABELA 5: wybrane elementy meteorologiczne w kolejnych latach wielolecia
# ------------------------------------------------------------------------------
# Wiersze to kolejne lata hydrologiczne, kolumny to elementy meteorologiczne.
# Pod spodem cztery wiersze podsumowania liczone z samego wielolecia: średnia,
# odchylenie standardowe, współczynnik zmienności i n - liczba lat, z których
# te trzy statystyki powstały.

# a1_dane_agg_vw_roczne to dokładnie ten sam wybór (wiersze RH z lat analizy),
# więc korzystamy z gotowego obiektu zamiast powtarzać filtr.
tab_5_dane = a1_dane_agg_vw_roczne |>
  select(rok_hydro,`PRES avg`,`TA_D avg`,`HH avg`,`RR_T sum`,`WIV avg`,
         `SOL_P h sum`,`SOL_T avg`)

# Podsumowania liczymy bez roku analizowanego - opisują samo wielolecie.
tmp <- tab_5_dane |> filter(rok_hydro %in% lata_wielolecia) |> select(-1)
# n liczymy osobno dla każdej kolumny: serie roczne bywają niepełne, więc średnia
# jednego elementu może pochodzić z innej liczby lat niż średnia sąsiedniego.
# Zaokrąglenie do jednego miejsca po przecinku nie rusza n (to liczba całkowita),
# ale zapis w raporcie i w arkuszu wymusza dla tego wiersza format bez części
# dziesiętnej - inaczej liczba lat wyglądałaby jak "30,0".
smr_df = data.frame(srednie = colMeans(tmp, na.rm = TRUE),
                    std = apply(tmp, 2, sd, na.rm = TRUE)) |>
  mutate(cv = (std/srednie) * 100,
         n = colSums(!is.na(tmp))) |>
  t() |>
  as.data.frame() |>
  mutate(across(where(is.numeric), \(x) round(x, 1))) |>
  magrittr::set_rownames(c(paste0(rok_poczatek,"-",rok_koniec), "STD", "CV", "n"))

rm(tmp)

tab_5_dane = tab_5_dane |>
  column_to_rownames(var = "rok_hydro") |>
  rbind(smr_df) |>
  kolumna_lata()


# ------------------------------------------------------------------------------
# TABELA 6: klasyfikacja termiczna
# ------------------------------------------------------------------------------
# Tabela 6 pokazuje średnie miesięczne temperatury, a bliźniacza tab_6B_dane -
# nazwy klas termicznych tych samych komórek. Z tab_6B_dane powstają macierze
# kolorów, którymi qmd maluje tło i czcionkę tabeli 6.

tab_6_dane = tabela_klasyfikacji(a1_klasyfikacja_termiczna_vw, "TA_D okres") |>
  dodaj_srednia() |>
  kolumna_lata()

# Kolumny wychodzą z pivot_wider jako numery miesięcy - zamieniamy je na rzymskie
# tutaj, żeby nie trzeba było podmieniać etykiet w qmd.
colnames(tab_6_dane) = c("Lata", miesiace_rzymskie, "Rok")

# Klasyfikacja słowna. Wiersz odpowiadający wierszowi "Średnia" w tabeli 6 zostaje
# pusty - dla średniej wielolecia klasyfikacji się nie podaje.
tab_6B_dane = tabela_klasyfikacji(a1_klasyfikacja_termiczna_vw, "klasyfikacja")

tab_6B_dane = tab_6B_dane |>
  rbind(rep(NA_character_, ncol(tab_6B_dane))) |>
  magrittr::set_rownames(c(rownames(tab_6B_dane), "Średnia")) |>
  kolumna_lata()

# Kolory komórek - wszystkie kolumny poza "Lata", czyli miesiące i "Rok".
kolory_bg_temp = as.matrix(apply(select(tab_6B_dane, -Lata), 2, koloruj_temp))
kolory_czcionka_temp = as.matrix(apply(select(tab_6B_dane, -Lata), 2, koloruj_czcionka_temp))

# Legenda: klasa termiczna i odpowiadający jej przedział odchyleń od średniej.
# Kolumna kolor jest pusta - wypełnia ją qmd tłem komórki.
# Odchylenie standardowe oznaczamy jako SD, zgodnie z tabelą 6.1.6 metodyk ZMŚP
# (Klasyfikacja termiczna roku lub miesiąca według Lorenc i Boguckiej 1996).
tab_6_legenda = data.frame(
  klasa = names(kolory_klasyfikacja_termiczna),
  zakres = c(
    "t > śr + 2,5SD",
    "śr + 2,0SD < t ≤ śr + 2,5SD",
    "śr + 1,5SD < t ≤ śr + 2,0SD",
    "śr + 1,0SD < t ≤ śr + 1,5SD",
    "śr + 0,5SD < t ≤ śr + 1,0SD",
    "śr - 0,5SD ≤ t ≤ śr + 0,5SD",
    "śr - 1,0SD ≤ t < śr - 0,5SD",
    "śr - 1,5SD ≤ t < śr - 1,0SD",
    "śr - 2,0SD ≤ t < śr - 1,5SD",
    "śr - 2,5SD ≤ t < śr - 2,0SD",
    "t < śr - 2,5SD"
  ),
  kolor = ""
)


# ------------------------------------------------------------------------------
# TABELA 7: klasyfikacja opadowa
# ------------------------------------------------------------------------------
# Tabela 7 łączy w jednej komórce dwie wartości: sumę opadu w mm (tab_7A_dane)
# i tę samą sumę jako procent normy wielolecia (tab_7B_dane). Procenty decydują
# też o kolorach komórek.

tab_7A_dane = tabela_klasyfikacji(a1_klasyfikacja_opadowa_vw, "opad_okres") |>
  dodaj_srednia()

tab_7B_dane = tabela_klasyfikacji(a1_klasyfikacja_opadowa_vw, "procent_opad_wiel") |>
  dodaj_srednia(cyfry = 0)

# Sklejenie obu tabel komórka po komórce: "mm\n(procent%)". map2_df gubi nazwy
# wierszy, więc lata bierzemy z tab_7A_dane.
# Brak pomiaru zapisujemy kropką, tak jak w pozostałych tabelach (na_str = "."
# w formatowanie_tabel.R). Bez jawnego warunku paste0() skleiłby sam napis "NA"
# i w komórce stanęłoby "NA (NA%)" - formatowanie w qmd już tego nie naprawi, bo
# dostaje gotowy tekst, a nie wartość NA. Procent bez sumy opadu nie ma sensu,
# więc brak sumy przesądza o całej komórce; sam brakujący procent (stacja bez
# normy wielolecia dla tego miesiąca) zostawia sumę i kropkę w nawiasie.
tab_7_dane <- map2_df(tab_7A_dane, tab_7B_dane,
                      ~ ifelse(is.na(.x), ".",
                               paste0(.x, "\n(", ifelse(is.na(.y), ".", .y), "%)"))) |>
  as.data.frame() |>
  mutate(Lata = rownames(tab_7A_dane)) |>
  relocate(Lata)

colnames(tab_7_dane) = c("Lata", miesiace_rzymskie, "Rok")

# Kolory komórek. Miesiące i kolumnę roczną kolorujemy wg innych progów, dlatego
# są rozdzielone. tab_7B_dane nie ma kolumny "Lata", więc miesiące to wszystko
# poza "Rok". Ostatni wiersz to "Średnia" - zostaje bez kolorowania.
kolory_bg_miesiace_opad = as.matrix(apply(select(tab_7B_dane, -Rok), 2, koloruj_miesiac_opad))
kolory_bg_lata_opad = as.matrix(koloruj_rok_opad(tab_7B_dane$Rok))
kolory_czcionka_m_opad = as.matrix(apply(select(tab_7B_dane, -Rok), 2, koloruj_czcionka_m_opad))
kolory_czcionka_r_opad = as.matrix(koloruj_czcionka_r_opad(tab_7B_dane$Rok))

kolory_bg_lata_opad[nrow(kolory_bg_lata_opad),]<- "white"
kolory_bg_miesiace_opad[nrow(kolory_bg_miesiace_opad),]<- "white"
kolory_czcionka_m_opad[nrow(kolory_czcionka_m_opad),]<- "black"
kolory_czcionka_r_opad[nrow(kolory_czcionka_r_opad),]<- "black"

# Legenda dwuczęściowa: progi miesięczne i roczne są inne, więc opisane osobno.
# Kolumny kolor i kolor2 są puste - wypełnia je qmd tłem komórki.
tab_7_legenda = data.frame(
  miesiac = "Miesiąc",
  kolor = "",
  klas_m = c("<25%","25-49%","50-74%","75-124%","125-149%","150-175%",">175%"),
  klasyfikacja_opad = names(kolory_klasyfikacja_opadowa),
  rok = "Rok",
  kolor2 = "",
  klas_r = c("<50%","50-74%","75-89%","90-110%","111-125%","126-150%",">150%"),
  klasyfikacja_opad = names(kolory_klasyfikacja_opadowa)
)


# ------------------------------------------------------------------------------
# TABELA 8: liczba dni charakterystycznych
# ------------------------------------------------------------------------------
# Druga tabela wyjątkowa: ten sam zakres i ta sama kolejność kolumn co w tabeli 1
# (14 miesięcy dwóch lat kalendarzowych plus XI-X i I-XII), tyle że z liczbami dni.
# Układ nagłówka liczony osobno, bo tabela pochodzi z innych widoków niż tabela 1.

# Wiersze tabeli; ostatni to liczba dni z opadem śniegu, doklejana z widoku agregatów.
# Etykiety wierszy łamane na trzy linie: "Dni", kategoria, kryterium. Zapis
# w jednej linii wymuszałby szeroką kolumnę 1, przez co na kolumny miesięczne
# zostałoby za mało miejsca, a daty w wierszu "Data wystąpienia" łamałyby się na
# dwie linie. Najdłuższa pojedyncza linia to "(TA_N < -10\u00b0C)".
tab8_nazwy_wierszy = c('Dni',
                       'Dni\nbardzo upalne\n(TA_X > 35\u00b0C)',
                       'Dni\nupalne\n(TA_X > 30\u00b0C)',
                       'Dni\ngorące\n(TA_X > 25\u00b0C)',
                       'Dni\nprzymrozkowe\n(TA_N < 0\u00b0C)',
                       'Dni\nmroźne\n(TA_X < 0\u00b0C)',
                       'Dni\nbardzo mroźne\n(TA_N < -10\u00b0C)',
                       'Dni\nz opadem\n\u2265 0,1 mm',
                       'Dni\nz opadem\n\u2265 1,0 mm',
                       'Dni\nz opadem\n\u2265 10,0 mm',
                       'Max. opad\ndobowy',
                       'Data\nwystąpienia',
                       'Liczba dni\nz opadem śniegu')

# Kluczem złączenia z tab_8_zrodlo są oba lata, miesiąc i typ okresu. Wszystkie widoki
# przeszły tę samą konwersję, więc miesiac jest po obu stronach faktorem o identycznych
# poziomach i złączenie nie wymaga sprowadzania go do liczby.
sch_dni = a1_dane_agg_vw |>
  filter(rok_hydro == analizowany_rok | rok_kal == analizowany_rok) |>
  select(rok_kal, rok_hydro, miesiac, okres_typ,`SC_H ile_dni`)

# Szkielet 16 okresów jak w tabeli 1: okres bez wpisu w bazie zostaje kolumną kropek,
# a tabela ma zawsze komplet kolumn, na których opiera się formatowanie w qmd.
tab_8_zrodlo = szkielet_okresow() |>
  left_join(
    dni_charakterystyczne |>
      select(rok_kal, rok_hydro, miesiac, okres_typ,
             `bardzo upalne`, `upalne`, `gorace`, `przymrozkowe`, `mrozne`, `bardzo mrozne`,
             `>= 0,1mm`, `>= 1,0mm`, `>= 10,0mm`, `opad max`, `dzien opad max`),
    by = c("okres_typ", "rok_kal", "rok_hydro", "miesiac")) |>
  relocate(rok_kal, rok_hydro, miesiac, okres_typ) |>
  arrange(factor(okres_typ, levels = c("M", "RH", "RK")), rok_kal, nr_miesiaca(miesiac))

rm(szkielet_okresow)

naglowek_tab_8 = uklad_naglowka(tab_8_zrodlo)

tab_8_dane = tab_8_zrodlo |>
  left_join(sch_dni, by = c("rok_kal", "rok_hydro", "miesiac", "okres_typ")) |>
  mutate(
    miesiac = case_when(
      okres_typ == "RH" ~ "XI-X",
      okres_typ == "RK" ~ "I-XII",
      !is.na(miesiac) ~ miesiac_rzymski(miesiac),
      TRUE ~ NA_character_
    )
  ) |>
  mutate(
    # Data maksymalnego opadu dobowego w formacie "dzień MIESIĄC_RZYMSKI". Wektorowo -
    # as.Date, format i as.roman działają na całej kolumnie naraz. Brak daty (miesiąc
    # bez opadu) musi zostać NA, inaczej paste() skleiłby z dwóch NA napis "NA NA".
    `dzien opad max` = {
      data_obj <- as.Date(`dzien opad max`)
      if_else(is.na(data_obj),
              NA_character_,
              paste(as.integer(format(data_obj, "%d")),
                    as.roman(as.integer(format(data_obj, "%m")))))
    }) |>
  mutate(across(where(is.numeric), \(x) round(x, 1)),
         across(everything(), as.character)) |>
  select(-okres_typ, -rok_kal, -rok_hydro) |>
  t() |>
  as.data.frame() |>
  mutate(Dni = tab8_nazwy_wierszy) |>
  relocate(Dni)



# ------------------------------------------------------------------------------
# TABELE 9 i 10: ekstremalne zjawiska pogodowe
# ------------------------------------------------------------------------------
# Odpowiednik sekcji "Ekstremalne zjawiska pogodowe" z raportów Stacji Bazowych,
# gdzie ta sama lista zjawisk jest co roku opisywana prozą. Tabele zbierają je
# w stałym układzie: zjawisko - kryterium - liczba przypadków - termin - wartość
# skrajna, dzięki czemu kolejne roczniki dają się porównać wiersz po wierszu.
# Podział na dwie tabele idzie po elemencie: tabela 9 to temperatura powietrza,
# tabela 10 - opad atmosferyczny wraz z pokrywą śnieżną, która jest jego formą
# zalegającą. Każda mieści się wtedy na stronie bez łamania wierszy.
#
# Wszystkie kryteria pochodzą z metodyk ZMŚP (tab. 6.1.4, 6.1.6, 6.1.7, 6.1.8)
# albo z progów podanych wprost w raportach wzorcowych (ciągi dni, susza).
#
# Noce tropikalnej nie ma na liście: TA_N jest minimum całej doby, a nie samej
# nocy, więc z danych dobowych nie da się sprawdzić kryterium tego zjawiska.
#
# ZERO TO NIE BRAK DANYCH: zjawisko, które nie wystąpiło, dostaje 0, a element
# w ogóle niemierzony przez stację - NA, które formatowanie zamieni na kropkę.
# Dlatego każdy licznik przechodzi przez liczba_dni(), sprawdzające najpierw,
# czy seria pomiarowa w ogóle istnieje.

# Ciągi kolejnych dni spełniających warunek. rle() daje długości serii, a cumsum()
# pozycje ich końców - stąd daty pierwszego i ostatniego dnia każdego ciągu oraz
# suma wartości w jego obrębie (potrzebna dla ciągów opadowych).
ciagi_dni = function(warunek, daty, wartosci = NULL) {
  warunek[is.na(warunek)] <- FALSE
  serie <- rle(warunek)
  koniec <- cumsum(serie$lengths)
  poczatek <- koniec - serie$lengths + 1
  w <- which(serie$values)
  data.frame(
    od   = daty[poczatek[w]],
    do   = daty[koniec[w]],
    dni  = serie$lengths[w],
    suma = vapply(w, function(i) if (is.null(wartosci)) NA_real_ else
      sum(wartosci[poczatek[i]:koniec[i]], na.rm = TRUE), numeric(1))
  )
}

# Data w postaci "21.08" - dzień i miesiąc, bez roku, bo rok niesie tytuł tabeli.
data_dm = function(x) format(as.Date(x), "%d.%m")

# Liczba dni spełniających warunek. Brak serii daje NA, a nie zero: "nie było
# takich dni" i "nie wiadomo, bo nie mierzono" to dwie różne odpowiedzi.
liczba_dni = function(warunek, seria) if (ma_dane(seria)) sum(warunek, na.rm = TRUE) else NA_integer_

# Wartość skrajna wraz z datą jej wystąpienia.
skrajna = function(wartosci, daty, funkcja) {
  if (!ma_dane(wartosci)) return(list(wartosc = NA_real_, data = NA_character_))
  i <- which(wartosci == funkcja(wartosci, na.rm = TRUE))[1]
  list(wartosc = wartosci[i], data = data_dm(daty[i]))
}

# Liczba z jednym miejscem po przecinku i jednostką; NA zostaje NA, żeby
# formatowanie w qmd zamieniło je na kropkę.
z_jednostka = function(x, jednostka, cyfry = 1) {
  if (length(x) == 0 || is.na(x)) return(NA_character_)
  paste0(formatC(x, format = "f", digits = cyfry, decimal.mark = ","), jednostka)
}

# Lista okresów w postaci "14.03-12.04 (30 dni); 14.04-27.04 (14 dni)".
lista_ciagow = function(df) {
  if (nrow(df) == 0) return(NA_character_)
  paste(paste0(data_dm(df$od), "-", data_dm(df$do), " (", df$dni, " dni)"), collapse = "; ")
}

# Wiersz tabeli. Puste komórki - zarówno "zjawisko nie wystąpiło", jak i "elementu
# nie mierzono" - zostają jako NA; fmt_komorki() w raporcie zamienia je na kropkę.
# Tabele 9 i 10 nie używają myślnika: obie sytuacje oznacza ta sama kropka, tak jak
# mówią objaśnienia pod tabelami.
w9 = function(zjawisko, kryterium = NA_character_, liczba = NA_character_,
              termin = NA_character_, wartosc = NA_character_) {
  data.frame(Zjawisko = zjawisko, Kryterium = kryterium,
             `Liczba wystąpień` = as.character(liczba), Termin = termin,
             `Wartość` = wartosc, check.names = FALSE)
}

# Dane źródłowe: doba roku hydrologicznego, klasyfikacje miesięczne i roczna,
# progi opadowe oraz pokrywa śnieżna.
dob9  <- a1_dane_dobowe_vw[order(a1_dane_dobowe_vw$data_pomiar), ]
mies9 <- nr_miesiaca(dob9$miesiac)
klas_t_m <- a1_klasyfikacja_termiczna_vw |>
  filter(okres_typ == "MH" & rok_hydro == analizowany_rok)
klas_t_r <- a1_klasyfikacja_termiczna_vw |>
  filter(okres_typ == "RH" & rok_hydro == analizowany_rok)
klas_o_m <- a1_klasyfikacja_opadowa_vw |>
  filter(okres_typ == "MH" & rok_hydro == analizowany_rok)
klas_o_r <- a1_klasyfikacja_opadowa_vw |>
  filter(okres_typ == "RH" & rok_hydro == analizowany_rok)
opady9 <- a1_dni_charakterystyczne_opady_vw |>
  filter(okres_typ == "RH" & rok_hydro == analizowany_rok)
snieg9 <- a1_pokrywa_sniezna_vw |> filter(rok_hydro == analizowany_rok)

# Miesiące skrajne: liczba oraz wykaz "MIESIĄC (klasa)". Klasy skrajne są
# w palecie na pierwszych i ostatnich pozycjach, więc bierzemy je stamtąd,
# zamiast wypisywać nazwy po raz drugi.
klasy_cieple  <- names(kolory_klasyfikacja_termiczna)[1:3]
klasy_chlodne <- names(kolory_klasyfikacja_termiczna)[9:11]

miesiace_klas = function(dane, klasy) {
  w <- dane |> filter(klasyfikacja %in% klasy)
  if (nrow(w) == 0) return(NA_character_)
  paste(paste0(miesiac_rzymski(w$miesiac), " (", w$klasyfikacja, ")"), collapse = "; ")
}

# Skrajne wartości temperatury.
ta_x_max <- skrajna(dob9$TA_X, dob9$data_pomiar, max)
ta_n_min <- skrajna(dob9$TA_N, dob9$data_pomiar, min)
ta_d_max <- skrajna(dob9$TA_D, dob9$data_pomiar, max)
ta_d_min <- skrajna(dob9$TA_D, dob9$data_pomiar, min)

# Przymrozki. Wiosenny to OSTATNI przymrozek pierwszej połowy roku kalendarzowego,
# jesienny - PIERWSZY z drugiej połowy. Podział po miesiącach kalendarzowych,
# a nie po dacie, bo rok hydrologiczny zaczyna się w listopadzie i jego pierwsze
# dwa miesiące należą do jesieni roku POPRZEDNIEGO.
przym <- !is.na(dob9$TA_N) & dob9$TA_N < 0
wiosna9 <- which(przym & mies9 %in% 1:6)
jesien9 <- which(przym & mies9 %in% 7:10)

# Ciągi dni bez opadu i z opadem. Dzień bezopadowy to doba poniżej progu
# mierzalności (0,1 mm) - obejmuje to również opad śladowy.
suchy9 <- !is.na(dob9$RR_T) & dob9$RR_T < 0.1
mokry9 <- !is.na(dob9$RR_T) & dob9$RR_T >= 0.1
bezopadowe <- ciagi_dni(suchy9, dob9$data_pomiar)
susza      <- bezopadowe[bezopadowe$dni >= 15, ]
bezopadowe <- bezopadowe[bezopadowe$dni > 7, ]
opadowe    <- ciagi_dni(mokry9, dob9$data_pomiar, dob9$RR_T)
opadowe    <- opadowe[opadowe$dni > 5 & opadowe$suma > 50, ]

# Miesięczne sumy opadu roku analizowanego - do skrajnych miesięcy.
opad_m <- a1_dane_agg_vw_rok[!is.na(a1_dane_agg_vw_rok$`RR_T sum`), ]
opad_m_max <- if (nrow(opad_m)) opad_m[which.max(opad_m$`RR_T sum`), ] else NULL
opad_m_min <- if (nrow(opad_m)) opad_m[which.min(opad_m$`RR_T sum`), ] else NULL

# Liczba dni z opadem przekraczającym próg - wprost z widoku dni charakterystycznych.
dni_opad = function(kolumna) {
  if (nrow(opady9) == 0 || is.na(opady9[[kolumna]][1])) NA_integer_ else as.integer(opady9[[kolumna]][1])
}

tab_9_dane <- bind_rows(
  w9("Klasyfikacja termiczna roku", "wg Lorenc i Boguckiej, tab. 6.1.6",
     wartosc = if (nrow(klas_t_r) && !is.na(klas_t_r$klasyfikacja[1])) klas_t_r$klasyfikacja[1] else NA_character_),
  w9("Miesiące ciepłe skrajne", paste(klasy_cieple, collapse = ", "),
     liczba = if (nrow(klas_t_m)) sum(klas_t_m$klasyfikacja %in% klasy_cieple) else NA_integer_,
     termin = miesiace_klas(klas_t_m, klasy_cieple)),
  w9("Miesiące chłodne skrajne", paste(klasy_chlodne, collapse = ", "),
     liczba = if (nrow(klas_t_m)) sum(klas_t_m$klasyfikacja %in% klasy_chlodne) else NA_integer_,
     termin = miesiace_klas(klas_t_m, klasy_chlodne)),
  w9("Absolutne maksimum temperatury", liczba = if (is.na(ta_x_max$wartosc)) NA_integer_ else 1,
     termin = ta_x_max$data, wartosc = z_jednostka(ta_x_max$wartosc, "°C")),
  w9("Absolutne minimum temperatury", liczba = if (is.na(ta_n_min$wartosc)) NA_integer_ else 1,
     termin = ta_n_min$data, wartosc = z_jednostka(ta_n_min$wartosc, "°C")),
  w9("Najwyższa średnia dobowa", liczba = if (is.na(ta_d_max$wartosc)) NA_integer_ else 1,
     termin = ta_d_max$data, wartosc = z_jednostka(ta_d_max$wartosc, "°C")),
  w9("Najniższa średnia dobowa", liczba = if (is.na(ta_d_min$wartosc)) NA_integer_ else 1,
     termin = ta_d_min$data, wartosc = z_jednostka(ta_d_min$wartosc, "°C")),
  w9("Dni ze średnią dobową ≥ 20°C", "TA_D ≥ 20,0°C",
     liczba = liczba_dni(dob9$TA_D >= 20, dob9$TA_D)),
  w9("Dni ze średnią dobową ≤ -10°C", "TA_D ≤ -10,0°C",
     liczba = liczba_dni(dob9$TA_D <= -10, dob9$TA_D)),
  w9("Dni ekstremalnie upalne", "TA_X > 35,0°C",
     liczba = liczba_dni(dob9$TA_X > 35, dob9$TA_X)),
  w9("Dni ekstremalnie mroźne", "TA_N < -10,0°C",
     liczba = liczba_dni(dob9$TA_N < -10, dob9$TA_N)),
  w9("Ostatni przymrozek wiosenny", "TA_N < 0,0°C",
     liczba = if (!ma_dane(dob9$TA_N)) NA_integer_ else length(wiosna9) > 0,
     termin = if (length(wiosna9)) data_dm(dob9$data_pomiar[max(wiosna9)]) else NA_character_,
     wartosc = if (length(wiosna9)) z_jednostka(dob9$TA_N[max(wiosna9)], "°C") else NA_character_),
  w9("Pierwszy przymrozek jesienny", "TA_N < 0,0°C",
     liczba = if (!ma_dane(dob9$TA_N)) NA_integer_ else length(jesien9) > 0,
     termin = if (length(jesien9)) data_dm(dob9$data_pomiar[min(jesien9)]) else NA_character_,
     wartosc = if (length(jesien9)) z_jednostka(dob9$TA_N[min(jesien9)], "°C") else NA_character_),
  w9("Dni przymrozkowe w maju", "TA_N < 0,0°C",
     liczba = liczba_dni(przym & mies9 == 5, dob9$TA_N[mies9 == 5]),
     termin = if (any(przym & mies9 == 5))
       paste(data_dm(dob9$data_pomiar[przym & mies9 == 5]), collapse = "; ") else NA_character_),
  w9("Przymrozek letni (VI-VIII)", "TA_N < 0,0°C",
     liczba = liczba_dni(przym & mies9 %in% 6:8, dob9$TA_N[mies9 %in% 6:8]),
     termin = if (any(przym & mies9 %in% 6:8))
       paste(data_dm(dob9$data_pomiar[przym & mies9 %in% 6:8]), collapse = "; ") else NA_character_),

)

tab_10_dane <- bind_rows(
  w9("Opad atmosferyczny", "", "", "", ""),
  w9("Klasyfikacja opadowa roku", "wg Kaczorowskiej, tab. 6.1.8",
     wartosc = if (nrow(klas_o_r) && !is.na(klas_o_r$klasyfikacja[1]))
       paste0(klas_o_r$klasyfikacja[1], "; ", round(klas_o_r$procent_opad_wiel[1]), "% normy") else NA_character_),
  w9("Maksymalny opad miesięczny", liczba = if (is.null(opad_m_max)) NA_integer_ else 1,
     termin = if (is.null(opad_m_max)) NA_character_ else miesiac_rzymski(opad_m_max$miesiac),
     wartosc = if (is.null(opad_m_max)) NA_character_ else z_jednostka(opad_m_max$`RR_T sum`, " mm")),
  w9("Minimalny opad miesięczny", liczba = if (is.null(opad_m_min)) NA_integer_ else 1,
     termin = if (is.null(opad_m_min)) NA_character_ else miesiac_rzymski(opad_m_min$miesiac),
     wartosc = if (is.null(opad_m_min)) NA_character_ else z_jednostka(opad_m_min$`RR_T sum`, " mm")),
  w9("Miesiące skrajnie wilgotne", "> 175% normy miesięcznej",
     liczba = if (nrow(klas_o_m)) sum(klas_o_m$klasyfikacja == "skrajnie wilgotny", na.rm = TRUE) else NA_integer_,
     termin = miesiace_klas(klas_o_m, "skrajnie wilgotny")),
  w9("Miesiące skrajnie suche", "< 25% normy miesięcznej",
     liczba = if (nrow(klas_o_m)) sum(klas_o_m$klasyfikacja == "skrajnie suchy", na.rm = TRUE) else NA_integer_,
     termin = miesiace_klas(klas_o_m, "skrajnie suchy")),
  w9("Ciągi dni bezopadowych", "> 7 dni bez opadu",
     liczba = if (ma_dane(dob9$RR_T)) nrow(bezopadowe) else NA_integer_,
     termin = lista_ciagow(bezopadowe),
     wartosc = if (nrow(bezopadowe)) paste(max(bezopadowe$dni), "dni") else NA_character_),
  w9("Susza meteorologiczna", "≥ 15 dni bez opadu",
     liczba = if (ma_dane(dob9$RR_T)) nrow(susza) else NA_integer_,
     termin = lista_ciagow(susza),
     wartosc = if (nrow(susza)) paste(max(susza$dni), "dni") else NA_character_),
  w9("Ciągi dni opadowych", "> 5 dni, suma > 50 mm",
     liczba = if (ma_dane(dob9$RR_T)) nrow(opadowe) else NA_integer_,
     termin = lista_ciagow(opadowe),
     wartosc = if (nrow(opadowe)) z_jednostka(max(opadowe$suma), " mm") else NA_character_),
  w9("Maksymalny opad dobowy",
     liczba = if (nrow(opady9) == 0 || is.na(opady9$`opad max`[1])) NA_integer_ else 1,
     termin = if (nrow(opady9) && !is.na(opady9$`dzien opad max`[1])) data_dm(opady9$`dzien opad max`[1]) else NA_character_,
     wartosc = if (nrow(opady9)) z_jednostka(opady9$`opad max`[1], " mm") else NA_character_),
  w9("Dni z opadem ≥ 10 mm", "p ≥ 10,0 mm", liczba = dni_opad(">= 10,0mm")),
  w9("Dni z opadem ≥ 20 mm", "p ≥ 20,0 mm", liczba = dni_opad(">= 20,0mm")),
  w9("Dni z opadem ≥ 30 mm", "p ≥ 30,0 mm", liczba = dni_opad(">= 30,0mm")),
  w9("Dni z opadem ≥ 50 mm", "p ≥ 50,0 mm", liczba = dni_opad(">= 50,0mm")),
  w9("Dni z opadem ≥ 100 mm", "p ≥ 100,0 mm", liczba = dni_opad(">= 100,0mm")),

  w9("Pokrywa śnieżna", "", "", "", ""),
  w9("Dni z pokrywą śnieżną", "SC_H ≥ 1 cm",
     liczba = if (nrow(snieg9) && !is.na(snieg9$`SC_H 1cm`[1])) as.integer(snieg9$`SC_H 1cm`[1]) else NA_integer_,
     wartosc = if (nrow(snieg9) && !is.na(snieg9$`SC_H max`[1]))
       paste0(z_jednostka(snieg9$`SC_H max`[1], " cm", 0), " (maksimum)") else NA_character_),
  w9("Dni z pokrywą ≥ 20 cm", "SC_H ≥ 20 cm",
     liczba = if (nrow(snieg9) && !is.na(snieg9$`SC_H 20cm`[1])) as.integer(snieg9$`SC_H 20cm`[1]) else NA_integer_)
)

# TRUE/FALSE z warunków obecności przymrozka zamieniamy na 1/0, żeby kolumna
# "Liczba wystąpień" była wszędzie liczbą, a nie mieszanką liczb i napisów "TRUE".
tab_9_dane$`Liczba wystąpień` <- sub("^TRUE$", "1",
                                     sub("^FALSE$", "0", tab_9_dane$`Liczba wystąpień`))

# Wiersze nagłówków grup w tabeli 10 (opad, pokrywa śnieżna) - qmd pogrubia je
# i scala; tutaj zostaje ich wykaz, żeby formatowanie nie musiało zgadywać po treści.
# Tabela 9 nagłówków nie ma: dotyczy w całości temperatury, co mówi jej tytuł.
tab_10_grupy <- which(tab_10_dane$Kryterium == "")

rm(dob9, mies9, klas_t_m, klas_t_r, klas_o_m, klas_o_r, opady9, snieg9,
   klasy_cieple, klasy_chlodne, ta_x_max, ta_n_min, ta_d_max, ta_d_min,
   przym, wiosna9, jesien9, suchy9, mokry9, bezopadowe, susza, opadowe,
   opad_m, opad_m_max, opad_m_min,
   ciagi_dni, data_dm, liczba_dni, skrajna, z_jednostka, lista_ciagow, w9,
   miesiace_klas, dni_opad)

# ==============================================================================
# SEKCJA 3: DANE DO RYCIN
#
# Obiekty budowane wyłącznie na potrzeby wykresów. Same ryciny powstają w plikach
# wykresy/ryc_*.R, uruchamianych przez tworzenie_wykresow.R. Ryciny korzystające
# wprost z widoków przygotowanych w sekcji 1 (np. 1-5, 10-14, 17) nie mają tu
# swoich obiektów.
# ==============================================================================

# ------------------------------------------------------------------------------
# Ryciny 10-14: nazwy linii w legendzie
# ------------------------------------------------------------------------------
# Trzy linie nanoszone na tło statystyk wielolecia. Pierwsza nazwa to rok analizowany
# zapisany tekstem, bo służy za poziom skali koloru w aes(color = ...).
nazwy_linii_doy = c(as.character(analizowany_rok), "Mediana", "Średnia")


# ------------------------------------------------------------------------------
# Rycina 21: klasyfikacja termiczna i opadowa lat hydrologicznych
# ------------------------------------------------------------------------------
# Po jednym wierszu na rok, z klasą termiczną i opadową obok siebie. Obie klasy
# jako faktory o poziomach z palet kolorów, żeby legenda miała stałą kolejność.
kt = a1_klasyfikacja_termiczna_vw |>
  filter(rok_hydro %in% lata_analizy
         & okres_typ == "RH") |>
  select(rok_hydro, klasyfikacja) |>
  rename(termiczna = "klasyfikacja")

klasyfikacja_temp_opad = a1_klasyfikacja_opadowa_vw |>
  filter(rok_hydro %in% lata_analizy
         & okres_typ == "RH") |>
  select(rok_hydro, klasyfikacja) |>
  rename(opadowa = "klasyfikacja") |>
  left_join(kt, by = "rok_hydro") |>
  mutate(termiczna = factor(termiczna, levels = names(kolory_klasyfikacja_termiczna)),
         opadowa = factor(opadowa, levels = names(kolory_klasyfikacja_opadowa)))

rm(kt)


# ------------------------------------------------------------------------------
# Rycina 9: miesięczne sumy usłonecznienia
# ------------------------------------------------------------------------------
# Rok analizowany i średnia wielolecia obok siebie, w postaci długiej - kolumna
# Okres rozdziela oba szeregi na wykresie słupkowym.
dane_uslonecznienie = a1_dane_agg_vw_rok |>
  select(miesiac, `SOL_P h sum`) |>
  left_join(wielolecie_miesieczne, by = "miesiac") |>
  select(miesiac, `SOL_P h sum`, `SOL_P_wielolecie`) |>
  rename(rok = `SOL_P h sum`, wielolecie = `SOL_P_wielolecie`) |>
  pivot_longer(cols = -miesiac,
               names_to = "Okres",
               values_to = "Uslonecznienie")


# ------------------------------------------------------------------------------
# Ryciny 22, 23 i 25-28: dni charakterystyczne
# ------------------------------------------------------------------------------
# Wszystkie te obiekty powstają tak samo: (opcjonalne) zsumowanie kategorii
# w grupach, rozłożenie kategorii do postaci długiej i nadanie im kolejności
# z palety kolorów. Różnią się tylko źródłem, kolumną identyfikującą i zestawem
# kategorii, więc buduje je jedna funkcja. Lista kategorii pochodzi z palety - tej
# samej, która ustala poziomy faktora, więc jedno nie może rozjechać się z drugim.
#  - id    - kolumny, które zostają w postaci długiej (miesiąc, rok lub oba),
#  - sumuj - TRUE, gdy dane wejściowe są drobniejsze niż wynik i trzeba je zsumować
#            w grupach; źródła _analizowany_rok i _r mają już docelową ziarnistość.
dane_dni_ch = function(dane, kategorie, id, sumuj = FALSE) {
  if (sumuj) {
    dane = dane |>
      group_by(across(all_of(id))) |>
      summarise(across(all_of(kategorie), \(x) sum(x, na.rm = TRUE)), .groups = "drop")
  }

  dane |>
    select(all_of(c(id, kategorie))) |>
    pivot_longer(all_of(kategorie), names_to = "kategoria", values_to = "wartosc") |>
    mutate(kategoria = factor(kategoria, levels = kategorie))
}

kategorie_opad = names(kolory_dni_charakterystyczne_opad)
kategorie_temp = names(kolory_dni_charakterystyczne_temp)

# Dni charakterystyczne opadu: miesiące roku analizowanego (ryciny 23 i 26A),
# miesiące całego wielolecia (26B) i sumy roczne (26C).
ryc_dni_ch_opad_analizowany_rok = dane_dni_ch(dni_charakterystyczne_analizowany_rok,
                                              kategorie_opad, "miesiac")

ryc_dni_ch_opad_m = dane_dni_ch(dni_charakterystyczne_m, kategorie_opad,
                                "miesiac", sumuj = TRUE)

# Miesiąc po miesiącu w każdym roku osobno - dane heatmapy z ryciny 28,
# odpowiednik ryc_dni_ch_temp_m_r rysowanego na rycinie 27.
ryc_dni_ch_opad_m_r = dane_dni_ch(dni_charakterystyczne_m, kategorie_opad,
                                  c("miesiac", "rok_hydro"), sumuj = TRUE)

ryc_dni_ch_opad_r = dane_dni_ch(dni_charakterystyczne_r, kategorie_opad, "rok_hydro")

# Dni charakterystyczne temperatury: miesiące roku analizowanego (ryciny 22 i 25A),
# miesiące całego wielolecia (25B), miesiąc po miesiącu w każdym roku (heatmapa 27)
# oraz sumy roczne (25C).
ryc_dni_ch_temp_analizowany_rok = dane_dni_ch(dni_charakterystyczne_analizowany_rok,
                                              kategorie_temp, "miesiac")

ryc_dni_ch_temp_m = dane_dni_ch(dni_charakterystyczne_m, kategorie_temp,
                                "miesiac", sumuj = TRUE)

ryc_dni_ch_temp_m_r = dane_dni_ch(dni_charakterystyczne_m, kategorie_temp,
                                  c("miesiac", "rok_hydro"), sumuj = TRUE)

ryc_dni_ch_temp_r = dane_dni_ch(dni_charakterystyczne_r, kategorie_temp, "rok_hydro")


# ------------------------------------------------------------------------------
# Ryciny 29 i 30: kompletność serii danych
# ------------------------------------------------------------------------------
# Widok podaje dla każdego elementu kolumnę "<element> kompletnosc" - procent
# wymaganych pomiarów, które faktycznie są w bazie za dany miesiąc. To ona
# przesądza, czy w ogóle powstał agregat: baza wylicza sumę opadu tylko przy 100%
# kompletności miesiąca I roku, a pozostałe elementy agreguje od 90% w miesiącu
# (dla wartości rocznych - przy 90% w każdym miesiącu). Stąd luki w seriach:
# nie są przeoczeniem, tylko odmową policzenia średniej z niepełnych danych.
#
# NULL w kolumnie kompletności znaczy co innego niż 0%: NULL to brak pomiaru
# dla tego miesiąca, a 0% to zarejestrowana seria, w której nie ma ani jednego
# wymaganego pomiaru. Rycina rozróżnia oba przypadki, więc NIE zlepiamy ich tutaj.
kolumny_kompletnosci = grep(" kompletnosc$", names(a1_dane_agg_vw), value = TRUE)

# Postać długa: jeden wiersz na (okres, element). Pivot obejmuje wszystkie kolumny
# kompletności naraz, więc dołożenie elementu w bazie nie wymaga zmiany w kodzie.
dlugie_kompletnosci = function(dane) {
  dane |>
    pivot_longer(all_of(kolumny_kompletnosci),
                 names_to = "parametr", values_to = "kompletnosc") |>
    mutate(parametr = factor(sub(" kompletnosc$", "", parametr),
                             levels = names(opisy_elementow)))
}

# complete() dokłada wiersze za miesiące i lata, których w widoku nie ma w ogóle -
# bez nich miesiąc bez wpisu zostawiłby na mapie białą dziurę nie do odróżnienia
# od tła, zamiast szarego kafelka "brak pomiaru". Zakres lat to lata z wierszami
# miesięcznymi (lata_ryc_29, taki sam dla ryciny 30), a nie całe wielolecie z parametrów:
# rok bez żadnego wpisu na brzegu serii nie rozciąga mapy, a luka w środku zostaje
# szarym pasem.
lata_ryc_29 = lata_z_danymi(a1_dane_agg_vw$rok_hydro[a1_dane_agg_vw$okres_typ == "M" &
                                                     a1_dane_agg_vw$rok_hydro %in% lata_analizy],
                            analizowany_rok)
lata_ryc_30 = lata_ryc_29

ryc_kompletnosc = a1_dane_agg_vw |>
  filter(rok_hydro %in% lata_analizy & okres_typ == "M") |>
  select(rok_hydro, miesiac, all_of(kolumny_kompletnosci)) |>
  dlugie_kompletnosci() |>
  complete(rok_hydro = min(lata_ryc_29):max(lata_ryc_29),
           miesiac, parametr)


# Klasa kompletności policzona tu, a nie w plikach rycin 29 i 30: dwie kopie cut()
# rozjechałyby się przy pierwszej zmianie progów. Przedziały są prawostronnie
# domknięte, więc przy całkowitych wartościach
# kompletności (0-100) wychodzą dokładnie klasy z nazw palety. Osobna klasa dla zera
# jest konieczna: 0% to zarejestrowana seria bez ani jednego pomiaru, a brak wpisu
# (NULL) to brak samej serii - na mapie muszą się różnić.
klasa_kompletnosci = function(x) {
  fct_na_value_to_level(
    cut(x, breaks = c(-1, 0, 49, 89, 99, 100),
        labels = head(names(kolory_kompletnosc), -1)),
    level = "brak pomiaru")
}

ryc_kompletnosc = mutate(ryc_kompletnosc, klasa = klasa_kompletnosci(kompletnosc))

rm(kolumny_kompletnosci, dlugie_kompletnosci, klasa_kompletnosci)


# ------------------------------------------------------------------------------
# Rycina 15: trend temperatury metodą Theila-Sena
# ------------------------------------------------------------------------------
# Nachylenie liczymy klasycznym estymatorem Theila-Sena: mediana nachyleń
# wszystkich par punktów (rok, wartość), wyznaczana na FAKTYCZNYCH latach.
# Nie korzystamy z sens.slope() z pakietu trend: ta funkcja przerywa pracę na
# brakach (na.fail), a luka w rocznej serii temperatury zdarza się na większości
# stacji bazowych.
# Samo usunięcie luk nie wystarczy: sens.slope() traktuje szereg jako
# równomierny, więc po wyrzuceniu brakującego roku sąsiednie punkty udawałyby
# kolejne lata i nachylenie wychodziłoby zawyżone. Liczenie na parach radzi
# sobie z lukami wprost - brakujący rok po prostu nie tworzy par - a nachylenie
# pozostaje wyrażone w °C na rok.
# Wyraz wolny liczymy klasycznie: mediana wartości minus nachylenie razy mediana
# lat - dzięki temu prosta jest wyrażona w latach kalendarzowych i pasuje do
# liczbowej osi X ryciny 15.
# Szereg musi być w porządku chronologicznym: test Manna-Kendalla bada trend
# w kolejności obserwacji, więc nieposortowane lata dałyby wynik przypadkowy.
tad_roczne <- a1_dane_agg_vw_roczne[order(a1_dane_agg_vw_roczne$rok_hydro),
                                    c("rok_hydro", "TA_D avg")]
tad_roczne <- tad_roczne[!is.na(tad_roczne$`TA_D avg`), ]
lata_tad <- tad_roczne$rok_hydro
wart_tad <- tad_roczne$`TA_D avg`

# Poniżej 5 lat z pomiarem trendu nie wyznaczamy: mediana nachyleń z kilku par
# punktów jest przypadkowa, a test Manna-Kendalla i tak nie wykryłby istotności.
# Rycina 15A rysuje się wtedy bez niebieskiej linii, a jej podpis mówi wprost,
# dlaczego jej nie ma.
if (length(wart_tad) >= 5) {
  pary <- combn(length(lata_tad), 2)
  nachylenia <- (wart_tad[pary[2, ]] - wart_tad[pary[1, ]]) /
                (lata_tad[pary[2, ]] - lata_tad[pary[1, ]])
  sen_slope_tad <- median(nachylenia[is.finite(nachylenia)])
  sen_intercept_tad <- median(wart_tad) - sen_slope_tad * median(lata_tad)
  # Istotność z testu Manna-Kendalla, liczona na latach, które mają pomiar.
  sen_pvalue_tad <- trend::mk.test(wart_tad)$p.value
  rm(pary, nachylenia)
} else {
  # Odmiana rzeczownika wprost w wywołaniu, żeby nie zostawiać w środowisku
  # zmiennej pomocniczej tworzonej tylko w tej gałęzi: 1 rok, 2-4 lata, 0 i 5+ lat.
  warning("Roczna seria temperatury ma tylko ", length(wart_tad), " ",
          if (length(wart_tad) == 1) "rok" else if (length(wart_tad) %in% 2:4) "lata" else "lat",
          " z pomiarem (potrzeba co najmniej 5) - trend Theila-Sena ",
          "nie został wyznaczony.", call. = FALSE)
  sen_slope_tad <- NA_real_
  sen_intercept_tad <- NA_real_
  sen_pvalue_tad <- NA_real_
}

# Wektor LICZBOWY - trafia wprost do geom_abline w ryc_15, więc wszystkie elementy
# muszą pozostać liczbami. Gdyby wstawić tu p-value jako tekst ("p < 0,001"), c()
# sprowadziłoby cały wektor (razem ze slope i intercept) do typu znakowego i wywróciło
# rysowanie wykresu przy każdym istotnym trendzie. Od postaci tekstowej jest osobny
# obiekt tad_trend_txt, budowany niżej.
tad_trend = c(slope = sen_slope_tad,
              intercept = sen_intercept_tad,
              pvalue = sen_pvalue_tad)

# Postać tekstowa do podpisu ryciny. Przecinek dziesiętny daje globalne
# options(OutDec = ",") - nie podmieniamy kropek ręcznie.
tad_trend_txt = c(
  slope = if (is.na(sen_slope_tad)) "nie wyznaczono" else as.character(round(sen_slope_tad, 4)),
  intercept = if (is.na(sen_intercept_tad)) "nie wyznaczono" else as.character(round(sen_intercept_tad, 4)),
  pvalue = if (is.na(sen_pvalue_tad)) {
    "nie wyznaczono"
  } else if (sen_pvalue_tad < 0.001) {
    "p < 0,001"
  } else {
    paste0("p = ", round(sen_pvalue_tad, 4))
  }
)

rm(tad_roczne, lata_tad, wart_tad, sen_intercept_tad, sen_slope_tad, sen_pvalue_tad)


# ------------------------------------------------------------------------------
# Ryciny wieloletnie: lata z danymi - zakres osi i wykaz lat w podpisie
# ------------------------------------------------------------------------------
# Każda rycina wieloletnia dostaje oś lat z WŁASNYCH danych: od pierwszego do
# ostatniego roku, dla którego jej źródło ma wiersz (patrz lata_z_danymi). Baza pomija
# lata zakwestionowane niezależnie w każdym widoku, więc wspólna oś rozciągnięta na
# całe wielolecie zostawiałaby na rycinach z krótszą serią puste odcinki na brzegach.
# Luka w środku serii zostaje na osi pustym miejscem. Przy serii kompletnej oś biegnie
# od pierwszego roku wielolecia do roku analizowanego. Te same lata wypisuje podpis
# ryciny w tworzenie_raportu.qmd (zakres_lat).
# lata_ryc_29 i lata_ryc_30 powstają wyżej, razem z danymi map kompletności.
lata_ryc_15 = lata_z_danymi(c(a1_dane_agg_vw_roczne$rok_hydro, a1_dane_agg_vw_m$rok_hydro),
                            analizowany_rok)
lata_ryc_16 = lata_ryc_15
lata_ryc_17 = lata_z_danymi(a1_pokrywa_sniezna_vw$rok_hydro, analizowany_rok)
lata_ryc_18 = lata_z_danymi(a1_dane_agg_vw_roczne$rok_hydro, analizowany_rok)
lata_ryc_19 = lata_ryc_18
lata_ryc_20 = lata_ryc_18
lata_ryc_21 = lata_z_danymi(klasyfikacja_temp_opad$rok_hydro, analizowany_rok)
# Ryciny 25 i 26: panel miesięcy wielolecia i panel kolejnych lat opisują ten sam
# zbiór lat - wiersze miesięczne i roczne dni charakterystycznych.
lata_ryc_25 = lata_z_danymi(c(dni_charakterystyczne_m$rok_hydro, dni_charakterystyczne_r$rok_hydro),
                            analizowany_rok)
lata_ryc_26 = lata_ryc_25
lata_ryc_27 = lata_z_danymi(ryc_dni_ch_temp_m_r$rok_hydro, analizowany_rok)
lata_ryc_28 = lata_z_danymi(ryc_dni_ch_opad_m_r$rok_hydro, analizowany_rok)
