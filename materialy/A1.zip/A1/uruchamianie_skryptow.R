################################################################################
# OPIS SKRYPTU
################################################################################
# uruchamianie_skryptow.R - skrypt sterujący całym raportem
#
# Punkt wejścia projektu. Wczytuje pakiety, ustawia przecinek jako separator
# dziesiętny, przygotowuje katalogi robocze, a następnie uruchamia kolejne
# etapy: pobranie danych z bazy, ich przetworzenie, wygenerowanie rycin, zapis
# obiektów potrzebnych raportowi i złożenie raportu w Quarto.
#
# Uwagi do kodu:
# Skrypt sam ustawia katalog roboczy na katalog, w którym leży - dzięki temu działa
# niezależnie od tego, skąd został uruchomiony, i użytkownik nie musi niczego ustawiać
# ręcznie. Projekt ma też plik A1.Rproj: otwarcie go w RStudio ustawia ten sam katalog.
# options(OutDec = ",") obowiązuje tylko w bieżącej sesji, dlatego to samo
# ustawienie jest powtórzone w chunku setup w tworzenie_raportu.qmd -
# quarto_render uruchamia osobną sesję R. Wczytanie RPostgres ma jeszcze jeden
# skutek: ładuje przestrzeń nazw bit64, bez której arytmetyka na kolumnach typu
# integer64 (liczby dni) liczyłaby na surowych bitach. Katalog wyniki/ jest
# kasowany i tworzony od nowa, żeby wyniki nie mieszały się z poprzednimi - ale
# dopiero PO udanym pobraniu danych. Katalogu dane/ nie kasujemy w ogóle: gdy baza
# jest niedostępna, poprzednie pobranie zostaje i można pracować offline.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - parametry/parametry.xlsx: parametry raportu
# - .Renviron: dane dostępowe do bazy
# - A1.Rproj: plik projektu RStudio (opcjonalny; otwarcie go ustawia katalog roboczy)
# - funkcje/styl_dokument.docx: szablon stylów Worda, na którym Quarto składa
#     raport (krój, marginesy oraz style Podpis tabeli, Objaśnienia, Tekst raportu)
# - skrypty etapów z katalogu skrypty/: pobieranie_danych.R,
#     przetwarzanie_danych.R, tworzenie_wykresow.R, zapis_tabel.R,
#     tworzenie_raportu.qmd
#     oraz pliki z katalogu funkcje/
################################################################################
# WYNIK
################################################################################
# - dane/dane.RData: widoki pobrane z bazy wraz z parametrami raportu
# - dane/dane_all.RData: obiekty, z których tworzenie_raportu.qmd składa raport
#     (dane, tabele, ryciny, parametry i stałe) - jawna lista, nie całe środowisko
# - wyniki/png/ i wyniki/svg/: ryciny zapisane do plików
# - wyniki/a1_tabele.xlsx: tabele 1-10, każda w osobnym arkuszu (tabele bez danych
#     za rok analizowany są pomijane, tak jak w raporcie)
# - wyniki/A1_raport_<stacja>.docx: gotowy raport
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - RPostgres
# - readxl
# - cowplot
# - flextable
# - scales
# - quarto
# - tidyverse
# - ggrepel
# - RColorBrewer
# - trend
# - openxlsx
################################################################################

## katalog roboczy ##
# Ustawiamy katalog roboczy na katalog TEGO pliku, żeby ścieżki względne (parametry/,
# funkcje/, skrypty/, dane/, wyniki/) działały niezależnie od tego, skąd skrypt został
# uruchomiony. Dzięki temu użytkownik nie musi sam ustawiać katalogu roboczego.
#
# Sposób ustalenia ścieżki zależy od tego, jak skrypt uruchomiono, więc sprawdzamy
# kolejno cztery możliwości - pierwsza, która zadziała, wygrywa:
#   1. Rscript / R CMD BATCH - ścieżka stoi w argumencie --file=,
#   2. przycisk Source w RStudio oraz source() - ścieżka jest w ramce wywołania ($ofile),
#   3. uruchamianie zaznaczonego kodu (Ctrl+Enter) - nie ma ani --file, ani ramki
#      source(), więc pytamy o ścieżkę samo RStudio (plik musi być zapisany na dysku),
#   4. srcref funkcji zdefiniowanej w tym pliku - działa, gdy R zachowuje źródła.
# Gdy żaden sposób nie zadziała, zostaje bieżący katalog roboczy i ostrzeżenie.
# Wszystkie funkcje użyte niżej są niezależne od systemu operacyjnego; normalizePath()
# zwraca ścieżkę w postaci właściwej dla Windows albo dla systemów uniksowych.
katalog_skryptu <- function() {
  argumenty <- commandArgs(trailingOnly = FALSE)
  arg_pliku <- grep("^--file=", argumenty, value = TRUE)
  if (length(arg_pliku) > 0) {
    return(dirname(normalizePath(sub("^--file=", "", arg_pliku[1]))))
  }

  for (ramka in rev(sys.frames())) {
    if (!is.null(ramka$ofile)) return(dirname(normalizePath(ramka$ofile)))
  }

  if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
    sciezka <- tryCatch(rstudioapi::getSourceEditorContext()$path,
                        error = function(e) "")
    if (length(sciezka) == 1 && nzchar(sciezka)) {
      return(dirname(normalizePath(sciezka)))
    }
  }

  katalog <- utils::getSrcDirectory(function() NULL)
  if (length(katalog) > 0 && nzchar(katalog)) return(normalizePath(katalog))

  warning("Nie udało się ustalić katalogu skryptu - zostaje bieżący katalog roboczy: ",
          getwd(), ".\n  Jeśli przebieg przerwie się na braku pliku parametrów, otwórz ",
          "projekt przez plik A1.Rproj.", call. = FALSE)
  getwd()
}

setwd(katalog_skryptu())
message("   Katalog roboczy: ", getwd())


## pakiety ##
# Komplet pakietów wymaganych przez projekt. Najpierw install.packages() dla tych,
# których nie ma w bibliotece, dopiero potem library() dla wszystkich - dzięki temu
# pierwsze uruchomienie na nowym komputerze nie kończy się błędem "there is no
# package called ...".
# tidyverse wciąga ggplot2, dplyr, tidyr, forcats i purrr.
pakiety = c("RPostgres", "readxl", "cowplot", "flextable", "scales", "quarto",
            "tidyverse", "ggrepel", "RColorBrewer", "trend", "openxlsx")

brakujace = setdiff(pakiety, rownames(installed.packages()))
if (length(brakujace) > 0) {
  message("   Instalowanie brakujących pakietów: ", paste(brakujace, collapse = ", "))
  install.packages(brakujace)
}

# Komunikaty startowe i ostrzeżenia pakietów (maskowanie funkcji, wersja R przy
# budowie pakietu) nic nie wnoszą do przebiegu, a zasypują konsolę, w której
# mają być widoczne komunikaty o postępie. Same błędy nadal przerywają pracę.
invisible(lapply(pakiety, function(p)
  suppressWarnings(suppressMessages(library(p, character.only = TRUE)))))

## Quarto ##
# Raport składa Quarto, ale dopiero w ostatnim kroku przebiegu. Bez tej kontroli brak
# Quarto ujawniłby się po kilkunastu minutach pobierania danych i obliczeń, które
# trzeba by powtórzyć od zera - dlatego sprawdzamy to na starcie.
#
# Pakiet R o nazwie quarto jest tylko łącznikiem do programu Quarto i szuka go WYŁĄCZNIE
# w dwóch miejscach: w zmiennej środowiskowej QUARTO_PATH oraz na ścieżce systemowej
# (PATH). RStudio wnosi własną kopię Quarto, ale wskazuje ją zmienną RSTUDIO_QUARTO,
# o której pakiet quarto nie wie - i na części instalacji ta kopia nie trafia na PATH.
# Wtedy quarto_render() przerywa pracę komunikatem o braku Quarto, choć Quarto jest
# zainstalowane. Poniżej podstawiamy więc wskazanie RStudio pod QUARTO_PATH.
if (is.null(quarto_path()) && nzchar(Sys.getenv("RSTUDIO_QUARTO"))) {
  wskazanie <- Sys.getenv("RSTUDIO_QUARTO")
  plik_quarto <- if (.Platform$OS.type == "windows") "quarto.exe" else "quarto"
  # RStudio podaje raz sam plik wykonywalny, raz katalog bin, raz katalog nadrzędny -
  # sprawdzamy wszystkie trzy postacie i bierzemy pierwszą, która jest plikiem.
  kandydaci <- c(wskazanie,
                 file.path(wskazanie, plik_quarto),
                 file.path(wskazanie, "bin", plik_quarto))
  kandydaci <- kandydaci[file.exists(kandydaci) & !dir.exists(kandydaci)]
  if (length(kandydaci) > 0) Sys.setenv(QUARTO_PATH = kandydaci[1])
}

if (is.null(quarto_path())) {
  stop("Nie znaleziono programu Quarto - bez niego raport nie powstanie.\n",
       "  Nowsze wersje RStudio mają Quarto wbudowane; jeśli go brakuje, pobierz je",
       " ze strony https://quarto.org, zainstaluj, uruchom RStudio ponownie",
       " i kliknij Source jeszcze raz.",
       call. = FALSE)
}
message("   Quarto: ", quarto_path())

## separator dziesiętny ##
# Przecinek niezależnie od ustawień regionalnych maszyny. OutDec steruje wyjściem
# format()/as.character(), a przez to również etykietami osi ggplot2 - dzięki temu
# wykresy i tabele wyglądają tak samo na każdym komputerze.
# UWAGA: quarto_render uruchamia osobną sesję R, więc ta sama opcja jest ustawiana
# także w chunku setup w tworzenie_raportu.qmd.
options(OutDec = ",")

# wczytanie funkcji pomocniczych, motywów wykresów i tabel oraz słownika stacji
source("funkcje/funkcje_pomocnicze.R")
source("funkcje/plot_theme.R")
source("funkcje/table_theme.R")
source("funkcje/slownik_stacji.R")

# Katalog na dane. NIE kasujemy go na starcie: gdyby baza okazała się niedostępna,
# zostalibyśmy bez danych z poprzedniego pobrania i bez możliwości ponownego
# uruchomienia offline. Pliki i tak są nadpisywane przy udanym przebiegu.
dir.create("dane", showWarnings = FALSE)

message("   Pobieranie danych z bazy danych...")
# uruchomienie pliku skrypty/pobieranie_danych.R
source("skrypty/pobieranie_danych.R")

# Dane pobrane i sprawdzone - dopiero teraz kasujemy wyniki poprzedniego przebiegu,
# żeby nie mieszały się z nowymi.
message("   Tworzenie folderu wyniki...")
if (dir.exists("wyniki")) unlink("wyniki", recursive = TRUE)
dir.create("wyniki")

message("   Przetwarzanie pobranych danych...")
# uruchomienie pliku skrypty/przetwarzanie_danych.R
source("skrypty/przetwarzanie_danych.R")

message("  Tworzenie wykresów...")
# uruchomienie pliku skrypty/tworzenie_wykresow.R
source("skrypty/tworzenie_wykresow.R")

message("  Zapisywanie tabel do arkusza...")
# uruchomienie pliku skrypty/zapis_tabel.R
source("skrypty/zapis_tabel.R")

message("  Zapisywanie obiektów...")
# Zapisujemy jawną listę obiektów, a nie całe środowisko. save(list = ls()) spakowałby
# tu ponad 200 obiektów, w tym zamknięty uchwyt połączenia z bazą (con), zmienne pętli
# oraz kilkadziesiąt obiektów roboczych z plików rycin (panelA, srodki_temp itp.).
# Ten plik jest interfejsem do raportu - quarto_render wczytuje go w osobnej sesji -
# więc trafia do niego tylko to, co ma wartość: dane, wyniki i parametry.
obiekty_do_zapisu = c(
  ls(pattern = "^a1_"),                # widoki z bazy i ramki z nich wyprowadzone
  ls(pattern = "^tab_"),               # dane tabel oraz ich legendy
  ls(pattern = "^naglowek_tab_"),      # układ nagłówka grupującego tabel 1 i 8
  ls(pattern = "^kolory_"),            # palety oraz macierze kolorów komórek
  # Gotowe ryciny i dane, z których powstały, ale BEZ paneli pośrednich (ryc_4A,
  # ryc_21B, ryc_25C...). Panel jest wyłącznie materiałem dla plot_grid(): złożona
  # rycina niesie jego kopię w środku, a qmd drukuje tylko gotowe ryc_N. Sam wzorzec
  # "^ryc_" zgarnąłby panele razem z rycinami i dołożył do pliku kilkanaście obiektów
  # zajmujących blisko 200 MB, których nikt nigdy nie otwiera - stąd setdiff() niżej.
  # Ryciny puste (NULL) muszą zostać: qmd sprawdza eval = !is.null(ryc_N) i bez
  # obiektu przerwałby pracę na "object not found".
  setdiff(ls(pattern = "^ryc_"), ls(pattern = "^ryc_[0-9]+[A-Z]+$")),
  ls(pattern = "^dane_"),              # dane pomocnicze rycin
  ls(pattern = "^dni_charakterystyczne"),
  # parametry raportu i stałe
  "stacja", "nazwa_stacji", "zrodlo_okresu_ref", "slownik_stacji",
  "analizowany_rok", "rok_poczatek", "rok_koniec",
  "lata_wielolecia", "lata_analizy", "miesiace_hydro", "miesiace_rzymskie",
  # Lata z danymi każdej ryciny wieloletniej (zakres jej osi) i funkcja zapisująca
  # je zwięźle - w sesji Quarto składają podpisy rycin 15-21 i 25-30, a sama
  # funkcja także podpisy tabel 5-7.
  ls(pattern = "^lata_ryc_"), "zakres_lat",
  "kierunki_wiatru", "nazwy_linii_doy",
  # Słownik opisów elementów meteorologicznych wraz z funkcją składającą z niego
  # listę do objaśnień. Sesja Quarto nie wczytuje funkcje/funkcje_pomocnicze.R,
  # a to z tego słownika powstają objaśnienia pod tabelami 1, 5 i 8 oraz pod
  # rycinami kompletności - bez niego raport przerwałby się na "object not found".
  "opisy_elementow", "jednostki_elementow", "opis_elementow_txt",
  # Wykaz wierszy nagłówkowych tabeli 10 - qmd po nim pogrubia i scala grupy.
  "tab_10_grupy",
  # wartości odniesienia i wyniki obliczeń
  "okres_referencyjny", "srednia_temp_okres_ref", "sredni_opad_okres_ref",
  "sd_temp_okres_ref", "srednia_temp_wielolecia", "srednia_opad_wielolecia",
  "tad_trend", "tad_trend_txt",
  "klasyfikacja_temp_opad", "wielolecie_miesieczne",
  # funkcje, których raport nie wczytuje z katalogu funkcje/
  "table_theme", "plot_theme",
  # UWAGA: rycina 20 podaje w aes() nazwy wektorów ze środowiska, a nie kolumn danych.
  # ggplot rozwiązuje takie odwołania dopiero przy rysowaniu, czyli już w sesji
  # quarto_render - bez tych dwóch obiektów raport przerywa się na "object not found".
  "kolor_punkt", "kolor_rok"
)

save(list = unique(obiekty_do_zapisu), file = "dane/dane_all.RData")

message("  Generowanie raportu...")
# uruchomienie pliku skrypty/tworzenie_raportu.qmd
quarto_render(input = "skrypty/tworzenie_raportu.qmd", output_file = "A1_raport.docx")

# Przeniesienie raportu do katalogu z wynikami.
# quarto_render zapisuje raport obok pliku .qmd, czyli w katalogu skrypty/,
# a wszystkie wyniki przebiegu mają leżeć razem w wyniki/. Nazwa dostaje kod stacji,
# żeby po samym pliku było widać, której stacji dotyczy.
# overwrite = TRUE jest konieczne: bez niego file.copy() napotkawszy raport tej samej
# stacji z poprzedniego przebiegu po cichu zwraca FALSE i zostawia STARĄ wersję -
# workflow kończyłby się sukcesem, a w wyniki/ leżałby nieaktualny raport. Wynik
# kopiowania sprawdzamy, żeby taka sytuacja nie przeszła niezauważona.
raport_stacji <- paste0("wyniki/A1_raport_", stacja, ".docx")

if (!file.copy("skrypty/A1_raport.docx", raport_stacji, overwrite = TRUE)) {
  warning("Nie udało się zapisać raportu do: ", raport_stacji, call. = FALSE)
}

unlink("skrypty/A1_raport.docx")

# Komunikat końcowy. Bez niego ostatnim, co widać w konsoli, jest wyjście
# quarto_render - a z niego nie wynika, czy przebieg się zakończył, czy jeszcze trwa.
message("\n>>> Gotowe. Wyniki dla stacji ", nazwa_stacji, " (", stacja, "), ",
        "rok hydrologiczny ", analizowany_rok, ":")
message("      raport:  ", raport_stacji)
message("      tabele:  wyniki/a1_tabele.xlsx")
message("      ryciny:  wyniki/png/ oraz wyniki/svg/ (",
        length(list.files("wyniki/png")), " rycin)")
