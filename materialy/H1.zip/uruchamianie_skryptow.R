################################################################################
# OPIS SKRYPTU
################################################################################
# uruchamianie_skryptow.R - skrypt sterujący całym raportem
#
# Punkt wejścia projektu - JEDYNY PLIK, KTÓRY SIĘ URUCHAMIA. Wczytuje pakiety,
# ustawia przecinek jako separator dziesiętny, przygotowuje katalogi robocze,
# a następnie wykonuje kolejne etapy: pobranie danych z bazy, ich przetworzenie,
# narysowanie rycin, zapis tabel do arkusza oraz złożenie raportu i aneksu w Quarto.
# Gotowe dokumenty Worda znajdziesz w katalogu wyniki/.
#
# Uwagi do kodu:
#
# JAK URUCHOMIĆ RAPORT
#   1. Otwórz H1.Rproj w RStudio (ustawia katalog roboczy projektu).
#   2. Wpisz kod swojej stacji i rok hydrologiczny w parametry/parametry.xlsx.
#   3. Utwórz plik .Renviron na wzór .Renviron.example i wpisz w nim dane dostępowe
#      do bazy ZMŚP. Po jego utworzeniu zrestartuj sesję R (Session -> Restart R) -
#      R czyta ten plik tylko przy starcie.
#   4. Otwórz ten plik i kliknij Source.
#   Przebieg trwa kilka minut. Postęp widać w konsoli, a każdy etap kończy się
#   komunikatem. Błąd przerywa pracę i mówi, co poprawić.
#
# PIERWSZE URUCHOMIENIE NA NOWYM KOMPUTERZE
#   Brakujące pakiety instalują się same, przed pierwszym użyciem. Potrzebne jest
#   też Quarto - skrypt sprawdza jego obecność na starcie, a nie dopiero przy
#   składaniu dokumentów.
#
# KATALOGI ROBOCZE
#   Katalog wyniki/ jest kasowany i tworzony od nowa przy każdym przebiegu, żeby
#   wyniki nie mieszały się z poprzednimi - ale dopiero PO udanym pobraniu danych.
#   Katalog dane/ nie jest kasowany nigdy: gdy baza okaże się niedostępna,
#   poprzednie pobranie zostaje na dysku.
#
# SEPARATOR DZIESIĘTNY
#   options(OutDec = ",") obowiązuje tylko w bieżącej sesji, dlatego to samo
#   ustawienie powtarza się w chunkach setup obu dokumentów Quarto - quarto_render
#   uruchamia osobną sesję R.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - parametry/parametry.xlsx: kod stacji bazowej oraz analizowany rok
# - .Renviron: dane dostępowe do bazy (ZMSP_DB_USER, ZMSP_DB_PASSWORD,
#     ZMSP_DB_HOST, ZMSP_DB_PORT, ZMSP_DB_NAME)
# - H1.Rproj: plik projektu RStudio (opcjonalny; otwarcie go ustawia katalog roboczy)
# - funkcje/styl_dokument.docx: szablon stylów Worda
# - skrypty etapów z katalogu skrypty/ oraz pliki rycin z katalogu wykresy/
################################################################################
# WYNIK
################################################################################
# - dane/dane.RData: widoki pobrane z bazy wraz z parametrami raportu
# - dane/dane_all.RData: obiekty, z których powstają raport i aneks - jawna lista,
#     nie całe środowisko
# - wyniki/png/ i wyniki/svg/: ryciny zapisane do plików
# - wyniki/h1_tabele.xlsx: tabele raportu i aneksu (do dziesięciu; tabela bez danych
#     nie dostaje arkusza) oraz arkusz objaśnień
# - wyniki/H1_raport_<stacja>_<rok>.docx oraz wyniki/H1_aneks_<stacja>_<rok>.docx
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - RPostgres, DBI
# - readxl
# - tidyverse
# - cowplot
# - svglite
# - flextable
# - openxlsx
# - quarto
################################################################################

## katalog roboczy ##
# Ustawiamy katalog roboczy na katalog TEGO pliku, żeby ścieżki względne (parametry/,
# funkcje/, skrypty/, dane/, wyniki/) działały niezależnie od tego, skąd skrypt został
# uruchomiony.
#
# Ścieżkę ustalamy na cztery sposoby, po kolei - pierwszy, który zadziała, wygrywa:
# argument --file= (Rscript), ramka wywołania (przycisk Source), zapytanie do RStudio
# (uruchamianie zaznaczonego kodu przez Ctrl+Enter) oraz srcref. Przy Ctrl+Enter plik
# musi być zapisany na dysku.
katalog_skryptu <- function() {
  argumenty <- commandArgs(trailingOnly = FALSE)
  arg_pliku <- grep("^--file=", argumenty, value = TRUE)
  if (length(arg_pliku) > 0) {
    return(dirname(normalizePath(sub("^--file=", "", arg_pliku[1]))))
  }

  for (ramka in rev(sys.frames())) {
    if (!is.null(ramka$ofile)) return(dirname(normalizePath(ramka$ofile)))
  }

  if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
    sciezka <- tryCatch(rstudioapi::getSourceEditorContext()$path,
                        error = function(e) "")
    if (length(sciezka) == 1 && nzchar(sciezka)) {
      return(dirname(normalizePath(sciezka)))
    }
  }

  katalog <- utils::getSrcDirectory(function() NULL)
  if (length(katalog) > 0 && nzchar(katalog)) return(normalizePath(katalog))

  warning("Nie udało się ustalić katalogu skryptu - zostaje bieżący katalog roboczy: ",
          getwd(), ".\n  Jeśli przebieg przerwie się na braku pliku parametrów, otwórz ",
          "projekt przez plik H1.Rproj.", call. = FALSE)
  getwd()
}

setwd(katalog_skryptu())
message("   Katalog roboczy: ", getwd())

## pakiety ##
# Brakujące pakiety instalują się automatycznie, przed wczytaniem.
# tidyverse wciąga ggplot2, dplyr, tidyr i forcats.
pakiety = c("RPostgres", "DBI", "readxl", "tidyverse", "cowplot", "svglite",
            "flextable", "openxlsx", "quarto")

brakujace = setdiff(pakiety, rownames(installed.packages()))
if (length(brakujace) > 0) {
  message("   Instalowanie brakujących pakietów: ", paste(brakujace, collapse = ", "))
  install.packages(brakujace)
}

# Komunikaty startowe pakietów są wyciszone, żeby w konsoli został sam postęp
# przebiegu. Błędy nadal przerywają pracę.
invisible(lapply(pakiety, function(p)
  suppressWarnings(suppressMessages(library(p, character.only = TRUE)))))

## Quarto ##
# Dokumenty składa Quarto, dopiero w ostatnim kroku przebiegu - ale jego obecność
# sprawdzamy już na starcie, żeby brak nie ujawnił się po kilku minutach obliczeń.
#
# Pakiet R o nazwie quarto jest tylko łącznikiem do programu Quarto i szuka go WYŁĄCZNIE
# w zmiennej środowiskowej QUARTO_PATH oraz na ścieżce systemowej (PATH). RStudio wnosi
# własną kopię Quarto, ale wskazuje ją zmienną RSTUDIO_QUARTO, o której pakiet quarto
# nie wie - i na części instalacji ta kopia nie trafia na PATH. Poniżej podstawiamy więc
# wskazanie RStudio pod QUARTO_PATH.
if (is.null(quarto_path()) && nzchar(Sys.getenv("RSTUDIO_QUARTO"))) {
  wskazanie <- Sys.getenv("RSTUDIO_QUARTO")
  plik_quarto <- if (.Platform$OS.type == "windows") "quarto.exe" else "quarto"
  kandydaci <- c(wskazanie,
                 file.path(wskazanie, plik_quarto),
                 file.path(wskazanie, "bin", plik_quarto))
  kandydaci <- kandydaci[file.exists(kandydaci) & !dir.exists(kandydaci)]
  if (length(kandydaci) > 0) Sys.setenv(QUARTO_PATH = kandydaci[1])
}

if (is.null(quarto_path())) {
  stop("Nie znaleziono programu Quarto - bez niego dokumenty nie powstaną.\n",
       "  Nowsze wersje RStudio mają Quarto wbudowane; jeśli go brakuje, pobierz je",
       " ze strony https://quarto.org, zainstaluj, uruchom RStudio ponownie",
       " i kliknij Source jeszcze raz.",
       call. = FALSE)
}
message("   Quarto: ", quarto_path())

## separator dziesiętny ##
# Przecinek niezależnie od ustawień regionalnych maszyny. OutDec steruje wyjściem
# format()/as.character(), a przez to również etykietami osi ggplot2.
# UWAGA: quarto_render uruchamia osobną sesję R, więc ta sama opcja jest ustawiana
# także w chunkach setup obu dokumentów.
options(OutDec = ",")

# wczytanie funkcji pomocniczych, motywów i słownika stanowisk
source("funkcje/funkcje_pomocnicze.R")
source("funkcje/plot_theme.R")
source("funkcje/table_theme.R")
source("funkcje/slownik_stanowisk.R")

# Katalog na dane. NIE kasujemy go na starcie: gdyby baza okazała się niedostępna,
# zostalibyśmy bez danych z poprzedniego pobrania i bez możliwości pracy offline.
dir.create("dane", showWarnings = FALSE)

message("   Pobieranie danych z bazy danych...")
# uruchomienie pliku skrypty/pobieranie_danych.R
source("skrypty/pobieranie_danych.R")

# Dane pobrane i sprawdzone - dopiero teraz kasujemy wyniki poprzedniego przebiegu,
# żeby nie mieszały się z nowymi.
message("   Tworzenie folderu wyniki...")
if (dir.exists("wyniki")) unlink("wyniki", recursive = TRUE)
dir.create("wyniki")

message("   Przetwarzanie pobranych danych...")
source("skrypty/przetwarzanie_danych.R")

message("   Tworzenie rycin...")
source("skrypty/tworzenie_wykresow.R")

message("   Zapisywanie tabel do arkusza...")
source("skrypty/zapis_tabel.R")

message("   Zapisywanie obiektów...")
# dane/dane_all.RData jest interfejsem do dokumentów Quarto, które wczytują go
# w osobnej sesji R. Trafia do niego jawna lista obiektów: dane, ryciny i parametry.
# Funkcji nie zapisujemy - oba dokumenty wczytują pliki z katalogu funkcje/ same.
obiekty_do_zapisu = c(
  ls(pattern = "^dane_"),   # dane rycin i tabel
  ls(pattern = "^tab_"),    # dane tabel raportu i aneksu
  ls(pattern = "^ryc_"),    # gotowe ryciny (NULL, gdy brak danych - qmd to sprawdza)
  # parametry przebiegu i wielkości z nich wyprowadzone
  "stacja", "nazwa_stacji", "stanowiska", "stanowisko_ujscie", "kody_stanowisk",
  "ma_dwa_stanowiska", "etykiety_stanowisk", "analizowany_rok",
  "wielolecie_Q", "wielolecie_Q_lat", "wielolecie_opad", "lata_analizy",
  "opis_wielolecia_Q", "opis_wielolecia_opad",
  "opis_lat_roczne", "opis_lat_kategorie",
  ls(pattern = "^lata_ryc_"),   # lata z danymi rycin wieloletnich: osie i podpisy
  # stałe podpisów: miejsce (ciek i profil) oraz rozwinięcia skrótów składane
  # z tego, co na rycinie faktycznie stoi
  "opis_miejsca", "opis_miejsc", "opis_stacji",
  "kategorie_linii", "opis_linii_progowych", "opis_kategorii",
  "ma_wielolecie", "ma_progi",
  "brak_kategorii_w_roku"
)

save(list = unique(obiekty_do_zapisu), file = "dane/dane_all.RData")

# Nazwy plików wynikowych: kod stacji i rok hydrologiczny, żeby po samym pliku było
# widać, czego dotyczy.
raport_docx <- paste0("wyniki/H1_raport_", stacja, "_", analizowany_rok, ".docx")
aneks_docx  <- paste0("wyniki/H1_aneks_",  stacja, "_", analizowany_rok, ".docx")

message("   Generowanie raportu...")
quarto_render(input = "skrypty/tworzenie_raportu.qmd", output_file = "H1_raport.docx")

message("   Generowanie aneksu...")
quarto_render(input = "skrypty/tworzenie_aneksu.qmd", output_file = "H1_aneks.docx")

# Przeniesienie dokumentów do katalogu z wynikami. quarto_render zapisuje je obok
# pliku .qmd, czyli w katalogu skrypty/, a wszystkie wyniki przebiegu mają leżeć razem.
# overwrite = TRUE jest konieczne: bez niego file.copy() napotkawszy dokument tej samej
# stacji z poprzedniego przebiegu po cichu zwraca FALSE i zostawia STARĄ wersję.
przenies_dokument <- function(zrodlo, cel) {
  if (!file.copy(zrodlo, cel, overwrite = TRUE)) {
    warning("Nie udało się zapisać dokumentu do: ", cel, call. = FALSE)
  }
  unlink(zrodlo)
}

przenies_dokument("skrypty/H1_raport.docx", raport_docx)
przenies_dokument("skrypty/H1_aneks.docx", aneks_docx)

# Komunikat końcowy. Bez niego ostatnim, co widać w konsoli, jest wyjście
# quarto_render - a z niego nie wynika, czy przebieg się zakończył, czy jeszcze trwa.
message("\n>>> Gotowe. Wyniki dla stacji ", nazwa_stacji, " (", stacja, "), ",
        "rok hydrologiczny ", analizowany_rok, ":")
message("      raport:  ", raport_docx)
message("      aneks:   ", aneks_docx)
message("      tabele:  wyniki/h1_tabele.xlsx")
message("      ryciny:  wyniki/png/ oraz wyniki/svg/ (",
        length(list.files("wyniki/png")), " rycin)")
