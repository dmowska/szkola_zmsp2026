################################################################################
# OPIS SKRYPTU
################################################################################
# tworzenie_wykresow.R - wygenerowanie i zapis rycin
#
# Uruchamia po kolei wszystkie skrypty z katalogu wykresy/, a powstałe obiekty
# rycin zapisuje do plików PNG i SVG w katalogu wyniki/. Uruchamiany przez
# uruchamianie_skryptow.R, po przetwarzanie_danych.R.
#
# Uwagi do kodu:
#
# KOLEJNOŚĆ WYKONANIA
#   Pliki wykonują się w kolejności alfabetycznej nazw, więc ryc_10 przed ryc_2.
#   Żaden skrypt ryciny nie korzysta z obiektu tworzonego przez inny - każdy bierze
#   dane wyłącznie z obiektów dane_* przygotowanych przez przetwarzanie_danych.R.
#
# ROZMIARY RYCIN
#   Domyślny rozmiar zapisu to 8 x 5 cala, a odstępstwa zbiera lista wymiary.
#   Wysokość rycin 1, 2, 3 i 11 zależy od liczby stanowisk: każde dostaje własny
#   panel, więc na stacji z dwoma stanowiskami rycina jest o jeden panel wyższa.
#
# RYCINA, KTÓRA NIE POWSTAŁA
#   Rycina bez danych ma wartość NULL i nie jest zapisywana do pliku. Dokument
#   pomija wtedy jej blok, więc w raporcie po prostu jej nie ma.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - wykresy/ryc_1.R ... ryc_11.R: skrypty rycin, po jednym na rycinę
# - obiekty danych utworzone przez przetwarzanie_danych.R
# - funkcje/plot_theme.R: wspólny motyw rycin
################################################################################
# WYNIK
################################################################################
# - ryc_1 ... ryc_11: obiekty rycin w środowisku, używane potem przez
#     tworzenie_raportu.qmd
# - wyniki/png/ryc_*.png oraz wyniki/svg/ryc_*.svg: ryciny zapisane do plików
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
# - cowplot
# - svglite
################################################################################

source("funkcje/plot_theme.R")

# Tylko pliki .R - notatki i kopie zapasowe leżące w katalogu są pomijane.
pliki_wykresy = list.files("wykresy", pattern = "\\.R$")

for (plik in pliki_wykresy) {
  source(file.path("wykresy", plik))
}

# Ryciny wymagające innego rozmiaru niż domyślne 8 x 5 cala (szerokość, wysokość).
# Ryciny 1, 2, 3 i 11 mają po jednym panelu na stanowisko, więc rosną wraz z ich liczbą.
wymiary <- list(
  ryc_1  = c(8, if (ma_dwa_stanowiska) 7 else 5),
  ryc_2  = c(8, if (ma_dwa_stanowiska) 9 else 7),
  ryc_3  = c(8, if (ma_dwa_stanowiska) 9 else 5.5),
  ryc_5  = c(8, 8),
  ryc_6  = c(8, 9),
  ryc_11 = c(8, if (ma_dwa_stanowiska) 8 else 6)
)

# Zapis w obu formatach jedną pętlą. Nazwa obiektu bierze się z nazwy pliku:
# ryc_5.R -> obiekt ryc_5 -> wyniki/png/ryc_5.png i wyniki/svg/ryc_5.svg.
for (format in c("png", "svg")) {
  katalog = file.path("wyniki", format)
  if (!dir.exists(katalog)) dir.create(katalog, showWarnings = FALSE, recursive = TRUE)

  for (plik in pliki_wykresy) {
    nazwa_obiektu = sub("\\.R$", "", plik)
    # Rycina bez danych jest NULL (skrypty ryc_*.R) - nie ma czego zapisywać,
    # a ggsave przerwałby pracę na "plot should be a ggplot object".
    if (is.null(get(nazwa_obiektu))) next
    wym = if (!is.null(wymiary[[nazwa_obiektu]])) wymiary[[nazwa_obiektu]] else c(8, 5)
    ggsave(file.path(katalog, paste0(nazwa_obiektu, ".", format)),
           get(nazwa_obiektu), width = wym[1], height = wym[2], dpi = 300)
  }
}

message(">>> [tworzenie_wykresow.R] Zakończono sukcesem.")
