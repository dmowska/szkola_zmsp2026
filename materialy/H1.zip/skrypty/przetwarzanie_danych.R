################################################################################
# OPIS SKRYPTU
################################################################################
# przetwarzanie_danych.R - przygotowanie danych do tabel i rycin
#
# Zamienia surowe widoki pobrane z bazy ZMŚP na gotowe zestawy danych raportu.
# Uruchamiany przez uruchamianie_skryptow.R, zaraz po pobieranie_danych.R.
#
# Uwagi do kodu:
#
# UKŁAD PLIKU
#   SEKCJA 1 - typy i porządki: kolejność stanowisk i ich etykiety,
#   SEKCJA 2 - obiekty dane_* wprost z widoków, zawężone do zakresu raportu,
#   SEKCJA 3 - obiekty dane_* wymagające obliczeń: progi, kategorie, kompletność,
#   SEKCJA 4 - obiekty tab_*_dane, w kolejności numerów tabel,
#   SEKCJA 5 - stałe do podpisów tabel i rycin.
#
# CO LICZY TEN SKRYPT, A CZEGO NIE
#   Charakterystyki przepływu, opad, odpływ, współczynniki i liczbę dni w kategoriach
#   liczy baza - tutaj są tylko odczytywane. Skrypt wylicza wyłącznie to, czego
#   w widokach nie ma: udziały kategorii, wiersze podsumowań w tabelach 2 i 3,
#   rozstęp międzykwartylowy oraz klasy kompletności.
#
# ROK HYDROLOGICZNY
#   Raport opisuje lata hydrologiczne (XI-X): 2024-11-01 należy już do roku 2025.
#   Parametr analizowany_rok jest rokiem HYDROLOGICZNYM, więc wszystkie filtry idą
#   po rok_hydro. Widoki zagregowane mają tę kolumnę gotową, dla danych dobowych
#   wylicza ją rok_hydrologiczny() z funkcje/funkcje_pomocnicze.R.
#
# TYPY OKRESU (kolumna okres_typ w widokach zagregowanych)
#   M  - miesiąc,
#   RH - podsumowanie roku hydrologicznego.
#   W wierszach RH kolumna miesiac jest pusta.
#
# MIESIĄC - PUŁAPKA
#   Miesiąc jest faktorem o poziomach roku hydrologicznego (XI, XII, I-X), więc
#   KOD POZIOMU NIE JEST NUMEREM MIESIĄCA: as.integer() zwróciłby 1 dla listopada.
#   Numer kalendarzowy daje nr_miesiaca(), zapis rzymski - miesiac_rzymski()
#   (obie funkcje w funkcje/funkcje_pomocnicze.R).
#
# STANOWISKO ODNIESIENIA A WSZYSTKIE STANOWISKA
#   Raport obejmuje jedno albo dwa stanowiska wodowskazowe. Obiekty dane_* dotyczą
#   stanowiska odniesienia, bo tylko ono wchodzi do większości rycin i do całego
#   aneksu. Wyjątki - dane_dobowe_rok, dane_dobowe_wiel, dane_doy, dane_linie_progowe
#   i dane_kompletnosc - obejmują wszystkie stanowiska, bo ryciny 1, 2, 3 i 11
#   pokazują każde z nich. Tabela 1 również obejmuje wszystkie stanowiska.
#
#   "Wszystkie" znaczy: wszystkie RAPORTOWANE. Stanowisko, które słownik wyłączył
#   z raportu (Wigry: ujściowe 009), odpada na wejściu sekcji 2 i nie wchodzi do
#   niczego - ani do rycin, ani do tabel, ani do zakresów lat.
#
# STACJA BEZ DANYCH WIELOLETNICH
#   Dla części stacji baza nie ma policzonych agregatów wieloletnich. Raport powstaje
#   wtedy bez części porównawczej, a sterują tym znaczniki ma_wielolecie i ma_progi:
#   puste obiekty przechodzą dalej, a ryciny i tabele, które nie mają czego pokazać,
#   same zamieniają się na NULL.
#
# NAZWY KOLUMN
#   Obiekty dane_* zachowują nazwy kolumn z bazy, także te ze spacjami ("q min",
#   "Q_E p95") - w kodzie w odwrotnych apostrofach. Obiekty tab_*_dane są materiałem
#   dla tabel, więc mają nazwy własne, krótkie i bez spacji.
#
# SEPARATOR DZIESIĘTNY
#   options(OutDec = ",") ustawia uruchamianie_skryptow.R oraz chunk setup w qmd,
#   więc nigdzie nie podmieniamy kropek na przecinki ręcznie.
################################################################################
# DANE WEJŚCIOWE
################################################################################
#   Plik dane/dane.RData zapisany przez pobieranie_danych.R. Zawiera osiem widoków
#   h1_*_vw, każdy zawężony do jednej stacji, oraz parametry raportu. Skrypt wczytuje
#   go sam, więc można go uruchomić bez ponownego pobierania danych z bazy.
#   Zakres lat w widokach bywa szerszy niż potrzebny w raporcie - zawęża go sekcja 2.
#
#   Dane dobowe - jeden wiersz na dzień i stanowisko:
#     h1_dane_dobowe_vw
#         Rok analizowany: przepływ Q_E, odpływ jednostkowy q i opad RR_T wraz
#         z flagami jakości. Widok ma rok wpisany na sztywno w definicji, więc
#         niesie WYŁĄCZNIE rok analizowany - za to jako jedyny z opadem.
#     h1_dane_dobowe_wiel_q_e_vw
#         Te same przepływy Q_E i q, ale dla wszystkich lat wielolecia. Bez opadu.
#
#   Dane zagregowane - jeden wiersz na okres (miesiąc albo rok hydrologiczny):
#     h1_dane_agg_vw
#         Charakterystyki I stopnia kolejnych lat i miesięcy: NQ, SQ, WQ, amplituda,
#         odchylenie, współczynnik zmienności i percentyle przepływu oraz odpływu
#         jednostkowego, opad RR_T, warstwa odpływu O, współczynniki a i kj,
#         jednostki i kompletność serii. Kolumna okres_typ rozdziela wiersze
#         miesięczne (M) od rocznych (RH).
#     h1_dane_wieloletnie_vw
#         Jeden wiersz na stanowisko: charakterystyki II stopnia całego wielolecia
#         (NNQ, NSQ, NWQ, SNQ, SSQ, SWQ, WNQ, WSQ, WWQ), percentyle, opad i odpływ
#         średnie oraz zakres wielolecia i liczba lat, na których stoi.
#     h1_dane_wieloletnie_dobowe_vw
#         Przebieg roku uśredniony po latach: dla każdego z 365 dni NQ, SQ, WQ
#         i percentyle 05/25/50/75/95. Kluczem jest dzien_roku, bo widok nie odnosi
#         się do konkretnego roku.
#     h1_wsp_msc_wiel_przeplywu_vw
#         Dwanaście wierszy - wieloletnie średnie miesięczne: SSQ, opad, warstwa
#         odpływu oraz współczynniki kj i a.
#
#   Kategorie przepływu:
#     h1_wartosci_graniczne_vw
#         Jeden wiersz na stanowisko: progi liczbowe pięciu granic kategorii.
#     h1_kategorie_przeplywu_vw
#         Liczba dni w każdej z sześciu kategorii, w układzie rok x miesiąc,
#         wraz z liczbą dni z wynikiem.
#
#   Parametry raportu: stacja, nazwa_stacji, stanowiska, stanowisko_ujscie,
#   wymien_profil, analizowany_rok, wielolecie_Q, wielolecie_Q_lat, wielolecie_opad,
#   lata_analizy.
################################################################################
# WYNIK
################################################################################
#   Dane rycin - rysują je potem pliki wykresy/ryc_*.R:
#     dane_dobowe_wiel                  - rycina 1
#     dane_dobowe_rok                   - ryciny 2 i 3
#     dane_doy                          - rycina 3
#     dane_linie_progowe                - ryciny 1 i 2
#     dane_miesieczne                   - ryciny 4 i 9
#     dane_kategorie_rok                - rycina 5
#     dane_kategorie_miesiac_rok        - rycina 5
#     dane_kategorie_miesiac_wielolecie - rycina 5
#     dane_kategorie_rok_miesiac        - rycina 6
#     dane_roczne                       - rycina 7
#     dane_miesieczne_rok               - ryciny 8 i 10
#     dane_wsp_miesieczny               - ryciny 8 i 10
#     dane_kompletnosc                  - rycina 11
#
#   Dane tabel - formatuje je potem funkcje/tabele.R:
#     tab_1_dane  - tabela 1, charakterystyki roku i wielolecia, wszystkie stanowiska
#     tab_2_dane  - tabela 2, miesięczne parametry roku analizowanego
#     tab_3_dane  - tabela 3, parametry roczne w kolejnych latach
#     tab_4_dane  - tabela 4, progi kategorii i liczba dni w roku analizowanym
#
#   Dane tabel aneksu - cyfra w nazwie jest numerem tabeli w aneksie:
#     tab_a1_dane - aneks, tabela 1: statystyki przepływu w kolejnych latach
#     tab_a2_dane - aneks, tabela 2: statystyki odpływu jednostkowego w kolejnych latach
#     tab_a3_dane - aneks, tabela 3: miesięczne charakterystyki roku analizowanego
#     tab_a4_dane - aneks, tabela 4: udziały kategorii w kolejnych latach
#     tab_a5_dane - aneks, tabela 5: udziały kategorii w miesiącach wielolecia
#     tab_a6_dane - aneks, tabela 6: udziały kategorii w miesiącach roku analizowanego
#
#   Obiekty pomocnicze:
#     dane_dobowe    - dobowa seria roku analizowanego wraz z opadem; podstawa
#                      dla dane_dobowe_rok, do rycin nie wchodzi wprost
#     dane_wieloletnie, dane_progi - materiał tabel; czyta je też tworzenie_raportu.qmd
#                      oraz zapis_tabel.R
#
#   Stałe do podpisów:
#     opis_miejsca, opis_miejsc, opis_stacji  - fraza "rzeki X w profilu
#                      wodowskazowym Y w Stacji Bazowej ZMŚP Z"
#     opis_wielolecia_Q, opis_wielolecia_opad
#     lata_ryc_1, lata_ryc_4, lata_ryc_5, lata_ryc_6, lata_ryc_7, lata_ryc_9,
#     lata_ryc_11 - lata z danymi każdej ryciny wieloletniej: zakres jej osi i podpis
#     opis_lat_roczne, opis_lat_kategorie - lata faktycznie obecne w tabelach
#     etykiety_stanowisk, kody_stanowisk, ma_dwa_stanowiska
#     kategorie_linii, opis_linii_progowych, opis_kategorii - skróty i ich
#                      rozwinięcia, wyliczane z linii i kategorii faktycznie
#                      narysowanych na rycinach
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - tidyverse (dplyr, tidyr, tibble, forcats)
################################################################################

if (!file.exists("dane/dane.RData")) {
  stop("Brak pliku dane/dane.RData. Uruchom najpierw pobieranie danych.", call. = FALSE)
}

source("funkcje/funkcje_pomocnicze.R")
load("dane/dane.RData")

# Kolumny bigint z bazy przychodzą jako integer64 i bez wczytanego bit64 liczą się
# na surowych bajtach - po cichu, bez ostrzeżenia. Pobieranie sprowadza je do numeric,
# ale ten skrypt uruchamia się także sam, na gotowym pliku dane/dane.RData, który mógł
# powstać wcześniej. Zamiana jest niekosztowna i nic nie zmienia w widoku, który tego
# typu nie ma.
#
# Widoki rozpoznajemy po nazwie, a nie po wykazie: wykaz pobieranych widoków stoi
# wyłącznie w skrypty/pobieranie_danych.R, a tutaj i tak obowiązuje to, co faktycznie
# wczytało się z pliku - także ze starszego, zapisanego przed zmianą listy widoków.
for (widok in ls(pattern = "^h1_")) assign(widok, bez_integer64(get(widok)))
if (exists("widok")) rm(widok)

################################################################################
# 1. TYPY I PORZĄDKI
################################################################################

# Kolejność stanowisk w raporcie: odniesienie pierwsze, dalej według słownika.
# Wykaz obejmuje wyłącznie stanowiska RAPORTOWANE - stanowisko z raport = FALSE
# w słowniku odpadło już w stacja_ze_slownika(). Stanowisko jest faktorem o tych
# poziomach, więc panele rycin i wiersze tabel układają się same, bez sortowania
# w każdym miejscu z osobna.
kody_stanowisk <- stanowiska$stanowisko
ma_dwa_stanowiska <- length(kody_stanowisk) > 1

# Plik dane/dane.RData zapisany przed wprowadzeniem kolumny raport nie ma parametru
# wymien_profil. Skrypt wolno uruchomić samodzielnie na takim starszym pobraniu,
# więc brak parametru cofa nas do dawnej reguły: profil wymieniamy, gdy raport
# obejmuje dwa stanowiska. Świeże pobranie przynosi wartość ze słownika i ta linia
# nic wtedy nie robi.
if (!exists("wymien_profil")) wymien_profil <- ma_dwa_stanowiska

jako_stanowisko <- function(x) factor(as.character(x), levels = kody_stanowisk)

# Etykieta stanowiska do podpisów i pasków paneli. Dopisek o ujściu ma sens tylko
# wtedy, gdy jest z czym je zestawić - przy jednym stanowisku byłby szumem (a na
# Wigrach również nieprawdą: raportowane 008 nie leży przy ujściu).
etykiety_stanowisk <- setNames(paste("stanowisko", kody_stanowisk), kody_stanowisk)
if (ma_dwa_stanowiska) {
  etykiety_stanowisk[stanowisko_ujscie] <-
    paste0(etykiety_stanowisk[stanowisko_ujscie], " (ujście)")
}

################################################################################
# 2. FILTRY I ZAWĘŻENIE DO STANOWISK
################################################################################

# Stanowiska spoza raportu. Widoki przychodzą z bazy z KOMPLETEM stanowisk stacji,
# także tymi, których słownik nie raportuje (Wigry: ujściowe 009, raport = FALSE).
# Odsiewamy je tutaj, raz, na wszystkich widokach naraz - zanim powstanie którykolwiek
# obiekt dane_*. Dzięki temu o zakresie raportu rozstrzyga jedno miejsce,
# funkcje/slownik_stanowisk.R, a dalszy kod może zakładać, że każdy wiersz należy
# do stanowiska raportowanego.
#
# Odsiew jest KONIECZNY, a nie porządkowy. Obiekty budowane wprost z widoku
# (dane_dobowe_wiel, dane_kompletnosc, dane_linie_progowe, dane_doy) nie filtrują po
# stanowisku - robi to dopiero rycina, dzieląc dane na panele. Rycina stacji
# jednostanowiskowej paneli nie ma, więc wiersze pominiętego stanowiska wpadłyby do
# wspólnej puli: pudełka ryciny 1 powstałyby z dwóch profili naraz, a mapa
# kompletności ryciny 11 kładłaby dwa kafelki na jednym miejscu.
# Kody z bazy bywają dopełnione spacjami (h1_dane_dobowe_wiel_q_e_vw), stąd trimws().
zawez_do_stanowisk <- function(dane)
  dane[trimws(as.character(dane$stanowisko)) %in% kody_stanowisk, , drop = FALSE]

for (widok in ls(pattern = "^h1_")) assign(widok, zawez_do_stanowisk(get(widok)))
if (exists("widok")) rm(widok)
rm(zawez_do_stanowisk)

# Dane dobowe. Miesiąc bierzemy z daty pomiaru, a nie z kolumny miesiac: data jest
# jednoznaczna, a kolumna podaje zapis rzymski, który i tak trzeba by przeliczyć.
dane_dobowe <- h1_dane_dobowe_vw |>
  mutate(data_pomiar = as.Date(data_pomiar),
         rok_hydro   = rok_hydrologiczny(data_pomiar),
         miesiac     = jako_miesiac(format(data_pomiar, "%m")),
         stanowisko  = jako_stanowisko(stanowisko),
         dzien_roku  = as.integer(dzien_roku)) |>
  filter(rok_hydro <= analizowany_rok) |>
  arrange(stanowisko, data_pomiar)

dane_dobowe_rok <- filter(dane_dobowe, rok_hydro == analizowany_rok)

# Dobowy przepływ całego wielolecia - osobny obiekt, bo w bazie stoi w osobnym widoku.
# h1_dane_dobowe_vw ma rok hydrologiczny wpisany na sztywno w definicji widoku, więc
# niesie wyłącznie rok analizowany, za to razem z opadem; h1_dane_dobowe_wiel_q_e_vw
# niesie wszystkie lata, ale bez opadu. Stąd dwa obiekty zamiast jednego: rycina 1
# rysuje pudełka dla kolejnych lat i bierze ten obiekt, a ryciny 2 i 3 potrzebują
# opadu i zostają przy dane_dobowe_rok.
#
# Rok hydrologiczny bierzemy z kolumny widoku, a nie z daty - widok podaje go wprost,
# tak samo jak widoki zagregowane. Filtr odcina rok bieżący, jeszcze niedomknięty.
dane_dobowe_wiel <- h1_dane_dobowe_wiel_q_e_vw |>
  mutate(data_pomiar = as.Date(data_pomiar),
         rok_hydro   = as.integer(rok_hydro),
         stanowisko  = jako_stanowisko(trimws(stanowisko))) |>
  filter(rok_hydro <= analizowany_rok) |>
  arrange(stanowisko, data_pomiar)

# Dane zagregowane - wspólna podstawa dla wierszy rocznych i miesięcznych. Rok bieżący,
# jeszcze niedomknięty, ma w widoku same wiersze miesięczne i żadnego rocznego; filtr
# po roku analizowanym usuwa go razem z latami późniejszymi.
dane_agg <- h1_dane_agg_vw |>
  mutate(rok_hydro  = as.integer(rok_hydro),
         stanowisko = jako_stanowisko(stanowisko)) |>
  filter(rok_hydro <= analizowany_rok)

dane_roczne <- dane_agg |>
  filter(okres_typ == "RH", stanowisko == stanowisko_ujscie) |>
  arrange(rok_hydro)

dane_miesieczne <- dane_agg |>
  filter(okres_typ == "M", stanowisko == stanowisko_ujscie) |>
  mutate(miesiac = jako_miesiac(miesiac)) |>
  arrange(rok_hydro, miesiac)

dane_miesieczne_rok <- filter(dane_miesieczne, rok_hydro == analizowany_rok)

# Charakterystyki 2. stopnia oraz wieloletnie statystyki dobowe.
dane_wieloletnie <- h1_dane_wieloletnie_vw |>
  filter(stanowisko == stanowisko_ujscie)

dane_doy <- h1_dane_wieloletnie_dobowe_vw |>
  mutate(stanowisko = jako_stanowisko(stanowisko),
         dzien_roku = as.integer(dzien_roku)) |>
  arrange(stanowisko, dzien_roku)

# Wieloletnie współczynniki miesięczne: kj (przepływ) oraz a (odpływ).
dane_wsp_miesieczny <- h1_wsp_msc_wiel_przeplywu_vw |>
  filter(stanowisko == stanowisko_ujscie) |>
  mutate(miesiac = jako_miesiac(miesiac)) |>
  arrange(miesiac)

################################################################################
# 3. OBIEKTY DANYCH
################################################################################

## 3.1 Wartości graniczne kategorii -------------------------------------------

progi_ujscie <- h1_wartosci_graniczne_vw |>
  filter(stanowisko == stanowisko_ujscie)

# Część stacji nie ma jeszcze w bazie agregatów wieloletnich (08ZM, 15ZM: "BRAK
# wielolecia, wartości granicznych, wsp. miesięcznych i wieloletnich dobowych").
# Raport dla nich powstaje, tylko bez elementów, które z tych agregatów wynikają -
# pusta tabela progów albo rycina bez ani jednej linii byłaby myląca, a nie uboższa.
# Poniższe flagi rozstrzygają, co się składa, a co pomijamy.
ma_wielolecie <- nrow(dane_wieloletnie) > 0
ma_progi <- nrow(progi_ujscie) > 0

prog <- function(kolumna) {
  if (!ma_progi || !kolumna %in% names(progi_ujscie)) return(NA_real_)
  as.numeric(progi_ujscie[[kolumna]][1])
}

prog_wielkie  <- prog("wezbranie wielkie")   # SWQ
prog_zwykle   <- prog("wezbranie zwykle")    # NWQ
prog_male     <- prog("wezbranie male")      # 1/2 (NWQ + WSQ)
prog_plytka   <- prog("nizowka plytka")      # 1/2 (NSQ + WNQ)
prog_gleboka  <- prog("nizowka gleboka")     # SNQ

# Górna granica przepływów normalnych to niższa z dwóch granic wezbraniowych.
# Zwykle jest nią granica wezbrania zwykłego (NWQ), bo połowa sumy NWQ i WSQ leży
# wyżej - wtedy przedział wezbrania małego jest pusty. Odwrotnie dzieje się tylko
# na stacjach, gdzie WSQ jest niższe od NWQ.
gorna_normalnego <- min(prog_zwykle, prog_male, na.rm = TRUE)

# Kategoria wezbrania małego bywa pusta z definicji, a nie z braku danych - pusta
# kolumna w tabeli wyglądałaby na usterkę, więc odnotowujemy to jawnie i tabela 4
# dopisze przypis.
wezbranie_male_puste <- !is.na(prog_male) && !is.na(prog_zwykle) &&
                        prog_male >= prog_zwykle

dane_progi <- if (!ma_progi) tibble(
  kategoria = factor(character(0), levels = names(kolory_kategorii)),
  warunek = character(0), pusta = logical(0)) else tibble(
  kategoria = factor(names(kolory_kategorii), levels = names(kolory_kategorii)),
  # Symbol Q, a nie Q_E: nagłówek kolumny nazywa wielkość wprost ("Przepływ
  # [m³·s⁻¹]"), więc oznaczenie z bazy nie musi tu wchodzić i nie wymaga objaśnienia.
  warunek = c(
    paste0("Q ≥ ", liczba_txt(prog_wielkie)),
    paste0(liczba_txt(prog_zwykle), " ≤ Q < ", liczba_txt(prog_wielkie)),
    paste0(liczba_txt(prog_male), " ≤ Q < ", liczba_txt(prog_zwykle)),
    paste0(liczba_txt(prog_plytka), " < Q < ", liczba_txt(gorna_normalnego)),
    paste0(liczba_txt(prog_gleboka), " < Q ≤ ", liczba_txt(prog_plytka)),
    paste0("Q ≤ ", liczba_txt(prog_gleboka))),
  pusta = c(FALSE, FALSE, wezbranie_male_puste, FALSE, FALSE, FALSE))

# Linie progowe na rycinach 1 i 2 - dla każdego stanowiska osobno, bo ryciny 2 i 3
# pokazują oba. Rysujemy KOMPLET granic wezbrań i niżówek, łącznie z granicą wezbrania
# małego; odsiew robi dopiero linia_widoczna(), i tylko tam, gdzie linia przecinałaby
# sąsiednią - wtedy strefa jest pusta z definicji i linia wprowadzałaby w błąd.
# Odsiew liczymy w obrębie stanowiska, bo każde ma własne charakterystyki 2. stopnia.
dane_linie_progowe <- h1_wartosci_graniczne_vw |>
  mutate(stanowisko = jako_stanowisko(stanowisko)) |>
  pivot_longer(all_of(names(kolumny_progow)),
               names_to = "kolumna", values_to = "wartosc") |>
  mutate(kategoria = factor(unname(kolumny_progow[kolumna]),
                            levels = names(kolory_kategorii))) |>
  filter(!is.na(kategoria), !is.na(wartosc)) |>
  select(stanowisko, kategoria, wartosc) |>
  group_by(stanowisko) |>
  filter(linia_widoczna(kategoria, wartosc)) |>
  ungroup() |>
  arrange(stanowisko, kategoria)

## 3.2 Kategorie przepływu ----------------------------------------------------

# Widok podaje liczbę dni w każdej kategorii. Udziały liczymy przez liczba_dni,
# czyli przez liczbę dni w okresie, a nie przez liczbę wyników - dzięki temu miesiąc
# z brakującym pomiarem nie udaje kompletnego.
kategorie_dlugie <- function(dane) {
  dane |>
    pivot_longer(all_of(names(kolumny_kategorii)),
                 names_to = "kolumna", values_to = "dni") |>
    mutate(kategoria = factor(unname(kolumny_kategorii[kolumna]),
                              levels = names(kolory_kategorii)),
           udzial = dni / liczba_dni) |>
    select(-kolumna)
}

kategorie <- h1_kategorie_przeplywu_vw |>
  filter(stanowisko == stanowisko_ujscie) |>
  mutate(rok_hydro = as.integer(rok_hydro))

# Filtr po lata_analizy, czyli po latach, dla których stanowisko odniesienia ma
# jakiekolwiek dane - a nie po latach z samego widoku kategorii. Widoki bywają
# rozbieżne w obie strony: 05ZM ma kategorie (i dobowe przepływy) dla roku, dla
# którego nie ma charakterystyk rocznych, a 11ZM i 09ZM odwrotnie - brakuje im
# kategorii dla lat zakwestionowanych. Zakres osi każdej ryciny powstaje osobno,
# z jej własnych danych (patrz lata_ryc_* niżej).
dane_kategorie_rok <- kategorie |>
  filter(okres_typ == "RH", rok_hydro %in% lata_analizy) |>
  kategorie_dlugie() |>
  arrange(rok_hydro, kategoria)

dane_kategorie_rok_miesiac <- kategorie |>
  filter(okres_typ == "M", rok_hydro %in% lata_analizy) |>
  mutate(miesiac = jako_miesiac(miesiac)) |>
  kategorie_dlugie() |>
  arrange(rok_hydro, miesiac, kategoria)

dane_kategorie_miesiac_rok <- filter(dane_kategorie_rok_miesiac,
                                     rok_hydro == analizowany_rok)

# Rok zakwestionowany w bazie nie wchodzi do widoku kategorii, choć ma charakterystyki
# roczne i miesięczne. Wtedy część kategoryjna raportu zostaje pusta i trzeba o tym
# powiedzieć wprost - puste ryciny wyglądałyby na usterkę skryptu.
brak_kategorii_w_roku <- nrow(dane_kategorie_miesiac_rok) == 0
if (brak_kategorii_w_roku) {
  warning("Widok h1_kategorie_przeplywu_vw nie zawiera kategorii przepływu dla roku",
          " hydrologicznego ", analizowany_rok, " (baza pomija lata zakwestionowane).",
          "\n  Zabraknie: panelu z miesiącami roku na rycinie 5, roku ",
          analizowany_rok, " na rycinie 6, liczby dni w tabeli 4 oraz tabeli 6 aneksu.",
          call. = FALSE)
}

# Miesiące wielolecia (W-M) nie mają roku hydrologicznego, więc nie podlegają
# filtrowi po roku - to zbiorcze podsumowanie całego okresu.
dane_kategorie_miesiac_wielolecie <- kategorie |>
  filter(okres_typ == "W-M") |>
  mutate(miesiac = jako_miesiac(miesiac)) |>
  kategorie_dlugie() |>
  arrange(miesiac, kategoria)

## 3.3 Kompletność serii ------------------------------------------------------

# Natężenie przepływu mierzone jest na każdym stanowisku, opad jest wspólny dla
# stacji, więc bierzemy go ze stanowiska odniesienia - inaczej ten sam panel
# powtórzyłby się dwa razy.
kompletnosc_przeplyw <- dane_agg |>
  filter(okres_typ == "M") |>
  transmute(stanowisko,
            rok_hydro,
            miesiac = jako_miesiac(miesiac),
            parametr = "Q_E",
            panel = if (ma_dwa_stanowiska)
                      paste0("Natężenie przepływu, ",
                             etykiety_stanowisk[as.character(stanowisko)])
                    else "Natężenie przepływu",
            kompletnosc = `kompletnosc_Q_E/q%`)

kompletnosc_opad <- dane_agg |>
  filter(okres_typ == "M", stanowisko == stanowisko_ujscie) |>
  transmute(stanowisko,
            rok_hydro,
            miesiac = jako_miesiac(miesiac),
            parametr = "RR_T",
            panel = "Opad atmosferyczny",
            kompletnosc = `kompletnosc_RR_T%`)

# Kolejność paneli składamy z wykazu stanowisk, a nie z kolejności wierszy w danych:
# widok oddaje stanowiska w porządku bazy (008 przed 009), a raport ma zaczynać
# od ujścia. Opad zawsze na końcu, bo jest jeden na stację.
poziomy_paneli <- c(
  if (ma_dwa_stanowiska)
    paste0("Natężenie przepływu, ", unname(etykiety_stanowisk[kody_stanowisk]))
  else "Natężenie przepływu",
  "Opad atmosferyczny")

dane_kompletnosc <- bind_rows(kompletnosc_przeplyw, kompletnosc_opad) |>
  mutate(panel = factor(panel, levels = poziomy_paneli),
         klasa = klasa_kompletnosci(kompletnosc)) |>
  arrange(panel, rok_hydro, miesiac)

################################################################################
# 4. DANE TABEL
################################################################################

## 4.1 Tabela 1 - charakterystyki roku analizowanego i wielolecia --------------

# Jedyna tabela obejmująca oba stanowiska. Wartości roku analizowanego stoją
# w wierszach, a nie w nagłówku, dzięki czemu układ jest ten sam niezależnie
# od liczby stanowisk.
tab_1_rok <- dane_agg |>
  filter(okres_typ == "RH", rok_hydro == analizowany_rok) |>
  select(stanowisko, NQ, SQ, WQ)

tab_1_wielolecie <- h1_dane_wieloletnie_vw |>
  mutate(stanowisko = jako_stanowisko(stanowisko)) |>
  select(stanowisko, NNQ, NSQ, NWQ, SNQ, SSQ, SWQ, WNQ, WSQ, WWQ)

# Układ z szablonu ZMŚP: dwa bloki jeden pod drugim - charakterystyki I stopnia dla
# roku analizowanego i II stopnia dla wielolecia, te drugie w siatce, w której symbol
# stoi obok swojej wartości. Kolumna typ niesie rolę wiersza; czyta ją tabela_blokowa()
# w funkcje/formatowanie_tabel.R i to ona rozstrzyga, które komórki się scala.
# Wartości zapisujemy jako TEKST, bo w wierszu siatki sąsiadują z symbolami.
# Stacja różnicowa dostaje blok na każde stanowisko, poprzedzony jego kodem.
wiersz_bloku <- function(typ, c1, c2 = "", c3 = "", c4 = "", c5 = "", c6 = "") {
  tibble(typ = typ, c1 = c1, c2 = c2, c3 = c3, c4 = c4, c5 = c5, c6 = c6)
}

blok_charakterystyk <- function(kod) {
  rok <- filter(tab_1_rok, stanowisko == kod)
  wlk <- filter(tab_1_wielolecie, stanowisko == kod)

  komorka <- function(ramka, nazwa) {
    if (nrow(ramka) == 0 || !nazwa %in% names(ramka)) "." else liczba_tab(ramka[[nazwa]][1], 3)
  }

  bind_rows(
    if (ma_dwa_stanowiska)
      wiersz_bloku("stanowisko", unname(etykiety_stanowisk[kod])),

    wiersz_bloku("sekcja",
                 paste0("Przepływy charakterystyczne I stopnia (", analizowany_rok, ")")),
    wiersz_bloku("naglowek", "NQ", "", "SQ", "", "WQ", ""),
    wiersz_bloku("wartosc", komorka(rok, "NQ"), "", komorka(rok, "SQ"), "",
                 komorka(rok, "WQ"), ""),

    # Blok II stopnia odpada w całości tam, gdzie baza nie ma jeszcze wielolecia.
    if (nrow(wlk) > 0) bind_rows(
      wiersz_bloku("sekcja",
                   paste0("Przepływy charakterystyczne II stopnia (", wielolecie_Q, ")")),
      wiersz_bloku("naglowek", "minimalne", "", "średnie", "", "maksymalne", ""),
      wiersz_bloku("siatka", "NNQ", komorka(wlk, "NNQ"), "SNQ", komorka(wlk, "SNQ"),
                   "WNQ", komorka(wlk, "WNQ")),
      wiersz_bloku("siatka", "NSQ", komorka(wlk, "NSQ"), "SSQ", komorka(wlk, "SSQ"),
                   "WSQ", komorka(wlk, "WSQ")),
      wiersz_bloku("siatka", "NWQ", komorka(wlk, "NWQ"), "SWQ", komorka(wlk, "SWQ"),
                   "WWQ", komorka(wlk, "WWQ"))))
}

tab_1_dane <- bind_rows(lapply(kody_stanowisk, blok_charakterystyk))

## 4.2 Tabele 2 i 3 - opad, odpływ i odpływ jednostkowy ------------------------

# Wiersz podsumowania okresu. Odpływ i opad sumujemy, współczynnik odpływu liczymy
# z sum (a nie jako średnią miesięcznych, bo miesiące mają różną wagę), skrajne
# wartości odpływu jednostkowego bierzemy z miesięcznych skrajnych, a średnią
# uśredniamy. Braki nie są pomijane: miesiąc bez opadu daje pustą sumę półrocza,
# co jest informacją, a nie usterką. Tak samo miesiąc, którego baza nie ma wcale
# (miesiąc zakwestionowany) - suma z pozostałych udawałaby wartość całego półrocza,
# więc półrocze niepełne dostaje wiersz z pustymi wartościami.
# Kolejność kolumn jest kolejnością z szablonu: opad przed odpływem, a odpływy
# jednostkowe średni - maksymalny - minimalny. Wektor etykiet w funkcje/tabele.R
# i tak ustawia kolumny po nazwach, ale zgodność obu miejsc oszczędza zdziwienia.
podsumuj_miesiace <- function(dane, miesiace, etykieta) {
  dane <- filter(dane, nr_miesiaca(miesiac) %in% miesiace)
  if (!all(miesiace %in% nr_miesiaca(dane$miesiac))) {
    return(tibble(okres = etykieta, RR_T = NA_real_, O = NA_real_, a = NA_real_,
                  q_avg = NA_real_, q_max = NA_real_, q_min = NA_real_))
  }
  tibble(okres = etykieta,
         RR_T  = sum(dane$RR_T),
         O     = sum(dane$O),
         a     = sum(dane$O) / sum(dane$RR_T),
         q_avg = mean(dane$`q avg`),
         q_max = max(dane$`q max`),
         q_min = min(dane$`q min`))
}

miesiace_rok <- dane_miesieczne_rok |>
  arrange(miesiac) |>
  transmute(okres = miesiac_rzymski(miesiac),
            RR_T, O, a,
            q_avg = `q avg`, q_max = `q max`, q_min = `q min`)

# Wiersz roku bierzemy z danych rocznych, a nie z sumy miesięcy: baza liczy go
# z wartości dobowych, więc jest spójny z resztą raportu.
wiersz_roku <- dane_roczne |>
  filter(rok_hydro == analizowany_rok) |>
  transmute(okres = "Rok hydrologiczny",
            RR_T, O, a,
            q_avg = `q avg`, q_max = `q max`, q_min = `q min`)

# Wiersz wielolecia. Opad wieloletni to średnia roczna (RR_T avg), a nie suma.
# Zakres lat w etykiecie dotyczy przepływu; różnicę wobec wielolecia opadu wyjaśnia
# przypis pod tabelą.
wiersz_wielolecia <- dane_wieloletnie |>
  transmute(okres = paste("Wielolecie", wielolecie_Q),
            RR_T = `RR_T avg`, O, a,
            q_avg = `q avg`, q_max = `q max`, q_min = `q min`)

# Tabela 2 opisuje miesiące roku analizowanego. Rok, dla którego baza nie ma ani
# jednego miesiąca, daje tabelę pustą - dokument i arkusz pomijają ją wtedy w całości,
# zamiast pokazywać same wiersze podsumowań bez niczego, co podsumowują.
tab_2_dane <- if (nrow(dane_miesieczne_rok) == 0) miesiace_rok[0, ] else bind_rows(
  miesiace_rok,
  podsumuj_miesiace(dane_miesieczne_rok, polrocze_zimowe, "Półrocze zimowe"),
  podsumuj_miesiace(dane_miesieczne_rok, polrocze_letnie, "Półrocze letnie"),
  wiersz_roku,
  wiersz_wielolecia)

tab_3_lata <- dane_roczne |>
  transmute(okres = as.character(rok_hydro),
            RR_T, O, a,
            q_avg = `q avg`, q_max = `q max`, q_min = `q min`)

# Wiersz n - liczba lat, na których opiera się wiersz wielolecia. Liczymy go OSOBNO
# dla każdej kolumny, a nie jedną liczbą na całą tabelę: braki w seriach nie muszą
# pokrywać się między opadem, warstwą odpływu i odpływem jednostkowym, więc średnia
# wieloletnia każdej z tych wielkości potrafi stać na innej liczbie lat. Przy seriach
# kompletnych wszystkie kolumny pokazują to samo n i wiersz czyta się jak jedna liczba.
wiersz_n <- tab_3_lata |>
  summarise(across(-okres, ~ sum(!is.na(.x)))) |>
  mutate(okres = "n", .before = 1)

tab_3_dane <- bind_rows(tab_3_lata, wiersz_wielolecia, wiersz_n)

## 4.3 Tabela 4 - kategorie przepływu -----------------------------------------

# Liczbę dni dokładamy do kompletu sześciu kategorii, a nie odwrotnie - tabela ma mieć
# wszystkie kategorie także wtedy, gdy któraś nie wystąpiła ani razu. Zero wpisujemy
# tylko wtedy, gdy dane o kategoriach w ogóle są; ich brak zostaje pustą komórką,
# bo "zero dni" i "brak podziału na kategorie" to dwie różne rzeczy.
kategorie_roku <- dane_kategorie_rok |>
  filter(rok_hydro == analizowany_rok) |>
  select(kategoria, dni)

# Skrót przy nazwie kategorii dokładamy PO złączeniu - złączenie idzie po kolumnie
# kategoria, więc zmiana etykiety musi nastąpić później, inaczej nie znalazłoby pary.
# Skrót wiąże tabelę z legendami rycin, na których stoi sam skrót.
tab_4_dane <- dane_progi |>
  left_join(kategorie_roku, by = "kategoria") |>
  mutate(dni = if (nrow(kategorie_roku) > 0) replace_na(dni, 0) else dni) |>
  mutate(kategoria = unname(etykiety_kategorii_ze_skrotem[as.character(kategoria)])) |>
  select(kategoria, warunek, dni, pusta)

## 4.4 Tabele aneksu ----------------------------------------------------------

# Aneks nie powtarza tabel raportu: roczne charakterystyki przepływu mieszczą się
# w tabeli 1 aneksu, a miesięczne wartości opadu i odpływu są co do wiersza tabelą 2
# raportu. Cyfra w nazwie obiektu jest NUMEREM TABELI W ANEKSIE - ta sama, którą
# widać w dokumencie i na zakładce arkusza Excela.

# Tabela 1 aneksu: pełne statystyki przepływu w kolejnych latach.
tab_a1_dane <- dane_roczne |>
  transmute(rok = as.character(rok_hydro),
            NQ, SQ, WQ, amplituda,
            sd = `Q_E sd`, cv = `Q_E cv`,
            p05 = `Q_E p05`, p25 = `Q_E p25`, p50 = `Q_E p50`,
            p75 = `Q_E p75`, p95 = `Q_E p95`,
            IQR = `Q_E p75` - `Q_E p25`)

# Tabela 2 aneksu: pełne statystyki odpływu jednostkowego w kolejnych latach.
tab_a2_dane <- dane_roczne |>
  transmute(rok = as.character(rok_hydro),
            min = `q min`, avg = `q avg`, max = `q max`,
            sd = `q sd`, cv = `q cv`,
            p05 = `q p05`, p25 = `q p25`, p50 = `q p50`,
            p75 = `q p75`, p95 = `q p95`,
            IQR = `q p75` - `q p25`)

# Tabela 3 aneksu: miesięczne charakterystyki przepływu roku analizowanego.
tab_a3_dane <- dane_miesieczne_rok |>
  arrange(miesiac) |>
  transmute(miesiac = miesiac_rzymski(miesiac), NQ, SQ, WQ, amplituda, kj)

# Tabela 4 aneksu: udziały kategorii w kolejnych latach.
tab_a4_dane <- dane_kategorie_rok |>
  select(rok_hydro, kategoria, udzial) |>
  pivot_wider(names_from = kategoria, values_from = udzial, names_expand = TRUE) |>
  transmute(rok = as.character(rok_hydro), across(all_of(names(kolory_kategorii))))

# Tabela 5 aneksu: udziały kategorii w miesiącach wielolecia.
tab_a5_dane <- dane_kategorie_miesiac_wielolecie |>
  select(miesiac, kategoria, udzial) |>
  pivot_wider(names_from = kategoria, values_from = udzial, names_expand = TRUE) |>
  transmute(miesiac = miesiac_rzymski(miesiac), across(all_of(names(kolory_kategorii))))

# Tabela 6 aneksu: udziały kategorii w miesiącach roku analizowanego.
tab_a6_dane <- dane_kategorie_miesiac_rok |>
  select(miesiac, kategoria, udzial) |>
  pivot_wider(names_from = kategoria, values_from = udzial, names_expand = TRUE) |>
  transmute(miesiac = miesiac_rzymski(miesiac), across(all_of(names(kolory_kategorii))))

################################################################################
# 5. STAŁE DO PODPISÓW
################################################################################

# Wielolecie zawsze z liczbą lat: zakres bywa dłuższy niż liczba lat użytych, bo baza
# pomija lata zakwestionowane. Wielolecie opadu podajemy osobno, bo bywa inne.
opis_wielolecia_Q <- opis_wielolecia(wielolecie_Q, wielolecie_Q_lat)
# Liczbę lat baza podaje wyłącznie dla wielolecia przepływowego (ile_lat), więc
# dopisujemy ją do opisu wielolecia opadowego tylko wtedy, gdy oba zakresy są
# identyczne - inaczej podawalibyśmy liczbę, której nikt nie policzył.
opis_wielolecia_opad <- if (identical(wielolecie_opad, wielolecie_Q))
                          opis_wielolecia_Q else wielolecie_opad
# Lata każdej ryciny wieloletniej - z jej własnych danych (patrz lata_z_danymi).
# Wyznaczają zakres osi lat (od pierwszego do ostatniego roku z danymi; luki
# w środku zostają pustym miejscem) oraz wykaz lat w podpisie ryciny. Rok z wierszem
# w widoku zagregowanym liczy się jako obecny, nawet z pustą wartością - taki rok
# ma kolumnę na mapach kompletności i opadu, gdzie brak pomiaru pokazuje biel.
# Seria dobowa bywa w bazie rokiem z samych braków, więc tam liczą się wartości.
lata_ryc_1  <- lata_z_danymi(dane_dobowe_wiel$rok_hydro, dane_dobowe_wiel$Q_E)
lata_ryc_4  <- lata_z_danymi(dane_miesieczne$rok_hydro)
lata_ryc_5  <- lata_z_danymi(dane_kategorie_rok$rok_hydro)
lata_ryc_6  <- lata_z_danymi(dane_kategorie_rok_miesiac$rok_hydro)
lata_ryc_7  <- lata_z_danymi(dane_roczne$rok_hydro)
lata_ryc_9  <- lata_z_danymi(dane_miesieczne$rok_hydro)
lata_ryc_11 <- lata_z_danymi(dane_kompletnosc$rok_hydro)

# Tabele wymieniają w podpisie lata, które faktycznie mają wiersz. Rok bez danych
# rocznych (albo bez kategorii) nie ma w tabeli wiersza, więc nie może stać w jej
# podpisie.
opis_lat_roczne <- zakres_lat(dane_roczne$rok_hydro)
opis_lat_kategorie <- zakres_lat(dane_kategorie_rok$rok_hydro)

# Miejsce w podpisie. Profil wodowskazowy wymieniamy tylko tam, gdzie stacja ma
# w słowniku więcej niż jeden profil - przy jednym nie ma czego rozróżniać i podpis
# zaczyna się wprost od nazwy stacji. Rozstrzyga o tym wymien_profil, a nie
# ma_dwa_stanowiska: Wigry raportują samo 008, ale baza ma też 009, więc podpis musi
# powiedzieć, z którego przekroju są wartości. Wersja z odniesieniem wchodzi do
# podpisów opisujących jedno stanowisko; wersja ze wszystkimi - do tabeli 1 oraz
# rycin 1, 2, 3 i 11.
opis_miejsca <- paste0(fraza_profilu(stanowiska[stanowiska$ujscie, , drop = FALSE],
                                     wymien_profil),
                       "w Stacji Bazowej ZMŚP ", nazwa_stacji)
opis_miejsc <- paste0(fraza_profilu(stanowiska, wymien_profil),
                      "w Stacji Bazowej ZMŚP ", nazwa_stacji)

# Sam opad nie należy do profilu wodowskazowego - jest mierzony dla stacji i wspólny
# dla jej stanowisk. Rycina o samym opadzie dostaje więc frazę bez profilu, także na
# stacji różnicowej, gdzie pozostałe podpisy profil wymieniają.
opis_stacji <- paste0("w Stacji Bazowej ZMŚP ", nazwa_stacji)

# Rozwinięcie skrótów w podpisach rycin. Składamy je z tego, co na rycinie NAPRAWDĘ
# stoi, a nie ze stałego tekstu: linia graniczna bywa pomijana (patrz linia_widoczna),
# a wtedy jej skrót w objaśnieniu wskazywałby na coś, czego nie ma. Przy braku
# wartości granicznych nie ma ani linii, ani zdania, które je zapowiada.
rozwin_skroty <- function(kategorie) {
  paste0(unname(skroty_kategorii[kategorie]), " – ", kategorie, collapse = ", ")
}

kategorie_linii <- levels(droplevels(dane_linie_progowe$kategoria))

opis_linii_progowych <- if (length(kategorie_linii) == 0) "" else
  paste0(" Linie przerywane wyznaczają granice kategorii natężenia przepływu",
         " obliczone dla wielolecia ", opis_wielolecia_Q, ": ",
         rozwin_skroty(kategorie_linii))

opis_kategorii <- rozwin_skroty(names(kolory_kategorii))

# Sprzątanie obiektów roboczych - do rycin i tabel trafia tylko to, co ma nazwę
# opisaną w nagłówku.
rm(dane_agg, kategorie, kategorie_roku, progi_ujscie, prog,
   kompletnosc_przeplyw, kompletnosc_opad,
   tab_1_rok, tab_1_wielolecie, wiersz_bloku, blok_charakterystyk,
   tab_3_lata, wiersz_n,
   miesiace_rok, wiersz_roku, wiersz_wielolecia)

message(">>> [przetwarzanie_danych.R] Zakończono sukcesem.")
