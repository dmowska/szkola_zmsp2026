################################################################################
# OPIS SKRYPTU
################################################################################
# zapis_tabel.R - eksport tabel raportu i aneksu do pliku wyniki/h1_tabele.xlsx
#
# Zapisuje dziesięć tabel w takiej postaci, w jakiej trafiają do dokumentów: te same
# kolumny, nagłówki, jednostki, zaokrąglenia i objaśnienia. Każda tabela ląduje
# w osobnym arkuszu, a ostatni arkusz zbiera objaśnienia oznaczeń i wykaz pozostałych
# arkuszy. Tabela, której baza nie policzyła, arkusza nie dostaje. Uruchamiany przez
# uruchamianie_skryptow.R, po tworzenie_wykresow.R.
#
# Uwagi do kodu:
#
# SKĄD POCHODZI UKŁAD TABEL
#   Opis każdej tabeli - podpis, etykiety kolumn, jednostki, zaokrąglenia, wiersze
#   wyróżnione i objaśnienia - pochodzi z funkcje/tabele.R, czyli z tego samego
#   miejsca, z którego korzystają dokumenty Worda. Arkusz pokazuje więc dokładnie
#   to samo co raport.
#
# CZYM ARKUSZ RÓŻNI SIĘ OD DOKUMENTU
#   Liczby są zapisane jako LICZBY, nie jako tekst, więc Excel pokaże je
#   z separatorem dziesiętnym ustawionym na Twoim komputerze - w raporcie separator
#   jest na stałe przecinkiem. Brak danych zostaje pustą komórką, a nie kropką:
#   pusta komórka nie przeszkadza w dalszych obliczeniach w arkuszu.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - tab_1_dane ... tab_4_dane (tabele raportu) oraz tab_a1_dane ... tab_a6_dane
#     (tabele aneksu): dane tabel przygotowane przez przetwarzanie_danych.R.
#     Cyfra w nazwie obiektu jest numerem tabeli w odpowiednim dokumencie.
# - dane_progi: kategorie przepływu wraz z warunkami (arkusz objaśnień)
# - parametry przebiegu: nazwa_stacji, analizowany_rok, stanowisko_ujscie,
#     opis_wielolecia_Q, opis_lat_roczne, opis_lat_kategorie, wielolecie_opad
# - funkcje/tabele.R: opis dziesięciu tabel
################################################################################
# WYNIK
################################################################################
# - wyniki/h1_tabele.xlsx: do jedenastu arkuszy - "Tabela 1" ... "Tabela 4"
#     (tabele raportu), "Aneks 1" ... "Aneks 6" (tabele aneksu, w jego kolejności)
#     oraz "Objaśnienia"
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - openxlsx
################################################################################

suppressWarnings(suppressMessages(library(openxlsx)))

source("funkcje/tabele.R")

dir.create("wyniki", showWarnings = FALSE)

# ------------------------------------------------------------------------------
# Style arkusza
# ------------------------------------------------------------------------------
styl_podpis <- createStyle(textDecoration = "bold", wrapText = TRUE, valign = "top")
styl_naglowek <- createStyle(textDecoration = "bold", halign = "center",
                             valign = "center", border = "TopBottomLeftRight",
                             borderColour = "gray", fgFill = "#F2F2F2")
styl_jednostki <- createStyle(halign = "center", valign = "center",
                              border = "TopBottomLeftRight", borderColour = "gray")
styl_dane <- createStyle(halign = "center", border = "TopBottomLeftRight",
                         borderColour = "gray")
styl_pierwsza_kolumna <- createStyle(textDecoration = "bold", halign = "left",
                                     border = "TopBottomLeftRight", borderColour = "gray")
styl_wyrozniony <- createStyle(textDecoration = "bold", halign = "center",
                               border = "TopBottomLeftRight", borderColour = "gray")
styl_objasnienia <- createStyle(fontSize = 9, wrapText = TRUE, valign = "top")
styl_sekcja <- createStyle(textDecoration = "bold")

# ------------------------------------------------------------------------------
# Zapis jednej tabeli do arkusza
# ------------------------------------------------------------------------------
# Układ arkusza: podpis, pusty wiersz, nagłówek, jednostki, dane, pusty wiersz,
# objaśnienia. Ten sam dla wszystkich dziesięciu tabel, więc czytelnik znajduje
# te same rzeczy w tych samych miejscach.
zapisz_tabele <- function(wb, opis) {
  # Tabela nieobliczona - jak progi kategorii na stacji, dla której baza nie ma
  # jeszcze wartości granicznych - nie dostaje arkusza. Pusty arkusz z samym
  # podpisem sugerowałby, że dane są, tylko się nie zapisały.
  dane_zrodlowe <- if (exists(opis$obiekt)) get(opis$obiekt) else NULL
  if (is.null(dane_zrodlowe) || nrow(dane_zrodlowe) == 0) return(invisible(NULL))

  dane <- kolumny_tabeli(dane_zrodlowe, opis)
  dane <- zaokraglij_tabele(dane, opis$dokladnosc)

  n_kol <- ncol(dane)
  addWorksheet(wb, opis$arkusz)

  # Podpis tabeli w pierwszym wierszu, scalony na szerokość tabeli.
  writeData(wb, opis$arkusz, wartosc_opisu(opis$podpis), startRow = 1, startCol = 1)
  mergeCells(wb, opis$arkusz, cols = 1:n_kol, rows = 1)
  addStyle(wb, opis$arkusz, styl_podpis, rows = 1, cols = 1:n_kol, gridExpand = TRUE)
  setRowHeights(wb, opis$arkusz, rows = 1, heights = 30)

  wiersz_naglowka <- 3
  # Tabela o układzie blokowym niesie nagłówki we własnych wierszach - w arkuszu
  # wpisujemy więc samą siatkę, bez wiersza etykiet i bez wiersza jednostek.
  uklad_blokowy <- identical(opis$uklad, "blok")
  # Jednostki pomijamy, gdy żadna kolumna ich nie ma (tabele kategorii).
  ma_jednostki <- !uklad_blokowy && any(nzchar(opis$jednostki))
  wiersz_danych <- if (uklad_blokowy) wiersz_naglowka
                   else wiersz_naglowka + 1 + as.integer(ma_jednostki)

  if (!uklad_blokowy) {
    writeData(wb, opis$arkusz, t(unname(opis$etykiety)),
              startRow = wiersz_naglowka, startCol = 1, colNames = FALSE)
    addStyle(wb, opis$arkusz, styl_naglowek, rows = wiersz_naglowka,
             cols = 1:n_kol, gridExpand = TRUE)
  }

  if (ma_jednostki) {
    writeData(wb, opis$arkusz, t(unname(opis$jednostki)),
              startRow = wiersz_naglowka + 1, startCol = 1, colNames = FALSE)
    addStyle(wb, opis$arkusz, styl_jednostki, rows = wiersz_naglowka + 1,
             cols = 1:n_kol, gridExpand = TRUE)
  }

  writeData(wb, opis$arkusz, dane, startRow = wiersz_danych, startCol = 1,
            colNames = FALSE, keepNA = FALSE)
  addStyle(wb, opis$arkusz, styl_dane,
           rows = wiersz_danych + seq_len(nrow(dane)) - 1,
           cols = 1:n_kol, gridExpand = TRUE)

  # Pierwsza kolumna niesie etykietę wiersza (okres, rok, miesiąc, kategoria),
  # więc wyrównujemy ją do lewej i pogrubiamy - tak samo jak w dokumentach.
  # W układzie blokowym pierwsza kolumna bywa wartością liczbową, więc zostaje
  # sformatowana jak reszta siatki.
  if (!uklad_blokowy) {
    addStyle(wb, opis$arkusz, styl_pierwsza_kolumna,
             rows = wiersz_danych + seq_len(nrow(dane)) - 1, cols = 1, gridExpand = TRUE)
  }

  # Wiersze podsumowań (półrocza, rok, wielolecie) pogrubione.
  wyroznione <- wartosc_opisu(opis$wyroznione, dane)
  if (!is.null(wyroznione)) {
    addStyle(wb, opis$arkusz, styl_wyrozniony,
             rows = wiersz_danych + wyroznione - 1, cols = 2:n_kol, gridExpand = TRUE)
    addStyle(wb, opis$arkusz, styl_pierwsza_kolumna,
             rows = wiersz_danych + wyroznione - 1, cols = 1, gridExpand = TRUE)
  }

  # Objaśnienia pod tabelą, każde w osobnym wierszu.
  objasnienia <- wartosc_opisu(opis$objasnienia)
  objasnienia <- objasnienia[!is.na(objasnienia) & nzchar(objasnienia)]
  if (length(objasnienia) > 0) {
    wiersz_objasnien <- wiersz_danych + nrow(dane) + 1
    for (i in seq_along(objasnienia)) {
      writeData(wb, opis$arkusz, objasnienia[i],
                startRow = wiersz_objasnien + i - 1, startCol = 1)
      mergeCells(wb, opis$arkusz, cols = 1:n_kol, rows = wiersz_objasnien + i - 1)
      addStyle(wb, opis$arkusz, styl_objasnienia,
               rows = wiersz_objasnien + i - 1, cols = 1:n_kol, gridExpand = TRUE)
    }
  }

  setColWidths(wb, opis$arkusz, cols = 1, widths = 22)
  if (n_kol > 1) setColWidths(wb, opis$arkusz, cols = 2:n_kol, widths = 11)

  invisible(NULL)
}

# ------------------------------------------------------------------------------
# Arkusz objaśnień
# ------------------------------------------------------------------------------
# Trzy bloki: wykaz arkuszy, oznaczenia zmiennych z jednostkami oraz kategorie
# przepływu wraz z warunkami. Bez niego arkusz byłby zrozumiały tylko dla kogoś,
# kto ma pod ręką raport.
zapisz_objasnienia <- function(wb, tabele) {
  arkusz <- "Objaśnienia"
  addWorksheet(wb, arkusz)
  wiersz <- 1

  blok <- function(tytul, ramka) {
    writeData(wb, arkusz, tytul, startRow = wiersz, startCol = 1)
    addStyle(wb, arkusz, styl_sekcja, rows = wiersz, cols = 1)
    writeData(wb, arkusz, ramka, startRow = wiersz + 1, startCol = 1)
    addStyle(wb, arkusz, styl_naglowek, rows = wiersz + 1,
             cols = seq_len(ncol(ramka)), gridExpand = TRUE)
    wiersz <<- wiersz + nrow(ramka) + 3
  }

  blok("Arkusze",
       data.frame(Arkusz = sapply(tabele, function(t) t$arkusz),
                  Zawartość = sapply(tabele, function(t) wartosc_opisu(t$podpis)),
                  stringsAsFactors = FALSE))

  blok("Oznaczenia",
       data.frame(Oznaczenie = names(opisy_zmiennych),
                  Opis = unname(opisy_zmiennych),
                  Jednostka = unname(jednostki_zmiennych[names(opisy_zmiennych)]),
                  stringsAsFactors = FALSE))

  # Blok kategorii odpada na stacjach, dla których baza nie ma wartości granicznych.
  if (nrow(dane_progi) > 0) {
    blok("Kategorie przepływu",
         data.frame(Kategoria = as.character(dane_progi$kategoria),
                    Warunek = dane_progi$warunek,
                    stringsAsFactors = FALSE))
  }

  setColWidths(wb, arkusz, cols = 1, widths = 24)
  setColWidths(wb, arkusz, cols = 2, widths = 100)
  setColWidths(wb, arkusz, cols = 3, widths = 16)

  invisible(NULL)
}

# ------------------------------------------------------------------------------
# Złożenie arkusza
# ------------------------------------------------------------------------------
wszystkie_tabele <- c(TABELE_RAPORT, TABELE_ANEKS)

wb <- createWorkbook()
for (opis in wszystkie_tabele) zapisz_tabele(wb, opis)
zapisz_objasnienia(wb, wszystkie_tabele)

saveWorkbook(wb, "wyniki/h1_tabele.xlsx", overwrite = TRUE)

message(">>> [zapis_tabel.R] Zakończono sukcesem: wyniki/h1_tabele.xlsx (",
        length(names(wb)), " arkuszy).")
