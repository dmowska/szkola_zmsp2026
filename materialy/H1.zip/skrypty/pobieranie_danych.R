################################################################################
# OPIS SKRYPTU
################################################################################
# pobieranie_danych.R - pobranie danych z bazy ZMŚP
#
# Pierwszy etap przebiegu. Czyta kod stacji i rok z parametry/parametry.xlsx, łączy
# się z bazą ZMŚP, pobiera osiem widoków h1_* zawężonych do tej stacji, sprawdza
# kompletność danych i zapisuje wszystko do dane/dane.RData. Uruchamiany przez
# uruchamianie_skryptow.R, przed przetwarzanie_danych.R.
#
# Uwagi do kodu:
#
# DANE DOSTĘPOWE DO BAZY
#   Login i hasło nigdy nie stoją w kodzie - skrypt czyta je ze zmiennych
#   środowiskowych z pliku .Renviron (wzór: .Renviron.example). Każda stacja ma
#   własne konto. R wczytuje .Renviron przy starcie sesji, więc po jego zmianie
#   trzeba zrestartować sesję (Session -> Restart R).
#
# ZAWĘŻENIE DO STACJI, ALE NIE DO STANOWISKA
#   Każde zapytanie zawęża widok do jednej stacji, więc dalsze skrypty nie muszą już
#   filtrować po stacji. Stanowiska zostają na tym etapie wszystkie, także te, których
#   raport nie opisuje (Wigry: ujściowe 009) - dopiero sekcja 2 skryptu
#   przetwarzanie_danych.R odsiewa je według słownika. Dzięki temu plik dane.RData
#   jest wiernym odbiciem tego, co baza ma dla stacji, a o zakresie raportu
#   rozstrzyga jedno miejsce: funkcje/slownik_stanowisk.R.
#
# DWA WIDOKI DOBOWE
#   h1_dane_dobowe_vw ma rok hydrologiczny wpisany na sztywno w definicji widoku,
#   więc oddaje wyłącznie rok analizowany - za to jako jedyny z opadem.
#   h1_dane_dobowe_wiel_q_e_vw niesie przepływ wszystkich lat wielolecia, ale bez
#   opadu. Żaden nie zastępuje drugiego, dlatego pobierane są oba.
#
# WIDOKI HYDROCHEMICZNE
#   Widoki h1_hydrochem_* nie należą do tego raportu - pobiera je osobny projekt
#   H1chem.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - parametry/parametry.xlsx: kod stacji bazowej oraz analizowany rok
# - .Renviron: dane dostępowe do bazy (ZMSP_DB_USER, ZMSP_DB_PASSWORD,
#     ZMSP_DB_HOST, ZMSP_DB_PORT, ZMSP_DB_NAME)
# - slownik_stanowisk: ramka ze stacjami bazowymi i ich stanowiskami
#     wodowskazowymi (kod, nazwa, stanowisko, raport, ujscie, kolejnosc, ciek)
# - funkcje z funkcje/funkcje_pomocnicze.R: stacja_ze_slownika, przygotuj_widoki,
#     parametry_wielolecia, zapisz_dane_h1
#   Słownik i funkcje wczytuje uruchamianie_skryptow.R przed tym skryptem.
################################################################################
# WYNIK
################################################################################
#   Plik dane/dane.RData, a w nim osiem widoków pod nazwami z bazy:
#     h1_dane_dobowe_vw              - dobowy przepływ, odpływ i opad roku
#                                      analizowanego
#     h1_dane_dobowe_wiel_q_e_vw     - dobowy przepływ wszystkich lat wielolecia
#     h1_dane_agg_vw                 - charakterystyki miesięczne i roczne
#     h1_dane_wieloletnie_vw         - charakterystyki II stopnia wielolecia
#     h1_dane_wieloletnie_dobowe_vw  - przebieg roku uśredniony po latach
#     h1_wsp_msc_wiel_przeplywu_vw   - wieloletnie średnie miesięczne
#     h1_kategorie_przeplywu_vw      - liczba dni w kategoriach przepływu
#     h1_wartosci_graniczne_vw       - progi kategorii przepływu
#
#   oraz parametry raportu:
#     stacja, nazwa_stacji, stanowiska, stanowisko_ujscie, wymien_profil,
#     analizowany_rok
#         - z parametry/parametry.xlsx i ze słownika stanowisk,
#     wielolecie_Q, wielolecie_Q_lat, wielolecie_opad, lata_analizy
#         - odczytane z pobranych danych; wchodzą do podpisów rycin i tytułów tabel.
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - readxl
# - RPostgres
################################################################################

# 1. WCZYTANIE PARAMETRÓW
if (!file.exists("parametry/parametry.xlsx")) stop("Brak pliku parametry/parametry.xlsx!")

parametry <- read_excel("parametry/parametry.xlsx")
stacja          <- parametry$wartosc[parametry$parametr == "kod stacji bazowej"]
analizowany_rok <- as.integer(parametry$wartosc[parametry$parametr == "analizowany rok"])

# Rok musi być jedną liczbą. Brakujący wiersz w pliku daje wektor pusty, a nie NA,
# więc kontrola sprawdza i długość, i wartość. Kod stacji sprawdza słownik stanowisk.
if (length(analizowany_rok) != 1 || is.na(analizowany_rok)) {
  stop("W parametry/parametry.xlsx wiersz 'analizowany rok' ma być rokiem, np. 2025.",
       call. = FALSE)
}

# Nazwa stacji, wykaz jej stanowisk RAPORTOWANYCH w kolejności raportowej i kod
# stanowiska odniesienia. Stanowiska z raport = FALSE w słowniku (Wigry: 009)
# odpadają już tutaj i nie pojawiają się w żadnej tabeli ani rycinie. Nieznany kod
# przerywa pracę.
stacja_info <- stacja_ze_slownika(stacja, slownik_stanowisk)
nazwa_stacji <- stacja_info$nazwa
stanowiska <- stacja_info$stanowiska
stanowisko_ujscie <- stacja_info$ujscie
# Czy podpisy mają wymieniać profil wodowskazowy - patrz fraza_profilu(). Liczy się
# liczba profili W SŁOWNIKU, a nie liczba raportowanych, więc Wigry wymieniają swoje
# 008 mimo że raport obejmuje tylko jedno stanowisko.
wymien_profil <- stacja_info$wymien_profil

message("   Wybrana stacja: ", nazwa_stacji, " (", stacja, "), stanowiska w raporcie: ",
        paste(stacja_info$kody_stanowisk, collapse = ", "),
        "; odniesienie: ", stanowisko_ujscie)

# 2. POŁĄCZENIE Z BAZĄ DANYCH
message("   Łączenie z bazą danych ZMŚP...")

# R wczytuje .Renviron automatycznie przy starcie sesji. Poniższa linia obsługuje
# przypadek, gdy sesja wystartowała w innym katalogu roboczym.
if (Sys.getenv("ZMSP_DB_PASSWORD") == "" && file.exists(".Renviron")) readRenviron(".Renviron")

if (Sys.getenv("ZMSP_DB_PASSWORD") == "") {
  stop("Brak danych dostępowych do bazy! Utwórz plik .Renviron na wzór",
       " .Renviron.example i zrestartuj sesję R.", call. = FALSE)
}

# Nieudane połączenie kończy się listą rzeczy do sprawdzenia. W treści zostaje też
# oryginalny komunikat serwera - odróżnia złe hasło od zablokowanego dostępu do portu.
con <- tryCatch(
  DBI::dbConnect(RPostgres::Postgres(),
                 user     = Sys.getenv("ZMSP_DB_USER"),
                 password = Sys.getenv("ZMSP_DB_PASSWORD"),
                 host     = Sys.getenv("ZMSP_DB_HOST"),
                 port     = as.integer(Sys.getenv("ZMSP_DB_PORT")),
                 dbname   = Sys.getenv("ZMSP_DB_NAME")),
  error = function(e) {
    stop("Nie udało się połączyć z bazą danych ZMŚP (SIMSP).\n",
         "  Komunikat serwera: ", conditionMessage(e),
         "  Sprawdź kolejno:\n",
         "  1. login i hasło w pliku .Renviron (ZMSP_DB_USER i ZMSP_DB_PASSWORD) -",
         " każda stacja ma własne konto;\n",
         "  2. czy po zmianie .Renviron sesja R została zrestartowana",
         " (Session -> Restart R) - R czyta ten plik tylko przy starcie;\n",
         "  3. połączenie z internetem oraz dostęp do serwera ",
         Sys.getenv("ZMSP_DB_HOST"), " na porcie ", Sys.getenv("ZMSP_DB_PORT"),
         " - w sieci instytucjonalnej bywa zablokowany i potrzebny jest VPN",
         " albo zgłoszenie do działu IT.",
         call. = FALSE)
  })


# 3. POBIERANIE DANYCH
message("   Pobieranie widoków danych...")

# Jedna funkcja na wszystkie osiem zapytań: warunek WHERE stoi w jednym miejscu.
pobierz_widok <- function(widok) {
  DBI::dbGetQuery(con, paste0("SELECT * FROM raportowanie.", widok,
                              " WHERE stacja = ", DBI::dbQuoteString(con, stacja), ";"))
}

# TA LISTA JEST JEDYNYM WYKAZEM POBIERANYCH WIDOKÓW - dołożenie albo usunięcie widoku
# robi się wyłącznie tutaj. Nazwy elementów muszą pozostać nazwami widoków: pod nimi
# odczytują je kontrole i pod nimi trafiają do dane/dane.RData. Widok pominięty na
# liście przerywa pracę z własną nazwą w komunikacie.
widoki <- list(
  h1_dane_dobowe_vw             = pobierz_widok("h1_dane_dobowe_vw"),
  h1_dane_agg_vw                = pobierz_widok("h1_dane_agg_vw"),

  h1_dane_dobowe_wiel_q_e_vw    = pobierz_widok("h1_dane_dobowe_wiel_q_e_vw"),
  h1_dane_wieloletnie_vw        = pobierz_widok("h1_dane_wieloletnie_vw"),
  h1_dane_wieloletnie_dobowe_vw = pobierz_widok("h1_dane_wieloletnie_dobowe_vw"),
  h1_wsp_msc_wiel_przeplywu_vw  = pobierz_widok("h1_wsp_msc_wiel_przeplywu_vw"),
  h1_kategorie_przeplywu_vw     = pobierz_widok("h1_kategorie_przeplywu_vw"),
  h1_wartosci_graniczne_vw      = pobierz_widok("h1_wartosci_graniczne_vw")
)

DBI::dbDisconnect(con)
message("   Połączenie z bazą zakończone.")


# 4. KONTROLA I DOPASOWANIE PARAMETRÓW
# Dwa kroki, oba wykonują funkcje z funkcje/funkcje_pomocnicze.R:
#
#  - KONTROLE sprawdzają obecność roku analizowanego w danych rocznych, miesięcznych
#    i dobowych, kompletność serii oraz obecność agregatów wieloletnich, a przy okazji
#    ujednolicają typy kolumn. Pracę PRZERYWA tylko stacja bez żadnych danych
#    przepływu. Brak roku analizowanego albo jego miesięcy w którymś widoku oraz brak
#    agregatów wieloletnich dają OSTRZEŻENIE z wykazem elementów, których zabraknie:
#    raport powstaje, a tabele i ryciny pomijają lata i miesiące nieobecne w bazie.
#
#  - WIELOLECIE odczytujemy z danych, a nie z parametry.xlsx - to baza rozstrzyga,
#    które lata weszły do charakterystyk, a przepływ i opad mają własne zakresy.
#    Użytkownik nie musi więc znać zakresu danych swojej stacji. Zakres jest widoczny
#    w gotowym dokumencie, bo wchodzi do podpisów rycin i tytułów tabel.
widoki <- przygotuj_widoki(widoki, stacja_info, analizowany_rok)

wielolecie <- parametry_wielolecia(widoki, stacja_info, analizowany_rok)

message("   Wielolecie przepływu: ",
        opis_wielolecia(wielolecie$wielolecie_Q, wielolecie$wielolecie_Q_lat),
        "; wielolecie opadu: ", wielolecie$wielolecie_opad,
        "\n   Lata objęte analizą: ", zakres_lat(wielolecie$lata_analizy),
        "; rok analizowany: ", analizowany_rok, ".")


# 5. ZAPIS DANYCH DO PLIKU
message("   Zapisywanie danych do pliku 'dane/dane.RData'...")

zapisz_dane_h1(
  widoki = widoki,
  parametry = c(
    # Parametry konfiguracyjne
    list(stacja = stacja,
         nazwa_stacji = nazwa_stacji,
         stanowiska = stanowiska,
         stanowisko_ujscie = stanowisko_ujscie,
         wymien_profil = wymien_profil,
         analizowany_rok = analizowany_rok),

    # Parametry wyprowadzone z danych
    wielolecie))

message(">>> [pobieranie_danych.R] Zakończono sukcesem.")
