################################################################################
# OPIS SKRYPTU
################################################################################
# funkcje/funkcje_pomocnicze.R - funkcje wspólne dla całego przebiegu
#
# Plik nic nie liczy - definiuje funkcje i stałe używane w kilku miejscach przebiegu:
# przy pobieraniu danych, przy ich przetwarzaniu, w tabelach i na rycinach. Wczytuje
# go uruchamianie_skryptow.R na starcie, przed pierwszym etapem.
#
# Uwagi do kodu:
#
# DWA POZIOMY OSTROŚCI KONTROLI
#   Pracę przerywa wyłącznie stacja bez żadnych danych przepływu - z niczego nie da
#   się złożyć raportu. Brak roku analizowanego w części widoków, brak agregatów
#   wieloletnich i niepełny rok dają tylko ostrzeżenie: raport powstaje, tylko
#   węższy, a komunikat wylicza wprost, czego w nim nie będzie.
#
# KATEGORIE PRZEPŁYWU
#   Sześć kategorii - od wezbrania wielkiego po niżówkę głęboką - ma w tym pliku
#   ustaloną kolejność, barwy, skróty i pełne nazwy. Wszystkie tabele i ryciny
#   biorą je stąd, więc legendy i podpisy są wszędzie takie same.
#
# OZNACZENIA Z BAZY
#   opisy_zmiennych i jednostki_zmiennych tłumaczą oznaczenia bazy (Q_E, SSQ, kj, a)
#   na opis słowny i jednostkę. Z nich powstają etykiety osi rycin i nagłówki tabel.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - brak - plik nie korzysta z żadnych obiektów zewnętrznych
################################################################################
# WYNIK
################################################################################
#   Lata i wielolecie:
#     rok_hydrologiczny  - rok hydrologiczny daty (listopad zaczyna nowy rok)
#     zakres_lat         - zwięzły zapis zbioru lat: "1995-2025" albo wykaz z lukami
#     opis_wielolecia    - zakres wielolecia wraz z liczbą lat, do podpisów
#     czlon_wielolecia   - człon podpisu o wieloleciu, pusty przy braku agregatów
#     odmiana_lat        - "rok", "lata", "lat" - polska odmiana liczebnika
#
#   Stacja i stanowiska:
#     stacja_ze_slownika - nazwa stacji, jej stanowiska raportowane i wskazanie
#                          stanowiska odniesienia
#     fraza_profilu      - fraza "w profilu wodowskazowym Y" do podpisów; pusta,
#                          gdy stacja ma w słowniku jedno stanowisko
#
#   Pobranie danych i kontrole:
#     widok_z_listy      - odczyt widoku z listy pobranej przez skrypt pobierania
#     bez_integer64      - sprowadzenie kolumn bigint z bazy do zwykłego numeric
#     przygotuj_widoki   - komplet kontroli wykonywanych po pobraniu danych
#     sprawdz_dane_stacji, sprawdz_dane_wieloletnie, sprawdz_rok_analizowany,
#     sprawdz_kompletnosc_roku
#                        - poszczególne kontrole, wywoływane przez przygotuj_widoki
#     parametry_wielolecia - zakresy wielolecia i lata objęte analizą
#     zapisz_dane_h1     - zapis widoków i parametrów do dane/dane.RData
#
#   Miesiące:
#     miesiace_hydro     - kolejność miesięcy roku hydrologicznego (XI, XII, I-X)
#     jako_miesiac       - miesiąc w dowolnym zapisie na faktor o tej kolejności
#     nr_miesiaca, miesiac_rzymski - numer kalendarzowy i zapis rzymski miesiąca
#     polrocze_zimowe, polrocze_letnie - podział roku hydrologicznego na półrocza
#
#   Kategorie przepływu:
#     kolory_kategorii, skroty_kategorii, kolumny_kategorii - barwy, skróty
#                          i kolejność sześciu kategorii
#     etykiety_kategorii_ze_skrotem - nazwa kategorii wraz ze skrótem, do tabel
#     kolumny_progow     - wartości graniczne kategorii i nazwy ich kolumn w widoku
#     linia_widoczna     - odsiew linii granicznych, które przecinają sąsiednią
#
#   Opisy i liczby:
#     opisy_zmiennych, jednostki_zmiennych - opis słowny i jednostka oznaczeń z bazy
#     etykieta_osi       - gotowy opis osi ryciny wraz z jednostką
#     liczba_txt         - dokładna wartość liczbowa w tekście warunku
#     liczba_tab         - wartość liczbowa jako tekst komórki tabeli
#
#   Ryciny:
#     kolory_kompletnosc, klasa_kompletnosci - paleta i klasy kompletności serii
#     kolory_perc_doy, kolory_linii_doy, kolory_rok_wielolecie, kolory_liczby_dni
#                        - palety pozostałych rycin
#     klucze_legendy     - warstwa przywracająca klucze legendy poziomom bez danych
#     lata_z_danymi      - lata, w których seria ma wartości; zakres osi danej ryciny
#     krok_osi_lat, os_lat - podziałki i podpisy osi lat, dobrane do długości serii
#     ma_dane            - czy seria ma choć jedną wartość; decyduje, czy rycina
#                          powstanie, czy zostanie zastąpiona przez NULL
#     max_lub            - największa wartość serii, odporna na komplet braków
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2 (wyłącznie w klucze_legendy; pozostałe funkcje korzystają z R base)
################################################################################

################################################################################
# ROK HYDROLOGICZNY
################################################################################

# Rok hydrologiczny zaczyna się 1 listopada, więc listopad i grudzień należą już do
# roku następnego: 2024-11-01 to rok hydrologiczny 2025. Widok danych dobowych podaje
# samą datę pomiaru, bez roku hydrologicznego - stąd ta funkcja. Widoki zagregowane
# mają gotową kolumnę rok_hydro i tej funkcji nie potrzebują.
rok_hydrologiczny = function(daty, poczatek = 11) {
  daty <- as.Date(daty)
  rok <- as.integer(format(daty, "%Y"))
  miesiac <- as.integer(format(daty, "%m"))
  ifelse(miesiac >= poczatek, rok + 1L, rok)
}

################################################################################
# ZAPIS ZAKRESU LAT
################################################################################

# Zwięzły zapis zbioru lat: ciągły przedział jako "1995-2024", z lukami jako wykaz.
# Używany w komunikatach o błędach - użytkownik ma od razu widzieć, co jest w bazie.
zakres_lat = function(lata) {
  lata <- sort(unique(as.integer(lata)))
  lata <- lata[!is.na(lata)]
  if (length(lata) == 0) return("brak")
  if (length(lata) == 1) return(as.character(lata))
  if (identical(lata, min(lata):max(lata))) paste0(min(lata), "-", max(lata))
  else paste(lata, collapse = ", ")
}

# Wielolecie w podpisach zawsze z liczbą lat: zakres bywa dłuższy niż liczba lat
# faktycznie użytych, bo baza pomija lata zakwestionowane. "2009-2025" potrafi więc
# oznaczać 15 lat, a nie 17.
opis_wielolecia = function(zakres, ile_lat) {
  if (is.na(zakres) || !nzchar(zakres)) return("brak")
  if (is.na(ile_lat)) return(as.character(zakres))
  paste0(zakres, " (kompletność wielolecia: ", ile_lat, " ", odmiana_lat(ile_lat), ")")
}

# Człon podpisu wymieniający wielolecie - "oraz wieloleciu 1995-2025 (...)", "na tle
# wartości wieloletnich 1995-2025 (...)" i podobne. Stacja, dla której baza nie ma
# agregatów wieloletnich (08ZM, 15ZM), nie ma czego zestawiać: rycina pokazuje sam rok
# analizowany, a tabela sam blok I stopnia. Człon nie powstaje wtedy w ogóle - podpis
# kończy się na roku analizowanym.
#
# Argument koniec domyka człon wartością wyliczoną z danych wieloletnich ("wynosi
# 0,35" pod ryciną 7). Wolno tam podać wyrażenie, które przy braku wielolecia nie
# miałoby z czego się policzyć - R wylicza argumenty leniwie, a gałąź bez wielolecia
# kończy się przed ich użyciem.
czlon_wielolecia = function(ma_wielolecie, wstep, opis, koniec = "") {
  if (!isTRUE(ma_wielolecie)) return("")
  paste0(wstep, opis, koniec)
}

# "1 rok", "2 lata", "5 lat" - polska odmiana liczebnika. Bez niej podpisy rycin
# miałyby "22 lat" albo "3 lat".
odmiana_lat = function(n) {
  n <- as.integer(n)
  if (is.na(n)) return("lat")
  reszta_10 <- n %% 10
  reszta_100 <- n %% 100
  if (n == 1) "rok"
  else if (reszta_10 %in% 2:4 && !(reszta_100 %in% 12:14)) "lata"
  else "lat"
}

################################################################################
# SŁOWNIK STANOWISK
################################################################################

# Zwraca wszystko, co raport wie o stacji poza danymi: nazwę, wykaz stanowisk
# RAPORTOWANYCH w kolejności raportowej i kod stanowiska odniesienia. Nieznany kod
# przerywa pracę - bez nazwy stacji nie ma tytułu, a bez wskazania odniesienia nie
# wiadomo, skąd wziąć opad i odpływ. To sytuacja do naprawienia w słowniku, nie do
# obejścia wartością zastępczą.
#
# STANOWISKA POZA RAPORTEM
#   Wiersze z raport = FALSE odpadają tutaj, na samym wejściu - dalej w przebiegu nie
#   ma już o nich mowy, a ich dane odsiewa sekcja 2 skryptu przetwarzanie_danych.R.
#   Jedynym śladem jest wymien_profil: stacja, której raport pomija któryś profil,
#   nadal wymienia w podpisach numer profilu, którego dotyczy (Wigry: 008). Bez tego
#   podpis brzmiałby "w Stacji Bazowej ZMŚP Wigry" i nie mówiłby, z którego z dwóch
#   przekrojów są wartości.
stacja_ze_slownika = function(kod, slownik) {
  kod <- trimws(as.character(kod))
  wszystkie <- slownik[slownik$kod == kod, , drop = FALSE]

  if (nrow(wszystkie) == 0) {
    stop("Nieznany kod stacji: '", kod, "'.",
         "\n  W pliku parametry/parametry.xlsx, w wierszu 'kod stacji bazowej', wpisz",
         " jeden z kodów: ", paste(sort(unique(slownik$kod)), collapse = ", "), ".",
         "\n  Jeśli stacja jest nowa, dopisz jej stanowiska w funkcje/slownik_stanowisk.R.",
         call. = FALSE)
  }

  wiersze <- wszystkie[wszystkie$raport, , drop = FALSE]

  if (nrow(wiersze) == 0) {
    stop("Stacja ", kod, " nie ma w słowniku ani jednego stanowiska z raport = TRUE,",
         " więc raport nie miałby o czym mówić.",
         "\n  Popraw kolumnę 'raport' w funkcje/slownik_stanowisk.R.", call. = FALSE)
  }

  wiersze <- wiersze[order(wiersze$kolejnosc), , drop = FALSE]
  ujscie <- wiersze$stanowisko[wiersze$ujscie]

  if (length(ujscie) != 1) {
    stop("Stacja ", kod, " ma wśród stanowisk raportowanych ", length(ujscie),
         " oznaczonych jako odniesienie (ujscie = TRUE), a powinna mieć dokładnie",
         " jedno.",
         "\n  Popraw kolumny 'ujscie' i 'raport' w funkcje/slownik_stanowisk.R.",
         call. = FALSE)
  }

  list(kod = kod,
       nazwa = wiersze$nazwa[1],
       stanowiska = wiersze,
       kody_stanowisk = wiersze$stanowisko,
       ujscie = ujscie,
       wymien_profil = nrow(wszystkie) > 1)
}

# Fraza lokalizacyjna podpisu, poprzedzająca nazwę stacji. Profil wodowskazowy
# wymieniamy WYŁĄCZNIE na stacji o więcej niż jednym profilu w słowniku - tam bez
# niego nie wiadomo, którego przekroju dotyczy rycina albo tabela. Stacja o jednym
# stanowisku żadnego rozróżnienia nie potrzebuje: podpis zaczyna się wprost od nazwy
# stacji, a fraza jest pusta.
#
# Nazwa cieku do podpisu NIE wchodzi. Profil identyfikuje kod stanowiska - to on stoi
# w bazie i on jednoznacznie wskazuje przekrój; nazwa cieku niczego nie rozstrzygała,
# a wymagała odmiany przez przypadki ("rzeki Czarnej Hańczy"), której słownik nie ma.
# Kolumna ciek zostaje w słowniku jako informacja o stacji.
#
# wymien_profil dotyczy CAŁEJ stacji, a nie przekazanej ramki, i to z dwóch powodów.
# Po pierwsze podpis dla samego stanowiska odniesienia dostaje jeden wiersz, a i tak
# ma wymienić profil, jeśli stacja ma ich dwa. Po drugie liczy się liczba profili
# W SŁOWNIKU, a nie liczba raportowanych: Wigry mają w raporcie samo 008, ale baza ma
# też 009, więc podpis musi powiedzieć, o który przekrój chodzi.
# Fraza kończy się spacją, żeby składało się ją wprost z nazwą stacji.
fraza_profilu = function(stanowiska, wymien_profil) {
  if (!isTRUE(wymien_profil)) return("")

  kody <- as.character(stanowiska$stanowisko)
  if (length(kody) == 1) paste0("w profilu wodowskazowym ", kody, " ")
  else paste0("w profilach wodowskazowych ", paste(kody, collapse = " i "), " ")
}

################################################################################
# KONTROLE PO POBRANIU DANYCH
################################################################################

# Odczyt jednego widoku z listy zbudowanej przez skrypt pobierania. Jedyny wykaz
# widoków stoi w skrypty/pobieranie_danych.R i tylko tam się go zmienia.
#
# Kontrolą jest samo sięgnięcie po widok: nazwa, której na liście nie ma, przerywa
# pracę komunikatem wskazującym brakujący widok i plik, w którym trzeba go dopisać.
widok_z_listy = function(widoki, nazwa) {
  dane <- widoki[[nazwa]]
  if (is.null(dane)) {
    stop("Na liście pobranych widoków brakuje ", nazwa, ".",
         "\n  Dopisz go do listy 'widoki' w skrypty/pobieranie_danych.R.",
         call. = FALSE)
  }
  dane
}

################################################################################
# TYPY KOLUMN Z BAZY
################################################################################

# Kolumny całkowite ośmiobajtowe (bigint) sterownik RPostgres oddaje jako integer64
# z pakietu bit64 - tak przychodzą liczby dni w widoku kategorii (liczba_dni,
# liczba_wynikow, liczby dni w kategoriach) oraz ile_lat w widoku wielolecia.
#
# Różnica jest groźna, bo integer64 to POD SPODEM double z podmienioną klasą.
# Wszystko, co na takiej kolumnie działa, działa wyłącznie przez metody S3 pakietu
# bit64. Gdy bit64 nie jest wczytany - a w przebiegu wciąga go dopiero RPostgres,
# czyli tylko wariant bazodanowy - as.numeric(30) zwraca 1,48e-322 zamiast 30
# i robi to BEZ ostrzeżenia: udziały kategorii wychodzą wtedy zerowe, a ryciny
# i tabele wyglądają na policzone. Zdarza się to za każdym razem, gdy
# przetwarzanie_danych.R uruchomić samo, z gotowego dane/dane.RData.
#
# Dlatego sprowadzamy takie kolumny do zwykłego numeric od razu po pobraniu.
# Dalsze skrypty widzą wtedy te same typy niezależnie od źródła danych i nie zależą
# od tego, czy któryś pakiet zdążył wczytać swoje metody.
bez_integer64 = function(dane) {
  kolumny <- names(dane)[vapply(dane, inherits, logical(1), "integer64")]
  if (length(kolumny) == 0) return(dane)

  # Metody bit64 rejestrują się przy wczytaniu przestrzeni nazw pakietu - bez tego
  # sama zamiana czytałaby surowe bajty. loadNamespace nie dokłada pakietu do ścieżki
  # wyszukiwania, więc nie przesłania funkcji bazowych (bit64 maskuje m.in. match,
  # order i table).
  loadNamespace("bit64")
  for (kolumna in kolumny) dane[[kolumna]] <- as.numeric(dane[[kolumna]])
  dane
}

# Komplet kontroli wykonywanych po pobraniu danych. Zwraca widoki w typach, na
# których liczą dalsze skrypty.
przygotuj_widoki = function(widoki, stacja_info, analizowany_rok) {

  # 0. Typy kolumn - zanim cokolwiek policzymy na liczbie dni czy liczbie lat.
  widoki <- lapply(widoki, bez_integer64)

  # 0a. Stacja w ogóle ma dane w bazie - inaczej kolejne kontrole dałyby mylące
  # ostrzeżenia o raporcie bez części porównawczej. Jedyna kontrola, która przerywa pracę.
  sprawdz_dane_stacji(widoki, stacja_info)

  # 1. Dane wieloletnie i wartości graniczne - bez nich raport traci część porównawczą.
  sprawdz_dane_wieloletnie(widoki, stacja_info)

  # 2. Rok analizowany w danych rocznych, miesięcznych i dobowych - tylko ostrzeżenie.
  sprawdz_rok_analizowany(widoki, stacja_info, analizowany_rok)

  # 3. Niepełny rok - tylko ostrzeżenie.
  sprawdz_kompletnosc_roku(widoki, stacja_info, analizowany_rok)

  widoki
}

# Agregaty wieloletnie bywają w bazie nieobliczone - dwie stacje nie mają ich wcale
# ("BRAK wielolecia, wartości granicznych, wsp. miesięcznych i wieloletnich dobowych"),
# choć ich dane roczne i dobowe są kompletne. Raport dla takiej stacji powstaje bez
# elementów, które z tych agregatów wynikają: bez części II stopnia w tabeli 1, bez
# tabeli progów, bez linii granicznych na rycinach 1 i 2, bez rycin kategorii i wstęg
# wieloletnich. Dlatego tylko ostrzegamy, i to wyliczając wprost, czego zabraknie -
# przerwanie pracy odbierałoby stacji cały raport zamiast jego części porównawczej.
#
# Dobowe przepływy kolejnych lat (h1_dane_dobowe_wiel_q_e_vw) są tu z tego samego
# powodu, choć nie są agregatem: bez nich rycina 1 nie znika częściowo, tylko w całości
# (ma_dane w wykresy/ryc_1.R ustawia ją na NULL, a dokument pomija wtedy jej blok).
# Cicha luka w numeracji rycin byłaby trudniejsza do zauważenia niż ostrzeżenie.
sprawdz_dane_wieloletnie = function(widoki, stacja_info) {
  wymagane <- c(h1_dane_wieloletnie_vw = "wielolecie przepływu",
                h1_wartosci_graniczne_vw = "wartości graniczne kategorii przepływu",
                h1_dane_wieloletnie_dobowe_vw = "statystyki wieloletnie dla dni roku",
                h1_wsp_msc_wiel_przeplywu_vw = "wieloletnie współczynniki miesięczne",
                h1_dane_dobowe_wiel_q_e_vw = "dobowe przepływy kolejnych lat")

  brak_dla_ujscia <- character(0)
  for (widok in names(wymagane)) {
    dane <- widok_z_listy(widoki, widok)
    if (!any(dane$stanowisko == stacja_info$ujscie)) {
      brak_dla_ujscia <- c(brak_dla_ujscia, paste0(wymagane[[widok]], " (", widok, ")"))
    }
  }

  if (length(brak_dla_ujscia) > 0) {
    warning("Baza nie ma danych wieloletnich dla stacji ", stacja_info$nazwa,
            " (", stacja_info$kod, "), stanowisko odniesienia ", stacja_info$ujscie, ".",
            "\n  Brakuje: ", paste(brak_dla_ujscia, collapse = "; "), ".",
            "\n  Raport powstanie bez części porównawczej: bez charakterystyk 2. stopnia",
            " w tabeli 1, bez tabeli wartości granicznych, bez linii granicznych",
            " na rycinach 1 i 2, bez rycin kategorii, bez wstęg wieloletnich",
            " oraz bez samej ryciny 1, gdy brakuje dobowych przepływów kolejnych lat.",
            "\n  Jeśli te elementy mają się pojawić, zgłoś brak danych opiekunowi bazy.",
            call. = FALSE)
  }

  poboczne <- setdiff(stacja_info$kody_stanowisk, stacja_info$ujscie)
  bez_wielolecia <- poboczne[!poboczne %in% widoki$h1_dane_wieloletnie_vw$stanowisko]
  if (length(bez_wielolecia) > 0) {
    warning("Stanowisko ", paste(bez_wielolecia, collapse = ", "),
            " nie ma danych wieloletnich - na rycinach 1, 2 i 3 zabraknie dla niego",
            " linii progowych i wstęg wieloletnich.", call. = FALSE)
  }

  invisible(NULL)
}

# Stacja bez żadnych danych przepływu na stanowisku odniesienia - ani zagregowanych, ani
# dobowych - np. nowo dopisana do słownika, zanim baza dostała jej pomiary. Z niczego
# nie da się złożyć raportu, a zmiana roku w parametrach nic tu nie da, więc komunikat
# kieruje do opiekuna bazy, a nie do parametry.xlsx.
sprawdz_dane_stacji = function(widoki, stacja_info) {
  agg <- widok_z_listy(widoki, "h1_dane_agg_vw")
  dobowe <- widok_z_listy(widoki, "h1_dane_dobowe_vw")
  dobowe_wiel <- widok_z_listy(widoki, "h1_dane_dobowe_wiel_q_e_vw")
  ujscie <- stacja_info$ujscie

  ma_cokolwiek <- any(agg$stanowisko == ujscie) ||
                  ma_dane(dobowe$Q_E[dobowe$stanowisko == ujscie]) ||
                  ma_dane(dobowe_wiel$Q_E[trimws(dobowe_wiel$stanowisko) == ujscie])

  if (!ma_cokolwiek) {
    stop("Baza nie zawiera żadnych danych H1 dla stacji ", stacja_info$nazwa,
         " (", stacja_info$kod, "), stanowisko odniesienia ", stacja_info$ujscie, ".",
         "\n  Raportu nie da się przygotować dla żadnego roku - zmiana roku",
         " w parametry/parametry.xlsx nie pomoże.",
         "\n  Sprawdź kod stanowiska w funkcje/slownik_stanowisk.R, a jeśli jest",
         " poprawny, zgłoś brak danych opiekunowi bazy.", call. = FALSE)
  }

  invisible(NULL)
}

# Rok analizowany w danych rocznych, miesięcznych i dobowych. Baza pomija lata
# i miesiące zakwestionowane, więc roku analizowanego może brakować w części widoków.
# Raport i tak powstaje - tabele i ryciny pomijają to, czego nie ma - ale użytkownik
# musi wiedzieć, których elementów zabraknie i skąd to wynika, dlatego ostrzegamy,
# wymieniając je wprost. Komunikat podaje też lata dostępne w danych rocznych, gdyby
# raport miał jednak dotyczyć innego roku.
sprawdz_rok_analizowany = function(widoki, stacja_info, analizowany_rok) {
  agg <- widok_z_listy(widoki, "h1_dane_agg_vw")
  agg_ujscie <- agg[agg$stanowisko == stacja_info$ujscie, , drop = FALSE]
  lata_roczne <- as.integer(agg_ujscie$rok_hydro[agg_ujscie$okres_typ == "RH"])
  lata_miesieczne <- as.integer(agg_ujscie$rok_hydro[agg_ujscie$okres_typ == "M"])

  dobowe <- widok_z_listy(widoki, "h1_dane_dobowe_vw")
  dobowe <- dobowe[dobowe$stanowisko == stacja_info$ujscie, , drop = FALSE]
  lata_dobowe <- rok_hydrologiczny(dobowe$data_pomiar[!is.na(dobowe$Q_E)])

  braki <- character(0)
  if (!analizowany_rok %in% lata_roczne) {
    braki <- c(braki, paste0(
      "danych rocznych (h1_dane_agg_vw) - w tabeli 1 zabraknie charakterystyk I stopnia,",
      " w tabeli 2 wiersza roku, a tabela 3, tabele 1 i 2 aneksu oraz rycina 7",
      " nie obejmą tego roku"))
  }
  if (!analizowany_rok %in% lata_miesieczne) {
    braki <- c(braki, paste0(
      "danych miesięcznych (h1_dane_agg_vw) - tabela 2 i tabela 3 aneksu zostaną",
      " pominięte, ryciny 8 i 10 nie powstaną, a ryciny 4, 9 i 11 nie obejmą tego roku"))
  } else {
    brakujace_miesiace <- setdiff(miesiace_hydro,
      nr_miesiaca(jako_miesiac(agg_ujscie$miesiac[agg_ujscie$okres_typ == "M" &
                                                  agg_ujscie$rok_hydro == analizowany_rok])))
    if (length(brakujace_miesiace) > 0) {
      braki <- c(braki, paste0(
        "danych miesięcznych za miesiące: ",
        paste(miesiac_rzymski(brakujace_miesiace), collapse = ", "),
        " - tabele i ryciny miesięczne pominą te miesiące, a wartości półroczy,",
        " do których należą, pozostaną puste"))
    }
  }
  if (!analizowany_rok %in% lata_dobowe) {
    braki <- c(braki, paste0(
      "danych dobowych (h1_dane_dobowe_vw) - ryciny 2 i 3 nie powstaną"))
  }

  if (length(braki) > 0) {
    warning("Baza nie zawiera za rok hydrologiczny ", analizowany_rok, " (stacja ",
            stacja_info$kod, ", stanowisko ", stacja_info$ujscie, "):\n  - ",
            paste(braki, collapse = ";\n  - "), ".",
            "\n  Raport powstanie bez tych elementów. Dane roczne są dostępne dla lat: ",
            zakres_lat(lata_roczne), ".", call. = FALSE)
  }

  invisible(NULL)
}

# Rok krótszy niż komplet dni nie przerywa pracy - raport ma sens, ale odbiorca musi
# wiedzieć, że seria jest niepełna. Liczbę dni liczymy z kalendarza, więc rok z lutym
# przestępnym ma poprawnie 366 dni.
sprawdz_kompletnosc_roku = function(widoki, stacja_info, analizowany_rok) {
  poczatek <- as.Date(paste0(analizowany_rok - 1, "-11-01"))
  koniec <- as.Date(paste0(analizowany_rok, "-10-31"))
  dni_w_roku <- as.integer(koniec - poczatek) + 1L

  dobowe <- widok_z_listy(widoki, "h1_dane_dobowe_vw")
  daty <- as.Date(dobowe$data_pomiar)
  w_roku <- !is.na(daty) & daty >= poczatek & daty <= koniec

  niepelne <- character(0)
  for (stanowisko in stacja_info$kody_stanowisk) {
    dni <- sum(w_roku & dobowe$stanowisko == stanowisko)
    # Rok zupełnie bez dni dobowych na odniesieniu zgłasza już sprawdz_rok_analizowany.
    if (dni == 0 && stanowisko == stacja_info$ujscie) next
    if (dni < dni_w_roku) {
      niepelne <- c(niepelne, paste0(stanowisko, ": ", dni, " z ", dni_w_roku, " dni"))
    }
  }

  if (length(niepelne) > 0) {
    warning("Rok hydrologiczny ", analizowany_rok, " jest niepełny (",
            paste(niepelne, collapse = "; "), ").",
            "\n  Ryciny 2 i 3 oraz tabele miesięczne pokażą tylko dni obecne w bazie.",
            call. = FALSE)
  }

  invisible(NULL)
}

################################################################################
# PARAMETRY WYPROWADZONE Z DANYCH
################################################################################

# Zakresy wielolecia bierzemy z bazy, a nie z parametrów - to baza rozstrzyga, które
# lata weszły do charakterystyk. Przepływ i opad mają własne wielolecia, bo rok
# zakwestionowany dla jednego z nich nie musi być zakwestionowany dla drugiego.
# Lata analizy to lata, dla których stanowisko odniesienia ma JAKIEKOLWIEK dane - roczne,
# miesięczne albo dobowe - do roku analizowanego włącznie, i zawsze sam rok analizowany.
# Wyznaczają zakres osi lat na rycinach. Baza pomija lata zakwestionowane niezależnie
# w każdym widoku, więc zakres wzięty z jednego z nich ucinałby lata obecne w innych:
# rok bez wiersza rocznego, ale z dobowymi przepływami, zniknąłby z ryciny 1. Rok bez
# danych w którymś widoku zostaje na osi pustym miejscem.
parametry_wielolecia = function(widoki, stacja_info, analizowany_rok) {
  wieloletnie <- widok_z_listy(widoki, "h1_dane_wieloletnie_vw")
  wiersz <- wieloletnie[wieloletnie$stanowisko == stacja_info$ujscie, , drop = FALSE][1, ]

  agg <- widok_z_listy(widoki, "h1_dane_agg_vw")
  dobowe <- widok_z_listy(widoki, "h1_dane_dobowe_vw")
  dobowe_wiel <- widok_z_listy(widoki, "h1_dane_dobowe_wiel_q_e_vw")
  ujscie <- stacja_info$ujscie

  lata <- c(
    as.integer(agg$rok_hydro[agg$stanowisko == ujscie]),
    rok_hydrologiczny(dobowe$data_pomiar[dobowe$stanowisko == ujscie & !is.na(dobowe$Q_E)]),
    as.integer(dobowe_wiel$rok_hydro[trimws(dobowe_wiel$stanowisko) == ujscie &
                                     !is.na(dobowe_wiel$Q_E)]),
    analizowany_rok)
  lata_analizy <- sort(unique(lata[!is.na(lata) & lata <= analizowany_rok]))

  list(
    wielolecie_Q     = as.character(wiersz$wielolecie_Q_E),
    wielolecie_Q_lat = as.integer(wiersz$ile_lat),
    wielolecie_opad  = as.character(wiersz$wielolecie_O_RR_T),
    lata_analizy     = lata_analizy
  )
}

################################################################################
# ZAPIS DANYCH
################################################################################

# Zapis widoków i parametrów do dane/dane.RData. Lista obiektów powstaje z tego, co
# skrypt pobierania faktycznie przekazał, więc dołożenie widoku albo parametru
# wystarczy zrobić w skrypty/pobieranie_danych.R.
zapisz_dane_h1 = function(widoki, parametry, sciezka = "dane/dane.RData") {
  srodowisko <- list2env(c(widoki, parametry), envir = new.env(parent = emptyenv()))
  save(list = ls(srodowisko), envir = srodowisko, file = sciezka)
  invisible(sciezka)
}

################################################################################
# MIESIĄCE ROKU HYDROLOGICZNEGO
################################################################################

# Kolejność miesięcy w roku hydrologicznym: od listopada do października. Wyznacza
# poziomy faktora miesiac, więc miesiące na osiach i w tabelach zawsze stoją
# chronologicznie, a nie kalendarzowo.
miesiace_hydro = c(11, 12, 1:10)

# Miesiąc jest w danych faktorem o poziomach miesiace_hydro, więc KOD POZIOMU NIE
# JEST NUMEREM MIESIĄCA - as.integer() na takim faktorze zwróciłby 1 dla listopada.
# Poniższe dwie funkcje są jedynym poprawnym sposobem odczytania numeru miesiąca
# i jego zapisu rzymskiego.
nr_miesiaca = function(x) as.integer(as.character(x))
miesiac_rzymski = function(x) as.character(as.roman(nr_miesiaca(x)))

# Zamienia miesiąc podany w dowolnej postaci (liczba, "11", "01", "XI") na faktor
# o poziomach roku hydrologicznego. Widoki podają miesiąc dwojako: zagregowane
# arabsko z wiodącym zerem, dobowe rzymsko - tutaj sprowadzamy je do jednej postaci.
jako_miesiac = function(x) {
  x <- trimws(as.character(x))
  rzymskie <- grepl("^[IVX]+$", x)
  numer <- rep(NA_integer_, length(x))
  numer[rzymskie] <- as.integer(as.roman(x[rzymskie]))
  numer[!rzymskie] <- suppressWarnings(as.integer(x[!rzymskie]))
  factor(numer, levels = miesiace_hydro)
}

# Półrocza roku hydrologicznego: zimowe XI-IV, letnie V-X. Wiersze podsumowań
# w tabeli 2.
polrocze_zimowe = c(11, 12, 1, 2, 3, 4)
polrocze_letnie = c(5, 6, 7, 8, 9, 10)

################################################################################
# KATEGORIE PRZEPŁYWU
################################################################################

# Sześć kategorii ZMŚP w kolejności od najwyższych przepływów do najniższych.
# Nazwy wyznaczają zarazem kolejność poziomów faktora i etykiety legend.
# Paleta jest paletą raportu IMGW rozszerzoną o jaśniejszy błękit dla kategorii,
# której IMGW nie wyróżnia (wezbranie małe mieści się tam w przepływach normalnych).
kolory_kategorii = c(
  "wezbranie wielkie" = "#08306b",
  "wezbranie zwykłe"  = "#2171b5",
  "wezbranie małe"    = "#6baed6",
  "okres normalny"    = "#ABABAB",
  "niżówka płytka"    = "#de2d26",
  "niżówka głęboka"   = "#a50f15")

# Skróty na ryciny - sześć pełnych nazw nie mieści się w legendzie poziomej.
# Rozwinięcie skrótów podaje podpis ryciny.
skroty_kategorii = c(
  "wezbranie wielkie" = "WW",
  "wezbranie zwykłe"  = "WZ",
  "wezbranie małe"    = "WM",
  "okres normalny"    = "N",
  "niżówka płytka"    = "NP",
  "niżówka głęboka"   = "NG")

# Nazwa kategorii wraz ze skrótem - postać używana w tabelach. Skrót przy pełnej
# nazwie wiąże tabelę z legendami rycin, na których stoi sam skrót.
etykiety_kategorii_ze_skrotem = setNames(
  paste0(names(kolory_kategorii), " (", unname(skroty_kategorii[names(kolory_kategorii)]), ")"),
  names(kolory_kategorii))

# Nazwy kolumn w widoku kategorii (bez polskich znaków) i odpowiadające im nazwy
# raportowe. Wektor służy zarazem do wskazania, które kolumny widoku niosą liczbę dni.
kolumny_kategorii = c(
  "wezbranie wielkie" = "wezbranie wielkie",
  "wezbranie zwykle"  = "wezbranie zwykłe",
  "wezbranie male"    = "wezbranie małe",
  "okres normalny"    = "okres normalny",
  "nizowka plytka"    = "niżówka płytka",
  "nizowka gleboka"   = "niżówka głęboka")

# Kolumny wartości granicznych i kategoria, której DOLNĄ granicę wyznaczają.
# Rysujemy je wszystkie - komplet granic wezbrań i niżówek. Granicy przepływu
# średniego (SQ) świadomie nie dokładamy: na rycinach mają stać wyłącznie granice
# kategorii, a SQ żadnej z nich nie wyznacza.
kolumny_progow = c(
  "wezbranie wielkie" = "wezbranie wielkie",
  "wezbranie zwykle"  = "wezbranie zwykłe",
  "wezbranie male"    = "wezbranie małe",
  "nizowka plytka"    = "niżówka płytka",
  "nizowka gleboka"   = "niżówka głęboka")

# Granice kategorii wyliczane z charakterystyk 2. stopnia potrafią stanąć w odwrotnej
# kolejności niż kategorie, które rozdzielają. Dzieje się tak, gdy strefy zachodzą na
# siebie: dolna granica wezbrania małego, połowa sumy NWQ i WSQ, leży powyżej granicy
# wezbrania zwykłego wszędzie tam, gdzie WSQ przewyższa NWQ (Parsęta: 0,947 > 0,889).
# Narysowana linia przecinałaby wtedy sąsiednią i sugerowała strefę, której nie ma -
# przedział jest pusty z definicji. Taką linię pomijamy; podpis ryciny wylicza skróty
# z linii faktycznie narysowanych, więc sam się do tego dostosowuje.
# Ta sama kontrola po stronie niżówek: górna granica niżówki płytkiej, połowa sumy
# NSQ i WNQ, może zejść poniżej granicy niżówki głębokiej (SNQ).
linia_widoczna = function(kategoria, wartosc) {
  wartosci <- setNames(as.numeric(wartosc), as.character(kategoria))
  odczyt <- function(nazwa) if (nazwa %in% names(wartosci)) unname(wartosci[[nazwa]]) else NA_real_

  przecina <- function(nizsza, wyzsza) {
    a <- odczyt(nizsza); b <- odczyt(wyzsza)
    !is.na(a) && !is.na(b) && a >= b
  }

  odsiane <- character(0)
  if (przecina("wezbranie małe", "wezbranie zwykłe"))
    odsiane <- c(odsiane, "wezbranie małe")
  if (przecina("niżówka głęboka", "niżówka płytka"))
    odsiane <- c(odsiane, "niżówka płytka")

  !as.character(kategoria) %in% odsiane
}

################################################################################
# OPISY ZMIENNYCH
################################################################################

# Oznaczenia z bazy wraz z opisem słownym i jednostką. Z tego słownika powstają
# nagłówki tabel i bloki objaśnień - i tylko one; opisy osi rycin składa osobno
# etykieta_osi(). Rozejście się nazw jest zamierzone: w podpisach rycin i na osiach
# wielkość Q_E nazywa się "natężenie przepływu", w tabelach i objaśnieniach zostaje
# krótsze "przepływ".
opisy_zmiennych = c(
  "Q_E"       = "przepływ",
  "q"         = "odpływ jednostkowy",
  "RR_T"      = "opad atmosferyczny",
  "O"         = "warstwa odpływu",
  "a"         = "współczynnik odpływu",
  "kj"        = "współczynnik miesięczny przepływu",
  "amplituda" = "amplituda względna przepływu",
  "NQ"        = "minimalny przepływ",
  "SQ"        = "średni przepływ",
  "WQ"        = "maksymalny przepływ")

jednostki_zmiennych = c(
  "Q_E"       = "m³·s⁻¹",
  "q"         = "dm³·s⁻¹·km⁻²",
  "RR_T"      = "mm",
  "O"         = "mm",
  "a"         = "-",
  "kj"        = "-",
  "amplituda" = "-",
  "NQ"        = "m³·s⁻¹",
  "SQ"        = "m³·s⁻¹",
  "WQ"        = "m³·s⁻¹")

# Opis osi rycin. Jednostki z indeksami górnymi wymagają wyrażenia, a nie napisu -
# stąd switch zamiast składania tekstu z opisy_zmiennych i jednostki_zmiennych,
# które służą objaśnieniom pod tabelami. Opis jest słowny, zgodnie z konwencją A1:
# oznaczenia z bazy stoją w tabelach, nie na osiach.
#
# NAZWA WIELKOŚCI Q_E
#   Na osiach i w podpisach rycin mówimy "natężenie przepływu", a nie "przepływ" -
#   przepływ jest objętością, natężenie przepływu jej strumieniem, i to ono ma
#   jednostkę m3/s. Ta sama nazwa wchodzi do wszystkich nazw pochodnych:
#   "współczynnik miesięczny natężenia przepływu", "amplituda względna natężenia
#   przepływu". Tabele zostają przy krótszym "przepływie" (patrz opisy_zmiennych
#   i funkcje/tabele.R).
#
# Jednostka zawsze w nawiasie KWADRATOWYM, tak samo jak w nagłówkach tabel i w tekście.
# W wyrażeniu plotmath nawias kwadratowy trzeba złożyć przez group(): sam znak "["
# jest tam operatorem indeksu dolnego i dałby "m3s-1" wpisane w dolny indeks.
# Wielkości bezwymiarowe dostają [-], żeby brak jednostki był świadomym zapisem,
# a nie przeoczeniem.
etykieta_osi = function(symbol) {
  switch(symbol,
    "Q_E"       = expression("Natężenie przepływu" ~ group("[", m^3 %.% s^-1, "]")),
    "q"         = expression("Odpływ jednostkowy" ~ group("[", dm^3 %.% s^-1 %.% km^-2, "]")),
    "RR_T"      = "Opad atmosferyczny [mm]",
    "O"         = "Warstwa odpływu [mm]",
    "a"         = "Współczynnik odpływu [-]",
    "kj"        = "Współczynnik miesięczny natężenia przepływu [-]",
    # Kolumna amplituda w bazie to iloraz (WQ - NQ) / SQ, czyli amplituda WZGLĘDNA -
    # wielkość bezwymiarowa. Nazwa osi musi to oddawać, inaczej sugerowałaby różnicę
    # natężeń przepływu wyrażoną w m3/s.
    "amplituda" = "Amplituda względna natężenia przepływu [-]",
    stop("Nieznany symbol osi: ", symbol))
}

################################################################################
# LICZBY W TEKŚCIE
################################################################################

# Dokładna wartość progu w warunku tabeli 4: bez zaokrąglania, ale i bez ogona zer.
# Zaokrąglenie byłoby tu szkodliwe - przy stacjach o przepływach bliskich zeru progi
# różnią się na czwartym miejscu po przecinku (13ZM: 0,00205 i 0,02585).
liczba_txt = function(x, max_miejsc = 6) {
  if (is.na(x)) return("brak")
  # decimal.mark = "." jest tu konieczne: przebieg ustawia options(OutDec = ","),
  # a wtedy formatC oddaje "0,000000" i obcinanie ogona zer zostawia samą "0,"
  # z wiszącym przecinkiem. Przecinek wstawiamy dopiero na końcu, sami.
  tekst <- formatC(x, format = "f", digits = max_miejsc, decimal.mark = ".")
  tekst <- sub("0+$", "", tekst)
  tekst <- sub("[.]$", "", tekst)
  gsub("[.]", ",", tekst)
}

# Wartość liczbowa jako tekst komórki tabeli, o stałej liczbie miejsc po przecinku.
# Potrzebna tam, gdzie tabela jest siatką napisów, a nie ramką liczb - jak tabela 1,
# w której symbol i wartość stoją w sąsiednich komórkach jednego wiersza.
# round() przed formatowaniem jest tu konieczne: formatC() zaokrągla po swojemu
# i przy połówce w ostatniej cyfrze (NWQ = 0,4175) oddaje inną wartość niż round(),
# z którego korzystają pozostałe tabele i arkusz. Bez tego ta sama liczba miałaby
# w tabeli 1 inną końcówkę niż w aneksie.
liczba_tab = function(x, miejsca = 3) {
  x <- as.numeric(x)
  tekst <- formatC(round(x, miejsca), format = "f", digits = miejsca, decimal.mark = ",")
  tekst[is.na(x)] <- "."
  tekst
}

################################################################################
# KOMPLETNOŚĆ SERII (rycina 11)
################################################################################

# Paleta klas kompletności. Nazwy wyznaczają zarazem etykiety legendy i kolejność klas.
kolory_kompletnosc = c(
  "0%"           = "#7f0000",
  "1-49%"        = "#d7301f",
  "50-89%"       = "#fc8d59",
  "90-99%"       = "#74a9cf",
  "100%"         = "#023858",
  "brak pomiaru" = "#f0f0f0")

# Przedziały prawostronnie domknięte, więc przy całkowitych wartościach kompletności
# wychodzą dokładnie klasy z nazw palety. Osobna klasa dla zera jest konieczna: 0% to
# zarejestrowana seria bez ani jednego pomiaru, a brak wpisu to brak samej serii -
# na mapie muszą się różnić.
klasa_kompletnosci = function(x) {
  klasy <- cut(x, breaks = c(-1, 0, 49, 89, 99, 100),
               labels = head(names(kolory_kompletnosc), -1))
  klasy <- as.character(klasy)
  klasy[is.na(klasy)] <- "brak pomiaru"
  factor(klasy, levels = names(kolory_kompletnosc))
}

################################################################################
# BARWY RYCIN
################################################################################

# Wstęgi i linie ryciny 3 (przepływ według dni roku).
kolory_perc_doy = c(
  "Minimum-Maksimum"  = "#87CEFA",
  "Percentyle: 05-95" = "#75b3d9",
  "Percentyle: 25-75" = "#335572")

# Nazwę pierwszej linii - rok analizowany - podstawia rycina, bo zależy od parametru.
kolory_linii_doy = c(
  "rok analizowany" = "red",
  "Średnia"         = "darkblue",
  "Mediana"         = "#00FFFF")

# Rok analizowany zestawiany z wieloleciem (ryciny 8 i 10). Czerwień oznacza rok
# analizowany na każdej rycinie raportu, granat - tło wielolecia.
kolory_rok_wielolecie = c("rok" = "red", "wielolecie" = "#08306b")

# Liczba dni w kategorii na rycinie 6. Sześć klas po pięć dni, od błękitu przy
# pojedynczych dniach do czerwieni przy miesiącu niemal w całości w jednej kategorii.
# Miesiąc bez ani jednego dnia w kategorii zostaje biały - to brak zjawiska,
# a nie najniższa klasa, więc celowo stoi poza skalą.
kolory_liczby_dni = c(
  "1-5"   = "#3288BD",
  "6-10"  = "#99D594",
  "11-15" = "#E6F598",
  "16-20" = "#FEE08B",
  "21-25" = "#FC8D59",
  "26-31" = "#D53E4F",
  "brak"  = "white")

################################################################################
# PEŁNA LEGENDA
################################################################################

# ggplot2 od wersji 4.0 nie rysuje klucza legendy dla poziomu faktora, którego nie ma
# w danych: zostaje sam podpis i pusty prostokąt tła, co wygląda jak usterka. A takich
# poziomów w H1 jest sporo - kategoria pusta z definicji, klasa kompletności, której
# stacja nigdy nie osiągnęła, klasa liczby dni bez wystąpień.
# Warstwa o zerowej szerokości i wysokości wnosi po jednym wierszu na każdy poziom,
# więc klucze odzyskują barwy, a sama nie rysuje na wykresie niczego.
klucze_legendy = function(dane, kolumna, poziomy) {
  if (nrow(dane) == 0) return(NULL)
  atrapa <- dane[rep(1, length(poziomy)), , drop = FALSE]
  atrapa[[kolumna]] <- factor(poziomy, levels = poziomy)
  ggplot2::geom_tile(data = atrapa, width = 0, height = 0, na.rm = TRUE)
}

################################################################################
# OŚ LAT
################################################################################

# Krok podpisów osi lat dobrany do długości serii: przy 10 latach podpisujemy co rok,
# przy 31 co piąty.
krok_osi_lat = function(n_lat, docelowo = 7) {
  max(1, ceiling(n_lat / docelowo))
}

# Lata, w których seria ma choć jedną wartość - podstawa osi lat konkretnej ryciny.
# Każda rycina wieloletnia dostaje zakres z WŁASNYCH danych: widoki bazy pomijają lata
# zakwestionowane niezależnie od siebie, więc wspólna oś rozciągnięta do najdłuższej
# serii zostawiałaby na rycinach z krótszymi seriami długie puste odcinki. Kilka serii
# (np. opad i odpływ) - rok wchodzi, gdy którakolwiek z nich ma w nim wartość.
lata_z_danymi = function(rok, ...) {
  serie <- list(...)
  obecne <- if (length(serie) == 0) rep(TRUE, length(rok))
            else Reduce(`|`, lapply(serie, function(x) !is.na(x)))
  lata <- as.integer(rok[obecne])
  sort(unique(lata[!is.na(lata)]))
}

# Komplet ustawień osi lat: podziałka przy KAŻDYM roku, podpisy przerzedzone.
# Rok bez danych ma wtedy własną kreskę, więc luka w serii jest widoczna także tam,
# gdzie nie ma podpisu. Jawne granice utrzymują stały margines - skala ciągła
# rozszerzyłaby zakres o szerokość skrajnych słupków.
#
# Pusty wektor lat (min() dałby Inf, a Inf:-Inf błąd) zastępuje rok analizowany, jeśli
# jest w środowisku - rycina bez danych i tak zostanie zastąpiona przez NULL.
os_lat = function(lata, docelowo = 15) {
  lata <- as.integer(lata[!is.na(lata)])
  if (length(lata) == 0) {
    lata <- if (exists("analizowany_rok")) as.integer(analizowany_rok) else 0L
  }
  lata_os <- min(lata):max(lata)
  krok <- krok_osi_lat(length(lata_os), docelowo = docelowo)
  list(breaks = lata_os,
       labels = ifelse((seq_along(lata_os) - 1) %% krok == 0, as.character(lata_os), ""),
       limits = range(lata_os) + c(-0.6, 0.6))
}

################################################################################
# SERIE BEZ DANYCH
################################################################################

# Czy jest cokolwiek do narysowania. Rycina bez danych zostaje zastąpiona przez NULL,
# a dokument pomija jej blok.
ma_dane = function(...) {
  wartosci <- unlist(list(...), use.names = FALSE)
  length(wartosci) > 0 && any(!is.na(wartosci))
}

# Największa wartość serii, odporna na komplet braków. max() na samych NA zwraca -Inf,
# a to wywraca każde miejsce, w którym z zakresu powstaje ciąg podziałek. Wartość
# zastępcza służy wyłącznie do bezpiecznego dokończenia budowy obiektu - rycina bez
# danych i tak zostanie zastąpiona przez NULL.
max_lub = function(x, zastepczy = 1) if (any(is.finite(x))) max(x, na.rm = TRUE) else zastepczy
