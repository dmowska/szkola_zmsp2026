################################################################################
# OPIS SKRYPTU
################################################################################
# funkcje/formatowanie_tabel.R - składanie tabel dokumentu z opisów i danych
#
# Ustawia domyślne parametry flextable obowiązujące w całym raporcie i buduje gotowe
# tabele: dobiera kolumny, wstawia nagłówki i wiersz jednostek, zaokrągla liczby,
# pogrubia wiersze podsumowań i rozkłada kolumny na szerokość kolumny tekstu.
# Wywołują je tworzenie_raportu.qmd i tworzenie_aneksu.qmd, raz na każdą tabelę.
#
# Uwagi do kodu:
#
# DWIE GAŁĘZIE
#   Tabela o zwykłym układzie - kolumny z nagłówkiem - powstaje w tabela_flextable().
#   Tabela z polem uklad = "blok" (tabela 1) trafia stamtąd do tabela_blokowej(),
#   bo nie ma nagłówka kolumn ani jednorodnych typów w kolumnach.
#
# ZAOKRĄGLENIE A FORMATOWANIE
#   To dwie różne rzeczy: round() ustala wartość, colformat_double() liczbę miejsc
#   na wydruku. Obie są potrzebne, żeby 0,30 zostało wydrukowane jako 0,30,
#   a kolumna pozostała wyrównana do przecinka.
#
# SKĄD SIĘ BIORĄ DANE TABELI
#   Opis tabeli podaje nazwę obiektu z danymi, a nie same dane - obiekt jest
#   odszukiwany przez get() w środowisku wywołania. Tabelę można więc zbudować
#   dopiero wtedy, gdy obiekty tab_*_dane są już wczytane.
#
# BRAKI DANYCH
#   Domyślne ustawienia wpisują w miejsce braku kropkę, więc kolumna pusta w całości
#   (np. percentyle, których baza nie policzyła) daje kolumnę kropek, a nie dziurę
#   w tabeli.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - opis tabeli z funkcje/tabele.R: pola obiekt, uklad, etykiety, jednostki,
#   dokladnosc, wyroznione i wiersze_calkowite
# - obiekt z danymi tabeli (tab_*_dane z przetwarzanie_danych.R), wskazany nazwą
#   w polu obiekt i odszukiwany w środowisku wywołania
# - kolumny_tabeli, zaokraglij_tabele i wartosc_opisu z funkcje/tabele.R
# - table_theme z funkcje/table_theme.R
################################################################################
# WYNIK
################################################################################
# - SZEROKOSC_TEKSTU: szerokość kolumny tekstu w calach, wspólna miara dla tabel
# - domyślne ustawienia flextable obowiązujące w całym raporcie: wielkość pisma,
#   marginesy komórek, przecinek dziesiętny i kropka w miejsce braku danych
# - tabela_flextable: gotowa tabela zbudowana z opisu w funkcje/tabele.R
# - dopasuj_szerokosc: rozłożenie kolumn na szerokość kolumny tekstu
# - tabela_blokowa: gałąź dla tabeli o układzie blokowym (tabela 1)
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - flextable
################################################################################

# Szerokość kolumny tekstu w szablonie funkcje/styl_dokument.docx: strona 8,5 cala
# pomniejszona o marginesy po 0,98 cala. Do niej skalujemy każdą tabelę.
SZEROKOSC_TEKSTU <- 6.5

# Domyślne ustawienia flextable
set_flextable_defaults(
  font.size = 10,
  padding = 2,
  theme_fun = NULL,
  decimal.mark = ",",
  big.mark = " ",
  na_str = ".",
  nan_str = "."
)


################################################################################
# BUDOWA TABELI RAPORTU
################################################################################

# Składa gotową tabelę na podstawie opisu z funkcje/tabele.R. Ten sam opis - kolumny,
# etykiety, jednostki, zaokrąglenia i wiersze wyróżnione - obsługuje arkusz
# wyniki/h1_tabele.xlsx, więc tabela w dokumencie i w arkuszu są zgodne.
#
# Uwagi do kodu:
# Wiersz jednostek powstaje tylko wtedy, gdy opis podaje choć jedną jednostkę.
# Jednostki powtarzające się w sąsiednich kolumnach (trzy kolumny odpływu
# jednostkowego) scala merge_h, więc ten sam napis stoi raz nad kilkoma kolumnami.
# Pierwsza kolumna - z etykietą wiersza - jest pogrubiona i wyrównana do lewej,
# pozostałe zostają wyśrodkowane przez table_theme().
# Podpis tabeli NIE jest tu ustawiany - w raporcie stoi nad tabelą jako osobny akapit
# w stylu "Podpis tabeli".
# Tabela o układzie blokowym (tabela 1) nie ma nagłówka kolumn ani jednorodnych
# kolumn, więc idzie osobną gałęzią - patrz tabela_blokowa().
tabela_flextable <- function(opis, rozmiar_czcionki = NULL) {
  if (identical(opis$uklad, "blok")) return(tabela_blokowa(opis, rozmiar_czcionki))

  dane <- kolumny_tabeli(get(opis$obiekt), opis)
  dane <- zaokraglij_tabele(dane, opis$dokladnosc)
  n_kol <- ncol(dane)

  ft <- flextable(dane) |>
    set_header_labels(values = as.list(opis$etykiety))

  if (any(nzchar(opis$jednostki))) {
    ft <- ft |>
      add_header_row(values = unname(opis$jednostki),
                     colwidths = rep(1, n_kol), top = FALSE) |>
      merge_h(part = "header")
  }

  ft <- table_theme(ft)

  # Liczba miejsc po przecinku kolumna po kolumnie, zgodnie z opisem tabeli.
  for (kolumna in names(dane)) {
    if (!is.numeric(dane[[kolumna]])) next
    miejsca <- if (length(opis$dokladnosc) == 1 && is.null(names(opis$dokladnosc)))
                 opis$dokladnosc
               else if (kolumna %in% names(opis$dokladnosc)) opis$dokladnosc[[kolumna]]
               else 2
    ft <- colformat_double(ft, j = kolumna, digits = miejsca)
  }

  # Wiersze, których wartości są liczbami całkowitymi mimo dziesiętnej kolumny -
  # jak wiersz n z liczbą lat w tabeli 3 - dostają zero miejsc po przecinku,
  # niezależnie od zaokrąglenia kolumny.
  calkowite <- wartosc_opisu(opis$wiersze_calkowite, dane)
  if (length(calkowite) > 0) {
    for (kolumna in names(dane)) {
      if (!is.numeric(dane[[kolumna]])) next
      ft <- colformat_double(ft, i = calkowite, j = kolumna, digits = 0)
    }
  }

  ft <- ft |>
    bold(part = "header") |>
    bold(j = 1, part = "body") |>
    align(j = 1, align = "left", part = "body")

  # Wiersze podsumowań (półrocza, rok, wielolecie) pogrubione.
  wyroznione <- wartosc_opisu(opis$wyroznione, dane)
  if (!is.null(wyroznione)) ft <- bold(ft, i = wyroznione, part = "body")

  # Rozmiar pisma musi być ustawiony PRZED liczeniem szerokości: to od niego zależy,
  # ile miejsca zajmie treść komórki.
  if (!is.null(rozmiar_czcionki)) ft <- fontsize(ft, size = rozmiar_czcionki, part = "all")

  dopasuj_szerokosc(ft)
}

################################################################################
# SZEROKOŚĆ KOLUMN
################################################################################

# Rozkłada kolumny na całą szerokość kolumny tekstu, zachowując proporcje wynikające
# z treści, i zapisuje wynik jako układ STAŁY.
#
# Uwagi do kodu:
# Szerokości kolumn są zapisywane jawnie, a układ ustawiony na "fixed": dokument
# niesie wtedy pełną siatkę kolumn, a komórka scalona w wierszu jednostek ma szerokość
# równą sumie kolumn, które obejmuje, i stoi dokładnie nad nimi.
dopasuj_szerokosc <- function(ft, szerokosc = SZEROKOSC_TEKSTU) {
  ft <- autofit(ft)
  szerokosci <- dim(ft)$widths
  ft <- width(ft, j = seq_along(szerokosci),
              width = szerokosci * szerokosc / sum(szerokosci))
  set_table_properties(ft, layout = "fixed")
}

################################################################################
# TABELA O UKŁADZIE BLOKOWYM
################################################################################

# Tabela 1 z szablonu ZMŚP nie jest ramką kolumn z nagłówkiem, tylko siatką sześciu
# kolumn, w której układ każdego wiersza wynika z jego roli:
#
#   Przepływy charakterystyczne I stopnia (2025)          <- scalone na całą szerokość
#        NQ    |      SQ      |      WQ                   <- scalone parami
#      0,310   |    0,461     |    1,273                  <- scalone parami
#   Przepływy charakterystyczne II stopnia (1995-2025)    <- scalone na całą szerokość
#    minimalne |   średnie    |  maksymalne               <- scalone parami
#   NNQ | 0,032 | SNQ | 0,232 | WNQ | 0,418               <- symbol i wartość osobno
#
# Rolę wiersza niesie kolumna typ, dokładana przy budowie danych: "sekcja",
# "stanowisko", "naglowek" albo "wartosc". Ten sam kod składa więc blok dla jednego
# stanowiska i dla stacji różnicowej, czyli takiej z dwoma stanowiskami, gdzie bloki
# stoją jeden pod drugim, każdy poprzedzony wierszem z kodem stanowiska.
#
# Uwagi do kodu:
# Wartości są tu NAPISAMI, a nie liczbami - w jednym wierszu sąsiadują symbol i liczba,
# więc kolumna nie ma jednolitego typu. Zaokrąglenie i przecinek dziesiętny nadaje im
# liczba_tab() przy budowie danych, a nie colformat_double() tutaj.
# Scalanie idzie wiersz po wierszu, bo w wierszu siatki sąsiadują komórki o różnej
# treści, a merge_h łączy tylko jednakowe.
# Sześć kolumn ma jednakową szerokość, więc pary scalone - NQ, SQ i WQ - wychodzą
# równe, mimo że kolumny symboli niosą krótszy tekst niż kolumny wartości.
tabela_blokowa <- function(opis, rozmiar_czcionki = NULL, szerokosc_calkowita = SZEROKOSC_TEKSTU) {
  dane <- get(opis$obiekt)
  kolumny <- paste0("c", seq_len(6))
  siatka <- dane[, kolumny, drop = FALSE]

  ft <- flextable(siatka) |>
    delete_part(part = "header")

  ft <- table_theme(ft)

  for (i in seq_len(nrow(dane))) {
    ft <- switch(dane$typ[i],
      "sekcja"     = merge_at(ft, i = i, j = 1:6, part = "body"),
      "stanowisko" = merge_at(ft, i = i, j = 1:6, part = "body"),
      "naglowek"   = ,
      "wartosc"    = merge_at(merge_at(merge_at(ft, i = i, j = 1:2, part = "body"),
                                       i = i, j = 3:4, part = "body"),
                              i = i, j = 5:6, part = "body"),
      ft)
  }

  # Pogrubione zostają wiersze opisujące układ - nagłówki sekcji, kod stanowiska
  # i podpisy kolumn. Same wartości pozostają zwykłe, jak w szablonie.
  wyroznione <- which(dane$typ %in% c("sekcja", "stanowisko", "naglowek"))
  if (length(wyroznione) > 0) ft <- bold(ft, i = wyroznione, part = "body")

  if (!is.null(rozmiar_czcionki)) ft <- fontsize(ft, size = rozmiar_czcionki, part = "all")

  ft <- width(ft, j = seq_len(6), width = szerokosc_calkowita / 6)
  set_table_properties(ft, layout = "fixed")
}
