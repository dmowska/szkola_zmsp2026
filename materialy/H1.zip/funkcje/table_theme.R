################################################################################
# OPIS SKRYPTU
################################################################################
# funkcje/table_theme.R - wspólny wygląd tabel
#
# Definiuje formatowanie nadawane tabelom raportu: przecinek jako separator
# dziesiętny i brak separatora tysięcy, wyśrodkowanie nagłówka i treści, krój
# Times New Roman, pełną siatkę linii oraz zmniejszone marginesy komórek. Wywołują
# go obie gałęzie budowy tabel w funkcje/formatowanie_tabel.R, więc każda tabela
# raportu i aneksu przechodzi przez ten sam motyw.
#
# Uwagi do kodu:
#
# KOLEJNOŚĆ MA ZNACZENIE
#   Funkcja przyjmuje obiekt flextable i zwraca go ze zmienionym formatowaniem.
#   Ustawienia nadaje w chwili wywołania, więc to, co formatowanie_tabel.R robi
#   z tabelą później - liczba miejsc po przecinku, pogrubienia, wyrównanie pierwszej
#   kolumny do lewej, rozmiar pisma - jest nadrzędne wobec motywu.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - ft: obiekt flextable przekazany w wywołaniu; plik nie korzysta z żadnych
#   obiektów zewnętrznych
################################################################################
# WYNIK
################################################################################
# - table_theme: funkcja przyjmująca i zwracająca obiekt flextable
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - flextable
################################################################################

table_theme = function(ft) {
  ft |>
    colformat_num(big.mark = "", decimal.mark = ",",na_str = "") |> # przecinek jako znak dziesiętny
    align(part = "all", align = "center") |> # wypośrodkowanie nagłówków
    font(fontname = "Times New Roman", part = "all") |>
    # dodanie pionowych i poziomych linii
    border_outer(part = "all") |>
    border_inner_h(part = "all") |>
    border_inner_v(part = "all") |>
    padding(padding.left = 0.5, padding.right = 0.5) # zmniejszenie marginesów
}