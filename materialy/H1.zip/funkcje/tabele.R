################################################################################
# OPIS SKRYPTU
################################################################################
# funkcje/tabele.R - opis dziesięciu tabel raportu i aneksu
#
# Jedno miejsce, w którym stoi wszystko, co o tabeli trzeba wiedzieć poza jej
# danymi: podpis, wykaz i etykiety kolumn, jednostki, zaokrąglenia, wiersze
# wyróżnione i objaśnienia. Korzystają z niego zarówno zapis_tabel.R (arkusz
# wyniki/h1_tabele.xlsx), jak i tworzenie_raportu.qmd oraz tworzenie_aneksu.qmd.
#
# Uwagi do kodu:
#
# POLA OPISU TABELI
#   Każda pozycja list TABELE_RAPORT i TABELE_ANEKS to lista pól:
#     numer             - numer tabeli widoczny w dokumencie,
#     obiekt            - nazwa obiektu z danymi tabeli (tab_*_dane),
#     arkusz            - nazwa karty w wyniki/h1_tabele.xlsx,
#     uklad             - "blok" dla tabeli 1; brak pola oznacza zwykły układ kolumn,
#     podpis            - funkcja bez argumentów zwracająca podpis,
#     etykiety          - nazwy kolumn danych wraz z nagłówkami tabeli,
#     jednostki         - drugi wiersz nagłówka; pusty napis zostawia pustą komórkę,
#     dokladnosc        - liczba miejsc po przecinku: jedna dla całej tabeli albo
#                         wektor nazwany kolumnami,
#     wyroznione        - wiersze pogrubione: wektor albo funkcja danych,
#     wiersze_calkowite - wiersze pokazywane bez miejsc po przecinku,
#     objasnienia       - tekst pod tabelą: wektor albo funkcja bez argumentów.
#
# ETYKIETY WYZNACZAJĄ KOLUMNY
#   Wykaz kolumn bierze się z NAZW wektora etykiet, więc kolumna pomocnicza (jak
#   znacznik pustej kategorii w tabeli 4) nie trafia ani do arkusza, ani do raportu.
#   Nazwy wyznaczają zarazem KOLEJNOŚĆ kolumn, więc zmiana układu tabeli to zmiana
#   kolejności w wektorze etykiet i nigdzie indziej.
#
# PODPISY I OBJAŚNIENIA SĄ FUNKCJAMI
#   Zależą od parametrów przebiegu (stacja, profil, rok, wielolecie) i od danych,
#   więc są funkcjami bez argumentów, wywoływanymi dopiero w środowisku, w którym
#   te parametry i obiekty tab_*_dane już są. Podpis nie kończy się kropką, zgodnie
#   z szablonem ZMŚP.
#
# NAGŁÓWKI OPISOWE, W ANEKSIE SKRÓTY
#   W raporcie nagłówki nazywają wielkość wprost ("Opad atmosferyczny", nie "RR_T"),
#   więc objaśnienia pod tabelą niosą samą treść merytoryczną. Aneks jest
#   zestawieniem statystycznym i zostają w nim skróty (sd, cv, p05, IQR) rozwinięte
#   w bloku objaśnień.
#
# TABELA 1
#   Ma układ blokowy (uklad = "blok"): nie jest ramką kolumn z nagłówkiem, lecz
#   siatką napisów 6 x N, w której symbol i wartość stoją w sąsiednich komórkach.
#   Obsługują ją osobne gałęzie w formatowanie_tabel.R i zapis_tabel.R.
#
# NOWA TABELA
#   Dopisanie pozycji do TABELE_RAPORT albo TABELE_ANEKS wystarczy, żeby tabela
#   trafiła do arkusza - zapis_tabel.R przechodzi obie listy po kolei. W dokumencie
#   trzeba ją jeszcze wywołać w tworzenie_raportu.qmd albo tworzenie_aneksu.qmd.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - funkcje/funkcje_pomocnicze.R: etykiety_kategorii_ze_skrotem i kolory_kategorii
#   (nazwy kategorii przepływu) oraz czlon_wielolecia() używane w podpisach
# - parametry przebiegu widoczne w środowisku wywołania podpisów i objaśnień:
#   opis_miejsca, opis_miejsc, analizowany_rok, opis_lat_roczne, opis_lat_kategorie,
#   opis_wielolecia_Q,
#   wielolecie_Q, wielolecie_opad, ma_wielolecie oraz obiekt tab_4_dane
################################################################################
# WYNIK
################################################################################
# - J_PRZEPLYW, J_ODPLYW_J, J_MM, J_BEZ: jednostki powtarzające się w tabelach
# - O_CHARAKTERYSTYKI_1ST, O_PERCENTYLE, O_AMPLITUDA, O_KATEGORIE: objaśnienia
#   powtarzające się pod kilkoma tabelami
# - objasnienie_wielolecia: zdanie o wierszu wielolecia w tabelach 2 i 3
# - ETYKIETY_PARAMETRY, JEDNOSTKI_PARAMETRY, DOKLADNOSC_PARAMETRY: opis kolumn
#   wspólny dla tabel 2 i 3
# - ETYKIETY_KATEGORII, JEDNOSTKI_KATEGORII, DOKLADNOSC_KATEGORII: opis kolumn
#   wspólny dla tabel udziałów kategorii przepływu
# - TABELE_RAPORT: opis czterech tabel raportu
# - TABELE_ANEKS: opis sześciu tabel aneksu
# - kolumny_tabeli: wybór i kolejność kolumn do pokazania
# - zaokraglij_tabele: zaokrąglenie kolumn zgodnie z opisem tabeli
# - wartosc_opisu: odczyt pola opisu, które bywa wartością albo funkcją
# - objasnienia_txt: objaśnienia pod tabelą złożone w jeden akapit
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - brak (plik nie wywołuje funkcji spoza R base)
################################################################################

# Jednostki powtarzające się w wielu tabelach. Indeksy górne są zapisane znakami
# Unicode, a nie formatowaniem komórki - ten sam napis trafia bez zmian do dokumentu
# Worda, do arkusza i do komunikatów.
J_PRZEPLYW <- "[m³·s⁻¹]"
J_ODPLYW_J <- "[dm³·s⁻¹·km⁻²]"
J_MM <- "[mm]"
J_BEZ <- "[-]"

# Objaśnienia powtarzające się pod kilkoma tabelami. Rozdzielnik to półpauza,
# zgodnie z szablonem; dywiz zostaje wyłącznie w zakresach (XI-IV, 1995-2025).
O_CHARAKTERYSTYKI_1ST <- paste(
  "NQ – minimalny przepływ, SQ – średni przepływ, WQ – maksymalny przepływ",
  "w okresie.")

O_PERCENTYLE <- paste(
  "sd – odchylenie standardowe, cv – współczynnik zmienności,",
  "p05, p25, p50, p75, p95 – percentyle (p50 to mediana),",
  "IQR – rozstęp międzykwartylowy, czyli różnica p75 i p25.")

O_AMPLITUDA <- paste(
  "amplituda – amplituda względna przepływu, obliczona jako różnica przepływu",
  "maksymalnego i minimalnego podzielona przez przepływ średni w okresie.")

O_KATEGORIE <- paste(
  "Udział dni w okresie, obliczony przez liczbę dni w tym okresie.",
  "Kategorie wyznaczają wartości graniczne z wielolecia – patrz tabela progów",
  "w raporcie.")

# Wiersz wielolecia w tabelach 2 i 3 miesza dwa wielolecia: opad, warstwa odpływu
# i współczynnik odpływu pochodzą z wielolecia opadowego, a odpływ jednostkowy
# z wielolecia przepływowego. Zakresy bywają różne, bo rok zakwestionowany dla
# jednej z serii nie musi być zakwestionowany dla drugiej. Podpis tabeli podaje
# jeden zakres, więc oba wymienia to objaśnienie - i tylko wtedy, gdy się różnią.
objasnienie_wielolecia <- function() {
  # Stacja bez agregatów wieloletnich nie ma wiersza wielolecia, więc objaśnienie
  # zostaje puste i odpada przy składaniu akapitu.
  if (!ma_wielolecie) {
    ""
  } else if (!identical(wielolecie_opad, wielolecie_Q)) {
    paste0("Wiersz wielolecia: opad atmosferyczny, warstwa odpływu i współczynnik",
           " odpływu obliczone dla wielolecia ", wielolecie_opad,
           ", odpływ jednostkowy – dla wielolecia ", opis_wielolecia_Q, ".")
  } else {
    paste0("Wiersz wielolecia podaje średnie roczne dla lat ", opis_wielolecia_Q, ".")
  }
}

# Etykiety, jednostki i zaokrąglenia tabel 2 i 3. Kolejność wektora jest kolejnością
# kolumn: opad, warstwa odpływu i współczynnik odpływu, a dalej odpływy jednostkowe
# w porządku średni - maksymalny - minimalny. Oba układy z szablonu ZMŚP.
ETYKIETY_PARAMETRY <- c(okres = "Okres",
                        RR_T  = "Opad atmosferyczny",
                        O     = "Warstwa odpływu",
                        a     = "Współczynnik odpływu",
                        q_avg = "Średni miesięczny odpływ jednostkowy",
                        q_max = "Maksymalny dobowy odpływ jednostkowy",
                        q_min = "Minimalny dobowy odpływ jednostkowy")
JEDNOSTKI_PARAMETRY <- c(okres = "", RR_T = J_MM, O = J_MM, a = J_BEZ,
                         q_avg = J_ODPLYW_J, q_max = J_ODPLYW_J, q_min = J_ODPLYW_J)
DOKLADNOSC_PARAMETRY <- c(RR_T = 1, O = 1, a = 2, q_avg = 2, q_max = 2, q_min = 2)

# Etykiety kategorii przepływu - te same we wszystkich tabelach kategorii. Nazwa
# kategorii stoi wraz ze skrótem, którym posługują się legendy rycin.
ETYKIETY_KATEGORII <- etykiety_kategorii_ze_skrotem
JEDNOSTKI_KATEGORII <- setNames(rep("", length(kolory_kategorii)), names(kolory_kategorii))
DOKLADNOSC_KATEGORII <- setNames(rep(2, length(kolory_kategorii)), names(kolory_kategorii))

################################################################################
# TABELE RAPORTU
################################################################################

TABELE_RAPORT <- list(

  list(
    numer = 1,
    obiekt = "tab_1_dane",
    arkusz = "Tabela 1",
    # Układ blokowy - siatka napisów, nie ramka kolumn. Patrz uwagi na górze pliku.
    uklad = "blok",
    podpis = function() paste0(
      "Charakterystyczne wartości natężenia przepływu ", J_PRZEPLYW, " ",
      opis_miejsc, " w roku hydrologicznym ", analizowany_rok,
      czlon_wielolecia(ma_wielolecie, " oraz wieloleciu ", opis_wielolecia_Q)),
    etykiety = setNames(rep("", 6), paste0("c", 1:6)),
    jednostki = setNames(rep("", 6), paste0("c", 1:6)),
    dokladnosc = 3,
    # Rozwinięcie oznaczeń dwuliterowych dotyczy bloku II stopnia. Stacja bez
    # agregatów wieloletnich ma sam blok I stopnia i to objaśnienie odpada.
    objasnienia = function() c(
      O_CHARAKTERYSTYKI_1ST,
      if (ma_wielolecie)
        paste("Pierwsza litera oznaczeń dwuliterowych mówi, co policzono",
              "z wartości rocznych w wieloleciu (N – minimalna,",
              "S – średnia, W – maksymalna), druga wskazuje charakterystykę",
              "roczną. NNQ to minimalny z przepływów minimalnych,",
              "SSQ – średni z przepływów średnich, czyli przepływ średni",
              "wielolecia, WWQ – maksymalny z przepływów maksymalnych."))
  ),

  list(
    numer = 2,
    obiekt = "tab_2_dane",
    arkusz = "Tabela 2",
    podpis = function() paste0(
      "Miesięczne wysokości warstwy opadu i odpływu ", J_MM,
      ", średnie wartości współczynnika odpływu ", J_BEZ,
      " i odpływu jednostkowego oraz ekstremalne dobowe odpływy jednostkowe ",
      J_ODPLYW_J, " ", opis_miejsca,
      " w roku hydrologicznym ", analizowany_rok),
    etykiety = replace(ETYKIETY_PARAMETRY, "okres", "Miesiąc"),
    jednostki = JEDNOSTKI_PARAMETRY,
    dokladnosc = DOKLADNOSC_PARAMETRY,
    # Wiersze podsumowań: półrocza, rok i wielolecie. Rozpoznawane po etykiecie,
    # bo stacja bez agregatów wieloletnich nie ma wiersza wielolecia i liczba
    # wierszy podsumowań na dole tabeli bywa różna.
    wyroznione = function(dane) which(
      dane[[1]] %in% c("Półrocze zimowe", "Półrocze letnie", "Rok hydrologiczny") |
        startsWith(dane[[1]], "Wielolecie")),
    objasnienia = function() c(
      paste("Półrocze zimowe obejmuje miesiące XI-IV, letnie V-X."),
      paste("Wartości półroczy i roku hydrologicznego: opad i odpływ zsumowane,",
            "współczynnik odpływu obliczony z sum, skrajne wartości odpływu",
            "jednostkowego wzięte z miesięcy skrajnych, wartość średnia uśredniona."),
      objasnienie_wielolecia())
  ),

  list(
    numer = 3,
    obiekt = "tab_3_dane",
    arkusz = "Tabela 3",
    podpis = function() paste0(
      "Roczne wysokości warstwy opadów atmosferycznych i odpływu oraz wartości",
      " współczynnika odpływu i odpływu jednostkowego ze zlewni badawczej ",
      opis_miejsca, " w wieloleciu ", opis_lat_roczne),
    etykiety = replace(ETYKIETY_PARAMETRY,
                       c("okres", "q_avg"),
                       c("Rok", "Średni roczny odpływ jednostkowy")),
    jednostki = JEDNOSTKI_PARAMETRY,
    dokladnosc = DOKLADNOSC_PARAMETRY,
    # Podsumowanie wielolecia i wiersz n. Rozpoznawane po etykiecie z tego samego
    # powodu co w tabeli 2: liczba wierszy podsumowań zależy od tego, czy stacja
    # ma agregaty wieloletnie.
    wyroznione = function(dane) which(
      dane[[1]] == "n" | startsWith(dane[[1]], "Wielolecie")),
    # Wiersz n zlicza lata, więc pokazujemy go bez miejsc po przecinku, niezależnie
    # od zaokrąglenia kolumny.
    wiersze_calkowite = function(dane) which(dane[[1]] == "n"),
    objasnienia = function() c(
      objasnienie_wielolecia(),
      paste0("n – liczba lat",
             if (ma_wielolecie) ", z których obliczono wartości wielolecia",
             "; podana osobno dla każdej kolumny, bo braki w seriach nie muszą",
             " się pokrywać."))
  ),

  list(
    numer = 4,
    obiekt = "tab_4_dane",
    arkusz = "Tabela 4",
    podpis = function() paste0(
      "Wartości graniczne kategorii przepływu",
      czlon_wielolecia(ma_wielolecie, " wyznaczone dla wielolecia ", opis_wielolecia_Q),
      " oraz liczba dni w każdej kategorii ", opis_miejsca,
      " w roku hydrologicznym ", analizowany_rok),
    etykiety = c(kategoria = "Kategoria", warunek = "Warunek", dni = "Liczba dni"),
    # Nagłówek jednostki nazywa wielkość wprost, więc symbol Q w warunkach nie
    # wymaga osobnego objaśnienia.
    jednostki = c(kategoria = "", warunek = paste("Przepływ", J_PRZEPLYW), dni = ""),
    dokladnosc = c(dni = 0),
    objasnienia = function() c(
      paste("Warunki podano dokładnymi wartościami granicznymi, bez zaokrągleń."),
      if (any(tab_4_dane$pusta))
        paste("Przedział kategorii wezbranie małe jest pusty: jego dolna granica,",
              "połowa sumy NWQ i WSQ, leży powyżej granicy wezbrania zwykłego (NWQ).",
              "Wynika to z definicji kategorii, a nie z braku danych."))
  )
)

################################################################################
# TABELE ANEKSU
################################################################################
# Aneks nie powtarza tabel raportu: roczne charakterystyki przepływu mieszczą się
# w całości w zestawieniach statystyk, a miesięczne wysokości opadu i odpływu stoją
# w tabeli 2 raportu.
#
# Kolejność: najpierw trzy zestawienia statystyk (przepływ roczny, odpływ jednostkowy
# roczny, charakterystyki miesięczne), potem trzy zestawienia udziałów kategorii
# (lata, miesiące wielolecia, miesiące roku analizowanego). Cyfra w nazwie obiektu
# odpowiada numerowi tabeli w aneksie i nazwie zakładki w arkuszu Excela:
# tab_a1_dane to tabela 1 aneksu i arkusz "Aneks 1".
################################################################################

TABELE_ANEKS <- list(

  list(
    numer = 1,
    obiekt = "tab_a1_dane",
    arkusz = "Aneks 1",
    podpis = function() paste0(
      "Statystyki przepływu ", opis_miejsca,
      " w latach hydrologicznych ", opis_lat_roczne),
    etykiety = c(rok = "Rok", NQ = "NQ", SQ = "SQ", WQ = "WQ", amplituda = "amplituda",
                 sd = "sd", cv = "cv", p05 = "p05", p25 = "p25", p50 = "p50",
                 p75 = "p75", p95 = "p95", IQR = "IQR"),
    jednostki = c(rok = "", NQ = J_PRZEPLYW, SQ = J_PRZEPLYW, WQ = J_PRZEPLYW,
                  amplituda = J_BEZ, sd = J_PRZEPLYW, cv = "[%]",
                  p05 = J_PRZEPLYW, p25 = J_PRZEPLYW, p50 = J_PRZEPLYW,
                  p75 = J_PRZEPLYW, p95 = J_PRZEPLYW, IQR = J_PRZEPLYW),
    dokladnosc = c(NQ = 3, SQ = 3, WQ = 3, amplituda = 2, sd = 3, cv = 1,
                   p05 = 3, p25 = 3, p50 = 3, p75 = 3, p95 = 3, IQR = 3),
    objasnienia = c(O_CHARAKTERYSTYKI_1ST, O_AMPLITUDA, O_PERCENTYLE)
  ),

  list(
    numer = 2,
    obiekt = "tab_a2_dane",
    arkusz = "Aneks 2",
    podpis = function() paste0(
      "Statystyki odpływu jednostkowego ", opis_miejsca,
      " w latach hydrologicznych ", opis_lat_roczne),
    etykiety = c(rok = "Rok", min = "min", avg = "śr", max = "maks",
                 sd = "sd", cv = "cv", p05 = "p05", p25 = "p25", p50 = "p50",
                 p75 = "p75", p95 = "p95", IQR = "IQR"),
    jednostki = c(rok = "", min = J_ODPLYW_J, avg = J_ODPLYW_J, max = J_ODPLYW_J,
                  sd = J_ODPLYW_J, cv = "[%]", p05 = J_ODPLYW_J, p25 = J_ODPLYW_J,
                  p50 = J_ODPLYW_J, p75 = J_ODPLYW_J, p95 = J_ODPLYW_J,
                  IQR = J_ODPLYW_J),
    dokladnosc = c(min = 2, avg = 2, max = 2, sd = 2, cv = 1, p05 = 2, p25 = 2,
                   p50 = 2, p75 = 2, p95 = 2, IQR = 2),
    objasnienia = c("q – odpływ jednostkowy.", O_PERCENTYLE)
  ),

  list(
    numer = 3,
    obiekt = "tab_a3_dane",
    arkusz = "Aneks 3",
    podpis = function() paste0(
      "Miesięczne charakterystyki przepływu ", opis_miejsca,
      " w roku hydrologicznym ", analizowany_rok),
    etykiety = c(miesiac = "Miesiąc", NQ = "NQ", SQ = "SQ", WQ = "WQ",
                 amplituda = "amplituda", kj = "kj"),
    jednostki = c(miesiac = "", NQ = J_PRZEPLYW, SQ = J_PRZEPLYW, WQ = J_PRZEPLYW,
                  amplituda = J_BEZ, kj = J_BEZ),
    dokladnosc = c(NQ = 3, SQ = 3, WQ = 3, amplituda = 2, kj = 2),
    objasnienia = c(O_CHARAKTERYSTYKI_1ST, O_AMPLITUDA,
                    paste("kj – współczynnik miesięczny przepływu, czyli iloraz przepływu",
                          "średniego miesiąca i przepływu średniego wielolecia."))
  ),

  list(
    numer = 4,
    obiekt = "tab_a4_dane",
    arkusz = "Aneks 4",
    podpis = function() paste0(
      "Udziały kategorii przepływu ", opis_miejsca,
      " w latach hydrologicznych ", opis_lat_kategorie),
    etykiety = c(c(rok = "Rok"), ETYKIETY_KATEGORII),
    jednostki = c(c(rok = ""), JEDNOSTKI_KATEGORII),
    dokladnosc = DOKLADNOSC_KATEGORII,
    objasnienia = O_KATEGORIE
  ),

  list(
    numer = 5,
    obiekt = "tab_a5_dane",
    arkusz = "Aneks 5",
    podpis = function() paste0(
      "Udziały kategorii przepływu ", opis_miejsca, " w miesiącach wielolecia",
      czlon_wielolecia(ma_wielolecie, " ", opis_wielolecia_Q)),
    etykiety = c(c(miesiac = "Miesiąc"), ETYKIETY_KATEGORII),
    jednostki = c(c(miesiac = ""), JEDNOSTKI_KATEGORII),
    dokladnosc = DOKLADNOSC_KATEGORII,
    objasnienia = O_KATEGORIE
  ),

  list(
    numer = 6,
    obiekt = "tab_a6_dane",
    arkusz = "Aneks 6",
    podpis = function() paste0(
      "Udziały kategorii przepływu ", opis_miejsca,
      " w miesiącach roku hydrologicznego ", analizowany_rok),
    etykiety = c(c(miesiac = "Miesiąc"), ETYKIETY_KATEGORII),
    jednostki = c(c(miesiac = ""), JEDNOSTKI_KATEGORII),
    dokladnosc = DOKLADNOSC_KATEGORII,
    objasnienia = O_KATEGORIE
  )
)

################################################################################
# FUNKCJE POMOCNICZE TABEL
################################################################################

# Kolumny pokazywane w tabeli, w kolejności z opisu. Kolumny pomocnicze - jak
# znacznik pustej kategorii w tabeli 4 albo znacznik typu wiersza w tabeli 1 -
# nie mają etykiety i tu odpadają.
kolumny_tabeli = function(dane, opis) {
  dane[, names(opis$etykiety), drop = FALSE]
}

# Zaokrąglenie kolumn liczbowych. dokladnosc bywa jedną liczbą dla całej tabeli
# albo wektorem nazwanym kolumnami; kolumna spoza wektora dostaje wartość domyślną.
zaokraglij_tabele = function(dane, dokladnosc, domyslnie = 2) {
  for (kolumna in names(dane)) {
    if (!is.numeric(dane[[kolumna]])) next
    miejsca <- if (length(dokladnosc) == 1 && is.null(names(dokladnosc))) dokladnosc
               else if (kolumna %in% names(dokladnosc)) dokladnosc[[kolumna]]
               else domyslnie
    dane[[kolumna]] <- round(dane[[kolumna]], miejsca)
  }
  dane
}

# Objaśnienia i wiersze wyróżnione bywają zależne od danych, więc w opisie tabeli
# mogą być funkcją. Ta funkcja sprowadza oba przypadki do jednego.
wartosc_opisu = function(element, ...) {
  if (is.function(element)) element(...) else element
}

# Objaśnienia pod tabelą, złożone w jeden akapit. Puste i niezachodzące pozycje
# (jak przypis o pustej kategorii, gdy kategoria pusta nie jest) odpadają.
objasnienia_txt = function(opis) {
  tresc <- wartosc_opisu(opis$objasnienia)
  tresc <- tresc[!is.na(tresc) & nzchar(tresc)]
  if (length(tresc) == 0) return("")
  paste("Objaśnienia:", paste(tresc, collapse = " "))
}
