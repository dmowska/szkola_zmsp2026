################################################################################
# OPIS SKRYPTU
################################################################################
# funkcje/plot_theme.R - wspólny motyw rycin
#
# Definiuje motyw nadawany wszystkim rycinom raportu: krój szeryfowy (w dokumencie
# Times New Roman), ramka panelu, jasna siatka główna, jednakowa wielkość pisma
# we wszystkich opisach i legenda pod wykresem. Wczytują go uruchamianie_skryptow.R
# i tworzenie_wykresow.R, a korzystają z niego wszystkie pliki wykresy/ryc_*.R.
#
# Uwagi do kodu:
#
# JAK SIĘ GO UŻYWA
#   plot_theme() jest funkcją bez argumentów, dokładaną na końcu łańcucha ggplot2:
#   ... + plot_theme(). Każde wywołanie zwraca osobny motyw, więc ryciny nie dzielą
#   jednego obiektu.
#
# WŁASNE POPRAWKI RYCINY
#   Motyw powstaje z theme_linedraw() przez %+replace%, czyli podmienia wskazane
#   elementy, a resztę zostawia. Rycina, która potrzebuje odstępstwa (np. obróconych
#   podpisów osi X), dokłada własne theme() PO plot_theme() - liczy się ostatni wpis.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - brak - plik nie korzysta z żadnych obiektów zewnętrznych
################################################################################
# WYNIK
################################################################################
# - plot_theme: funkcja zwracająca motyw ggplot2, gotowy do dodania do ryciny
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
################################################################################

plot_theme = function() {
  theme_linedraw() %+replace%
    theme(
      text = element_text(family = "serif", size = 12, colour = "black"),
      panel.background = element_rect(fill = NA, colour = NA),
      # ramka panelu i sama siatka główna, bez siatki pomocniczej
      panel.border = element_rect(colour = "black", fill = NA),
      panel.grid.major = element_line(colour = "grey60", linewidth = 0.2),
      panel.grid.minor = element_blank(),
      # jednakowa wielkość czcionki we wszystkich elementach opisu
      axis.text = element_text(size = 12),
      axis.title = element_text(size = 12),
      legend.title = element_text(size = 12),
      legend.text = element_text(size = 12),
      plot.title = element_text(size = 12, face = "bold"),
      legend.position = "bottom",
      legend.margin = margin(t = -1),    # Ujemny margines górny legendy (przyciąga ją do osi)
      legend.box.spacing = unit(0, "pt"),  # Zredukowanie przestrzeni między obszarem wykresu a legendą
      plot.margin = margin(b = 5, t = 5, l = 5, r = 5) # Opcjonalnie: ogólne marginesy wykresu
    )
}

