################################################################################
# OPIS SKRYPTU
################################################################################
# funkcje/slownik_stanowisk.R - wykaz stacji bazowych i ich stanowisk wodowskazowych
#
# Baza podaje przy każdym wyniku kod stacji i kod stanowiska, ale nie mówi ani jak
# stacja się nazywa, ani które stanowiska wchodzą do raportu i które z nich jest
# stanowiskiem odniesienia. Raport potrzebuje wszystkich trzech rzeczy: nazwa stacji
# wchodzi do tytułu, wykaz stanowisk rozstrzyga, czyje dane w ogóle się liczą,
# a wskazanie odniesienia - skąd brane są opad, odpływ i współczynnik odpływu oraz
# które stanowisko stoi pierwsze.
# Ze słownika czyta pobieranie_danych.R - przez stacja_ze_slownika()
# z funkcje/funkcje_pomocnicze.R - a stamtąd nazwy trafiają do podpisów tabel i rycin.
#
# Uwagi do kodu:
#
# KLUCZEM JEST PARA KOD + STANOWISKO
#   Numery stanowisk powtarzają się między stacjami - stanowisko "022" ma zarówno
#   09ZM, jak i 14ZM - więc wyszukiwanie po samym numerze stanowiska trafia w cudzy
#   wiersz. Dopasowanie zawsze idzie po obu kolumnach naraz.
#
# KODY ZOSTAJĄ TEKSTEM
#   Kody stanowisk mają w bazie wiodące zero ("008", "004"). Konwersja na liczbę
#   ucina to zero i dopasowanie przestaje działać, dlatego kolumny kod i stanowisko
#   są znakowe.
#
# STANOWISKO ODNIESIENIA (KOLUMNA UJSCIE)
#   Dokładnie jedno RAPORTOWANE stanowisko stacji ma ujscie = TRUE, także wtedy, gdy
#   stacja ma tylko jedno stanowisko - reguła "opad i odpływ z ujścia" działa więc
#   tak samo niezależnie od ich liczby. To z tego stanowiska biorą się opad, odpływ
#   i współczynnik odpływu oraz wszystkie tabele i ryciny opisujące jeden profil.
#   Kolumna kolejnosc ustala porządek stanowisk w raporcie, odniesienie zawsze jako
#   pierwsze. Zwykle odniesieniem jest profil przy ujściu zlewni; wyjątkiem są Wigry,
#   gdzie ujściowe 009 nie wchodzi do raportu i rolę odniesienia przejmuje 008.
#
# KOLUMNA RAPORT - STANOWISKA POMIJANE
#   Baza bywa bogatsza niż raport: stacja może mieć profil, którego raport nie
#   opisuje. Takie stanowisko zostaje w słowniku z raport = FALSE. Jego dane nie
#   wchodzą wtedy do żadnej tabeli ani ryciny - odsiewa je sekcja 2 skryptu
#   skrypty/przetwarzanie_danych.R - ale w słowniku widać, że profil istnieje,
#   i podpisy nadal wymieniają numer profilu, którego raport dotyczy.
#   Tak jest na Wigrach: raport obejmuje WYŁĄCZNIE stanowisko 008, choć baza ma też
#   ujściowe 009. Pojezierze Chełmińskie zostaje stacją różnicową - oba jego profile,
#   501 i 502, mają raport = TRUE.
#
# KOLUMNA CIEK
#   Wchodzi do KAŻDEGO podpisu tabeli i ryciny, bo szablon ZMŚP wymaga frazy
#   "rzeki X w profilu wodowskazowym Y". Wpis "XXXX" oznacza nazwę jeszcze
#   nieuzupełnioną i widać go w gotowym dokumencie. Sam profil wodowskazowy
#   identyfikuje w podpisach KOD stanowiska, a nie nazwa przekroju.
#
# NOWA STACJA ALBO NOWE STANOWISKO
#   Trzeba dopisać pozycję w każdym z wektorów: kod, nazwa, stanowisko, raport,
#   ujscie, kolejnosc i ciek - zawsze na tym samym miejscu we wszystkich. Dopóki
#   wiersza nie ma, pobieranie danych przerywa pracę komunikatem o nieznanym kodzie
#   stacji.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - brak - plik nie korzysta z żadnych obiektów zewnętrznych
################################################################################
# WYNIK
################################################################################
# - slownik_stanowisk: ramka danych, jeden wiersz na stanowisko wodowskazowe,
#   o kolumnach
#     kod              - identyfikator stacji bazowej ZMŚP, np. "06ZM"
#     nazwa            - pełna nazwa stacji bazowej, np. "Parsęta"
#     stanowisko       - kod stanowiska wodowskazowego, np. "004"
#     raport           - TRUE dla stanowiska wchodzącego do tabel i rycin raportu
#     ujscie           - TRUE dla stanowiska odniesienia (jedno na stację, spośród
#                        raportowanych)
#     kolejnosc        - kolejność stanowisk w raporcie (odniesienie zawsze 1)
#     ciek             - nazwa cieku do podpisów; "XXXX" do czasu uzupełnienia
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - brak (plik nie wywołuje funkcji spoza R base)
################################################################################

slownik_stanowisk = data.frame(
  kod = c("05ZM", "05ZM", "06ZM", "07ZM", "07ZM", "08ZM", "09ZM",
          "10ZM", "11ZM", "12ZM", "13ZM", "14ZM", "15ZM"),
  nazwa = c("Wigry", "Wigry", "Parsęta",
            "Pojezierze Chełmińskie", "Pojezierze Chełmińskie",
            "Kampinos", "Łysogóry", "Beskid Niski", "Wolin", "Roztocze",
            "Poznań Morasko", "Karkonosze", "Pogórze Karpackie"),
  stanowisko = c("009", "008", "004", "502", "501", "026", "022",
                 "006", "011", "032", "010", "022", "003"),
  # 05ZM/009: profil ujściowy Wigier ZOSTAJE POZA RAPORTEM - tabele i ryciny tej
  # stacji powstają wyłącznie dla 008, które przejmuje rolę stanowiska odniesienia.
  raport = c(FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE,
             TRUE, TRUE, TRUE, TRUE, TRUE, TRUE),
  ujscie = c(FALSE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE,
             TRUE, TRUE, TRUE, TRUE, TRUE, TRUE),
  kolejnosc = c(2L, 1L, 1L, 1L, 2L, 1L, 1L,
                1L, 1L, 1L, 1L, 1L, 1L),
  ciek = c("Czarna Hańcza", "Czarna Hańcza", "Parsęta",
           "Struga Toruńska", "Struga Toruńska",
           "Kanał Olszowiecki", "Wieniec", "Bystrzanka", "Lewińska Struga", "Świerszcz",
           "Różany Strumień", "Wrzosówka", "Stara Rzeka"),
  stringsAsFactors = FALSE
)
