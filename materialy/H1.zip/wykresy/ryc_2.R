################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 2 - przebieg opadu i przepływu w roku analizowanym
#
# Panele ustawione jeden pod drugim, na wspólnej osi czasu obejmującej cały rok
# hydrologiczny: u góry dobowe sumy opadu atmosferycznego, niżej dobowy przepływ.
# Poziome linie przerywane to progi kategorii przepływu. Układ pozwala odczytać,
# po których opadach rzeka odpowiedziała wzrostem przepływu.
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Dobowe wartości opadu atmosferycznego i natężenia przepływu {opis_miejsc} w roku
#   hydrologicznym {analizowany_rok}.{opis_linii_progowych}"
#
#   {opis_miejsc} to profile WSZYSTKICH stanowisk, np. "w profilach
#   wodowskazowych 502 i 501 w Stacji Bazowej ZMŚP Pojezierze Chełmińskie"; fraza znika
#   tylko na stacji, która ma w słowniku jeden profil (Wigry mają dwa, choć raport
#   opisuje samo 008, więc fraza zostaje).
#
# Uwagi do kodu:
#
# PANELE
#   Opad jest wspólny dla stacji, więc jego panel rysowany jest raz, z danych
#   stanowiska odniesienia; natężenie przepływu dostaje osobny panel dla każdego
#   stanowiska.
#   Przy jednym stanowisku rycina ma dwa panele, przy dwóch - trzy, i tylko wtedy
#   panele przepływu mają tytuł z kodem stanowiska.
#
# OŚ CZASU
#   Podziałki stoją w pierwszych dniach kolejnych miesięcy, policzone z danych,
#   bo miesiące mają różną długość, a rok hydrologiczny bywa przestępny.
#
# LINIE PROGOWE
#   Legenda wymienia wyłącznie linie, które faktycznie stoją na rycinie - ten sam
#   wykaz, kategorie_linii, rozwija skróty w podpisie ryciny.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_dobowe_rok: dobowy opad i przepływ w roku analizowanym
# - dane_linie_progowe, kategorie_linii: wartości graniczne kategorii dla każdego
#     stanowiska oraz wykaz kategorii, których linie trafiają na rycinę
# - kody_stanowisk, stanowisko_ujscie, ma_dwa_stanowiska, etykiety_stanowisk
################################################################################
# WYNIK
################################################################################
# - ryc_2: rycina złożona z paneli albo NULL, gdy brak danych roku analizowanego
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
# - cowplot
# - dplyr
################################################################################

# Podziałki osi X: pierwszy dzień każdego miesiąca roku hydrologicznego.
osie_miesiecy_2 <- dane_dobowe_rok |>
  group_by(miesiac) |>
  summarise(dzien_roku = min(dzien_roku), .groups = "drop") |>
  arrange(miesiac)

os_x_2 <- list(breaks = osie_miesiecy_2$dzien_roku,
               labels = miesiac_rzymski(osie_miesiecy_2$miesiac))

# Panel opadu - z ujścia, bo opad jest jeden na stację.
panel_opad_2 <- ggplot(filter(dane_dobowe_rok, stanowisko == stanowisko_ujscie),
                       aes(x = dzien_roku, y = RR_T)) +
  geom_bar(stat = "identity", fill = "#2f75b5", width = 1, na.rm = TRUE) +
  scale_x_continuous(breaks = os_x_2$breaks, labels = os_x_2$labels) +
  xlab("") +
  ylab(etykieta_osi("RR_T")) +
  plot_theme()

# Panel przepływu dla jednego stanowiska, wraz z jego własnymi liniami progowymi.
panel_przeplyw_2 <- function(kod) {
  dane <- filter(dane_dobowe_rok, stanowisko == kod)
  progi <- filter(dane_linie_progowe, stanowisko == kod)

  wykres <- ggplot(dane, aes(x = dzien_roku, y = Q_E)) +
    geom_line(colour = "black", linewidth = 0.5, na.rm = TRUE) +
    geom_hline(data = progi, aes(yintercept = wartosc, colour = kategoria),
               linetype = "dashed", linewidth = 0.5) +
    scale_x_continuous(breaks = os_x_2$breaks, labels = os_x_2$labels) +
    scale_colour_manual(name = "", values = kolory_kategorii,
                        breaks = kategorie_linii,
                        labels = unname(skroty_kategorii[kategorie_linii])) +
    xlab("") +
    ylab(etykieta_osi("Q_E")) +
    guides(colour = guide_legend(nrow = 1)) +
    plot_theme()

  if (ma_dwa_stanowiska) {
    wykres <- wykres + ggtitle(unname(etykiety_stanowisk[kod]))
  }
  wykres
}

# Legenda stoi tylko pod ostatnim panelem: linie progowe znaczą na każdym z nich
# to samo.
panele_2 <- c(list(panel_opad_2), lapply(kody_stanowisk, panel_przeplyw_2))
panele_2 <- lapply(panele_2, function(p)
  p + theme(plot.margin = margin(t = 14, r = 5, b = 5, l = 5)))

ostatni_2 <- length(panele_2)
panele_2[-ostatni_2] <- lapply(panele_2[-ostatni_2],
                               function(p) p + theme(legend.position = "none"))

# Ostatni panel jest wyższy o legendę, więc dostaje odpowiednio więcej miejsca.
ryc_2 = plot_grid(plotlist = panele_2, ncol = 1, align = "v", axis = "lr",
                  rel_heights = c(rep(1, ostatni_2 - 1), 1.2))

ryc_2

rm(osie_miesiecy_2, os_x_2, panel_opad_2, panel_przeplyw_2, panele_2, ostatni_2)

# Bez danych roku analizowanego rycina byłaby pustą ramką z podpisem. NULL sprawia,
# że raport pomija jej blok w całości.
if (!ma_dane(dane_dobowe_rok$Q_E, dane_dobowe_rok$RR_T)) ryc_2 <- NULL
