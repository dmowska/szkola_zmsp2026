################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 3 - rok analizowany na tle wielolecia
#
# Przebieg dobowego przepływu w roku analizowanym narysowany na tle wstęg opisujących
# zmienność tego samego dnia roku w całym wieloleciu. Wstęgi idą od najszerszej do
# najwęższej: zakres od minimum do maksimum, przedział między percentylami 5 i 95
# oraz między 25 i 75; na wierzchu stoją mediana i średnia wielolecia. Linia roku
# analizowanego wychodząca poza wstęgi wskazuje dzień nietypowy na tle serii.
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Natężenie przepływu {opis_miejsc} w kolejnych dniach roku hydrologicznego
#   {analizowany_rok}[ na tle zmienności natężenia przepływu w wieloleciu
#   {opis_wielolecia_Q}]. Wstęgi obejmują
#   zakres wartości skrajnych oraz przedziały między percentylami 5 i 95 oraz 25 i 75"
#
#   {opis_miejsc} to profile WSZYSTKICH stanowisk, np. "w profilach
#   wodowskazowych 502 i 501 w Stacji Bazowej ZMŚP Pojezierze Chełmińskie"; fraza znika
#   tylko na stacji, która ma w słowniku jeden profil (Wigry mają dwa, choć raport
#   opisuje samo 008, więc fraza zostaje).
#   Fragment w nawiasie kwadratowym wypada, gdy baza nie ma dla stacji danych
#   wieloletnich.
#
# Uwagi do kodu:
#
# PANELE STANOWISK
#   Każde stanowisko dostaje własny panel, bo ma własne wielolecie i własny przebieg
#   roku. Tytuł z kodem stanowiska pojawia się tylko wtedy, gdy stanowiska są dwa.
#
# LEGENDA
#   Podpisem pierwszej linii jest rok analizowany, więc powstaje z parametru
#   analizowany_rok. Legenda stoi pod ostatnim panelem i ma dwa rzędy: linie
#   w pierwszym, wstęgi w drugim.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_doy: wieloletnie statystyki przepływu dla dni roku (wszystkie stanowiska)
# - dane_dobowe_rok: przebieg roku analizowanego
# - kody_stanowisk, ma_dwa_stanowiska, etykiety_stanowisk, analizowany_rok
################################################################################
# WYNIK
################################################################################
# - ryc_3: rycina złożona z paneli albo NULL, gdy brak statystyk wieloletnich
#     albo serii dobowej roku analizowanego
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
# - cowplot
# - dplyr
################################################################################

# Podziałki osi X w pierwszych dniach kolejnych miesięcy. Statystyki wieloletnie
# nie niosą miesiąca, więc bierzemy je z kolumny DD-MM.
osie_miesiecy_3 <- dane_doy |>
  filter(stanowisko == stanowisko_ujscie) |>
  mutate(miesiac = jako_miesiac(substr(`DD-MM`, 4, 5))) |>
  group_by(miesiac) |>
  summarise(dzien_roku = min(dzien_roku), .groups = "drop") |>
  arrange(miesiac)

os_x_3 <- list(breaks = osie_miesiecy_3$dzien_roku,
               labels = miesiac_rzymski(osie_miesiecy_3$miesiac))

# Rok analizowany jako poziom skali koloru - stąd nazwa podstawiana z parametru.
# Kolejnosc nazw musi byc taka sama jak w A1 (nazwy_linii_doy w przetwarzanie_danych.R):
# barwy podstawiane sa POZYCYJNIE, wiec druga wartosc kolory_linii_doy (granat) trafia
# na mediane, a trzecia (turkus) na srednia. Bez tego H1 mialoby te barwy odwrotnie niz A1.
kolory_linii_3 <- setNames(unname(kolory_linii_doy),
                           c(as.character(analizowany_rok), "Mediana", "Średnia"))

panel_doy_3 <- function(kod) {
  tlo <- filter(dane_doy, stanowisko == kod)
  rok <- filter(dane_dobowe_rok, stanowisko == kod)

  wykres <- ggplot(tlo, aes(x = dzien_roku)) +
    geom_ribbon(aes(ymin = NQ, ymax = WQ, fill = "Minimum-Maksimum"), alpha = 0.4) +
    geom_ribbon(aes(ymin = `Q_E p05`, ymax = `Q_E p95`, fill = "Percentyle: 05-95"), alpha = 0.8) +
    geom_ribbon(aes(ymin = `Q_E p25`, ymax = `Q_E p75`, fill = "Percentyle: 25-75"), alpha = 0.6) +
    geom_line(aes(y = SQ, colour = "Średnia"), linewidth = 0.6) +
    geom_line(aes(y = `Q_E p50`, colour = "Mediana"), linewidth = 0.6) +
    geom_line(data = rok, aes(x = dzien_roku, y = Q_E,
                              colour = as.character(analizowany_rok)),
              linewidth = 0.6, na.rm = TRUE) +
    scale_fill_manual(name = "", values = kolory_perc_doy) +
    scale_colour_manual(name = "", values = kolory_linii_3) +
    scale_x_continuous(breaks = os_x_3$breaks, labels = os_x_3$labels) +
    xlab("") +
    ylab(etykieta_osi("Q_E")) +
    guides(colour = guide_legend(order = 1, nrow = 1),
           fill = guide_legend(order = 2, nrow = 1)) +
    plot_theme() +
    theme(legend.box = "vertical", legend.spacing.y = unit(0.2, "cm"))

  if (ma_dwa_stanowiska) {
    wykres <- wykres + ggtitle(unname(etykiety_stanowisk[kod]))
  }
  wykres
}

# Legenda tylko pod ostatnim panelem: na każdym znaczy to samo.
panele_3 <- lapply(kody_stanowisk, panel_doy_3)
panele_3 <- lapply(panele_3, function(p)
  p + theme(plot.margin = margin(t = 14, r = 5, b = 5, l = 5)))

ostatni_3 <- length(panele_3)
panele_3[-ostatni_3] <- lapply(panele_3[-ostatni_3],
                               function(p) p + theme(legend.position = "none"))

ryc_3 = plot_grid(plotlist = panele_3, ncol = 1, align = "v", axis = "lr",
                  rel_heights = c(rep(1, ostatni_3 - 1), 1.3))

ryc_3

rm(osie_miesiecy_3, os_x_3, kolory_linii_3, panel_doy_3, panele_3, ostatni_3)

# Rycina zestawia rok analizowany z tłem wielolecia, więc powstaje tylko wtedy, gdy
# są OBIE serie. Bez którejś z nich ryc_3 jest NULL i raport pomija jej blok.
if (!ma_dane(dane_doy$SQ) || !ma_dane(dane_dobowe_rok$Q_E)) ryc_3 <- NULL
