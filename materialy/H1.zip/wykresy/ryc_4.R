################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 4 - mapa miesięcznych sum opadu
#
# Wykres kafelkowy (mapa ciepła): kolumna to rok hydrologiczny, wiersz to miesiąc,
# a odcień niebieskiego to miesięczna suma opadu atmosferycznego. Miesiące na osi
# pionowej idą od listopada u góry do października u dołu. Skala jest skwantowana,
# więc odcień odpowiada klasie sumy, a nie dokładnej wartości.
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Miesięczne sumy opadu atmosferycznego {opis_stacji} w kolejnych latach
#   hydrologicznych {zakres_lat(lata_ryc_4)}. Miesiące bez pomiaru pozostają białe"
#
#   {opis_stacji} to sama nazwa stacji, np. "w Stacji Bazowej ZMŚP Pojezierze
#   Chełmińskie" - opad nie jest przypisany do stanowiska.
#
# Uwagi do kodu:
#
# BIAŁY KAFELEK
#   Biały kafelek to miesiąc bez pomiaru, a nie miesiąc bez opadu - najniższa klasa
#   skali ma własny, jasnoniebieski odcień.
#
# ZAKRES OSI POZIOMEJ
#   Oś biegnie od pierwszego do ostatniego roku z danymi miesięcznymi (lata_ryc_4).
#   Rok bez pomiarów leżący w tym zakresie zostaje na osi jako pusta kolumna.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_miesieczne: miesięczne sumy opadu stanowiska odniesienia
# - lata_ryc_4 (lata z danymi miesięcznymi: zakres osi)
################################################################################
# WYNIK
################################################################################
# - ryc_4: rycina (obiekt ggplot) albo NULL, gdy brak danych o opadzie
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
################################################################################

os_ryc_4 <- os_lat(lata_ryc_4)

# Kolejność miesięcy na osi pionowej podana JAWNIE przez limits: od listopada u góry
# do października u dołu.
ryc_4 = ggplot(dane_miesieczne,
               aes(x = rok_hydro, y = miesiac, fill = RR_T)) +
  geom_tile(colour = "white", linewidth = 0.2) +
  scale_fill_fermenter(name = "Opad atmosferyczny [mm]",
                       palette = "Blues", direction = 1, n.breaks = 7,
                       na.value = "white") +
  scale_x_continuous(breaks = os_ryc_4$breaks, labels = os_ryc_4$labels,
                     expand = expansion(add = 0)) +
  scale_y_discrete(limits = rev(as.character(miesiace_hydro)),
                   labels = function(x) miesiac_rzymski(x)) +
  xlab("") +
  ylab("") +
  guides(fill = guide_colorsteps(barwidth = unit(6, "cm"), barheight = unit(0.4, "cm"))) +
  plot_theme() +
  theme(panel.grid.major = element_blank(),
        axis.text.x = element_text(angle = 90, vjust = 0.5))

ryc_4

rm(os_ryc_4)

# Stacja bez pomiarów opadu dałaby jednolicie białą mapę z podpisem.
if (!ma_dane(dane_miesieczne$RR_T)) ryc_4 <- NULL
