################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 9 - zmienność miesięcznych amplitud przepływu w kolejnych latach
#
# Każdy rok hydrologiczny opisują trzy elementy policzone z jego dwunastu wartości
# miesięcznych amplitudy: jasna wstęga obejmuje zakres od najmniejszej do największej,
# ciemna - przedział międzykwartylowy, a punkt oznacza średnią. Szeroka wstęga to rok
# o miesiącach mocno różniących się między sobą, wąska - rok wyrównany. Wstęgi łączą
# sąsiednie lata linią, ale każdy rok opisuje osobny zestaw wartości; na roku bez
# danych wstęga się przerywa.
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Zmienność miesięcznych wartości amplitudy względnej natężenia przepływu
#   {opis_miejsca} w kolejnych
#   latach hydrologicznych {zakres_lat(lata_ryc_9)}. Wstęga jasna obejmuje zakres od wartości
#   najmniejszej do największej, ciemna - przedział międzykwartylowy, a punkt oznacza
#   średnią z wartości miesięcznych"
#
#   {opis_miejsca} to profil stanowiska ODNIESIENIA, np. "w profilu wodowskazowym
#   502 w Stacji Bazowej ZMŚP Pojezierze Chełmińskie"; fraza znika tylko
#   na stacji, która ma w słowniku jeden profil (Wigry mają dwa, choć raport opisuje
#   samo 008, więc fraza zostaje).
#
# Uwagi do kodu:
#
# AMPLITUDA
#   Kolumna amplituda niesie amplitudę WZGLĘDNĄ, czyli iloraz (WQ - NQ) / SQ - wielkość
#   bez jednostki. Statystyki roku liczymy z dwunastu wartości miesięcznych, a nie
#   z wartości dobowych.
#
# ROK BEZ WARTOŚCI
#   Rok o samych brakach odrzucamy przed rysowaniem: min() i max() zwróciłyby dla niego
#   nieskończoności, które wywracają skalę osi. Jego miejsce na osi zostaje puste,
#   a wstęgi i linie przerywają się na luce, zamiast łączyć odległe lata. Rok z danymi
#   otoczony lukami dostaje zakres i przedział międzykwartylowy jako pionowe odcinki -
#   sama średnia byłaby pojedynczym punktem bez opisu rozrzutu.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_miesieczne: miesięczne wartości amplitudy względnej natężenia przepływu,
#     stanowisko odniesienia
# - lata_ryc_9 (lata z danymi miesięcznymi: zakres osi)
################################################################################
# WYNIK
################################################################################
# - ryc_9: rycina (obiekt ggplot) albo NULL, gdy brak wartości amplitudy;
#     dokument pomija wtedy blok ryciny wraz z podpisem
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
# - dplyr
################################################################################

os_ryc_9 <- os_lat(lata_ryc_9)

dane_ryc_9 <- dane_miesieczne |>
  filter(!is.na(amplituda)) |>
  group_by(rok_hydro) |>
  summarise(najmniejsza = min(amplituda),
            q25 = quantile(amplituda, 0.25),
            srednia = mean(amplituda),
            q75 = quantile(amplituda, 0.75),
            najwieksza = max(amplituda),
            .groups = "drop") |>
  # Lata bez danych miesięcznych dostają wiersz z brakami. Wstęgi i linie przerywają
  # się wtedy na luce, zamiast łączyć sąsiednie lata odcinkiem, który udawałby
  # wartości roku nieobecnego w bazie.
  right_join(tibble(rok_hydro = os_ryc_9$breaks), by = "rok_hydro") |>
  arrange(rok_hydro)

# Rok bez danych w obu sąsiednich latach nie ma z kim utworzyć wstęgi, więc zostałby
# z samą średnią. Takie lata dostają zakres i przedział międzykwartylowy jako pionowe
# odcinki w kolorach wstęg. W serii bez luk takich lat nie ma i odcinki nie powstają.
odosobnione_ryc_9 <- dane_ryc_9 |>
  filter(!is.na(srednia),
         is.na(lag(srednia)) | lag(rok_hydro) != rok_hydro - 1,
         is.na(lead(srednia)) | lead(rok_hydro) != rok_hydro + 1)

kolory_ryc_9 <- c("zakres" = "#87CEFA", "przedział międzykwartylowy" = "#335572")

ryc_9 = ggplot(dane_ryc_9, aes(x = rok_hydro)) +
  geom_ribbon(aes(ymin = najmniejsza, ymax = najwieksza, fill = "zakres"), alpha = 0.5,
              na.rm = TRUE) +
  geom_ribbon(aes(ymin = q25, ymax = q75, fill = "przedział międzykwartylowy"), alpha = 0.7,
              na.rm = TRUE) +
  geom_linerange(data = odosobnione_ryc_9,
                 aes(ymin = najmniejsza, ymax = najwieksza, colour = NULL),
                 colour = scales::alpha("#87CEFA", 0.5), linewidth = 3) +
  geom_linerange(data = odosobnione_ryc_9,
                 aes(ymin = q25, ymax = q75, colour = NULL),
                 colour = scales::alpha("#335572", 0.7), linewidth = 3) +
  geom_line(aes(y = najmniejsza), colour = "black", linewidth = 0.3, na.rm = TRUE) +
  geom_line(aes(y = najwieksza), colour = "black", linewidth = 0.3, na.rm = TRUE) +
  geom_point(aes(y = srednia, colour = "średnia"), size = 1.2, na.rm = TRUE) +
  scale_fill_manual(name = "", values = kolory_ryc_9) +
  scale_colour_manual(name = "", values = c("średnia" = "darkblue")) +
  scale_x_continuous(breaks = os_ryc_9$breaks, labels = os_ryc_9$labels,
                     limits = os_ryc_9$limits, expand = expansion(add = 0)) +
  xlab("") +
  ylab(etykieta_osi("amplituda")) +
  guides(colour = guide_legend(order = 1, nrow = 1),
         fill = guide_legend(order = 2, nrow = 1)) +
  plot_theme() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5))

ryc_9

rm(os_ryc_9, dane_ryc_9, kolory_ryc_9, odosobnione_ryc_9)

# Stacja bez wartości amplitudy dałaby pustą ramkę z podpisem. NULL sprawia,
# że dokument pomija blok ryciny (eval = !is.null(ryc_9)).
if (!ma_dane(dane_miesieczne$amplituda)) ryc_9 <- NULL
