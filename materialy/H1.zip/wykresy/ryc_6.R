################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 6 - liczba dni w kategoriach przepływu, rok po miesiącu
#
# Wykresy kafelkowe (mapy ciepła), po jednej na kategorię przepływu, ułożone w dwóch
# kolumnach w kolejności od wezbrań do niżówek. W każdym panelu kolumna to rok
# hydrologiczny, wiersz to miesiąc, a odcień - liczba dni, w których przepływ mieścił
# się w danej kategorii, podzielona na klasy po pięć dni. Rycina pokazuje, w których
# miesiącach roku i w których latach dana kategoria się powtarzała.
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Liczba dni w kategoriach natężenia przepływu {opis_miejsca} w kolejnych miesiącach lat
#   hydrologicznych {zakres_lat(lata_ryc_6)}. Miesiące bez ani jednego dnia w danej kategorii
#   pozostają białe"
#
#   {opis_miejsca} to profil stanowiska ODNIESIENIA, np. "w profilu wodowskazowym
#   502 w Stacji Bazowej ZMŚP Pojezierze Chełmińskie"; fraza znika tylko
#   na stacji, która ma w słowniku jeden profil (Wigry mają dwa, choć raport opisuje
#   samo 008, więc fraza zostaje).
#
# Uwagi do kodu:
#
# BIAŁY KAFELEK
#   Biały kafelek to miesiąc, w którym kategoria nie wystąpiła ani razu. Zero dni
#   i brak wyniku trafiają do tej samej klasy "brak", więc biel nie rozróżnia braku
#   zjawiska od braku pomiaru.
#
# LICZBA PANELI
#   Kategoria, która w całym zakresie lat nie wystąpiła ani razu, nie dostaje panelu -
#   rycina ma wtedy mniej niż sześć paneli. O tym, że kategoria w ogóle istnieje,
#   mówi tabela wartości granicznych.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_kategorie_rok_miesiac: liczba dni w kategoriach, rok x miesiąc
# - lata_ryc_6 (lata z kategoriami miesięcznymi: zakres osi)
################################################################################
# WYNIK
################################################################################
# - ryc_6: rycina (obiekt ggplot) albo NULL, gdy brak danych o kategoriach
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
# - dplyr
################################################################################

os_ryc_6 <- os_lat(lata_ryc_6, docelowo = 7)

# Do ryciny wchodzą tylko kategorie, które wystąpiły choć raz. Panel wypełniony
# w całości bielą wyglądałby na brak danych, a byłby brakiem zjawiska.
kategorie_obecne_6 <- dane_kategorie_rok_miesiac |>
  group_by(kategoria) |>
  summarise(razem = sum(dni, na.rm = TRUE), .groups = "drop") |>
  filter(razem > 0) |>
  pull(kategoria)

# Klasa liczby dni. Zero i brak wyniku trafiają do wspólnej klasy "brak" - w obu
# przypadkach kategoria w danym miesiącu nie wystąpiła.
dane_ryc_6 <- dane_kategorie_rok_miesiac |>
  filter(kategoria %in% kategorie_obecne_6) |>
  mutate(kategoria = droplevels(kategoria),
         klasa_dni = cut(dni, breaks = c(0, 5, 10, 15, 20, 25, 31),
                         labels = head(names(kolory_liczby_dni), -1)),
         klasa_dni = factor(ifelse(is.na(klasa_dni), "brak", as.character(klasa_dni)),
                            levels = names(kolory_liczby_dni)))

# Kolejność miesięcy na osi pionowej podana JAWNIE przez limits: od listopada u góry
# do października u dołu.
ryc_6 = ggplot(dane_ryc_6,
               aes(x = rok_hydro, y = miesiac, fill = klasa_dni)) +
  klucze_legendy(dane_ryc_6, "klasa_dni", names(kolory_liczby_dni)) +
  geom_tile(colour = "lightgrey", linewidth = 0.15) +
  facet_wrap(~kategoria, ncol = 2) +
  scale_fill_manual(name = "Liczba dni", values = kolory_liczby_dni, drop = FALSE) +
  scale_x_continuous(breaks = os_ryc_6$breaks, labels = os_ryc_6$labels,
                     expand = expansion(add = 0)) +
  scale_y_discrete(limits = rev(as.character(miesiace_hydro)),
                   labels = function(x) miesiac_rzymski(x)) +
  xlab("") +
  ylab("") +
  # Legenda w dwóch wierszach, żeby każdy klucz zmieścił podpis obok prostokąta.
  guides(fill = guide_legend(nrow = 2)) +
  plot_theme() +
  theme(panel.grid.major = element_blank(),
        strip.background = element_rect(colour = "darkgrey", fill = "white"),
        strip.text = element_text(colour = "black", face = "bold.italic", size = 11),
        axis.text.x = element_text(angle = 90, vjust = 0.5, size = 10),
        axis.text.y = element_text(size = 10))

ryc_6

rm(os_ryc_6, dane_ryc_6, kategorie_obecne_6)

# Stacja bez podziału na kategorie dałaby same puste panele z podpisem. NULL sprawia,
# że raport pomija blok ryciny w całości.
if (!ma_dane(dane_kategorie_rok_miesiac$dni)) ryc_6 <- NULL
