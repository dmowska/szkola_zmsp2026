################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 1 - rozkład dobowych przepływów w kolejnych latach
#
# Jedno pudełko na rok hydrologiczny, zbudowane z dobowych wartości przepływu:
# pudełko obejmuje przedział międzykwartylowy, kreska w środku to mediana,
# a ciemnoczerwone punkty to wartości odstające. Poziome linie przerywane to progi
# kategorii przepływu policzone dla stanowiska. Rycina pokazuje, jak rozkład przepływu
# zmieniał się z roku na rok i które lata wychodziły poza granice kategorii.
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Zmienność dobowych wartości natężenia przepływu {opis_miejsc} w kolejnych latach
#   hydrologicznych {zakres_lat(lata_ryc_1)}. Pudełko obejmuje przedział od 25. do 75.
#   percentyla, kreska w środku to mediana, a punkty oznaczają wartości
#   odstające.{opis_linii_progowych}"
#
#   {opis_miejsc} to profile WSZYSTKICH stanowisk, np. "w profilach
#   wodowskazowych 502 i 501 w Stacji Bazowej ZMŚP Pojezierze Chełmińskie"; fraza znika
#   tylko na stacji, która ma w słowniku jeden profil (Wigry mają dwa, choć raport
#   opisuje samo 008, więc fraza zostaje).
#
# Uwagi do kodu:
#
# LATA NA OSI
#   Oś biegnie od pierwszego do ostatniego roku z dobowym przepływem (lata_ryc_1).
#   Rok bez pomiarów leżący w tym zakresie zostaje na osi jako pusta pozycja -
#   przerwa w serii jest widoczna.
#
# LINIE PROGOWE
#   Legenda wymienia wyłącznie linie, które faktycznie stoją na rycinie: granica
#   wezbrania małego bywa pomijana, bo przecinałaby granicę wezbrania zwykłego
#   (decyduje o tym linia_widoczna z funkcje/funkcje_pomocnicze.R). Ten sam wykaz -
#   kategorie_linii - rozwija skróty w podpisie ryciny.
#
# PANELE STANOWISK
#   Stacja z dwoma stanowiskami wodowskazowymi dostaje panel na każde z nich, jeden
#   pod drugim; linie progowe trafiają do właściwego panelu, bo dane_linie_progowe
#   niosą kod stanowiska. Przy jednym stanowisku paneli nie ma.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_dobowe_wiel: dobowe wartości przepływu wszystkich stanowisk, wszystkie lata
# - dane_linie_progowe, kategorie_linii: wartości graniczne kategorii i wykaz
#     tych, które trafiają na rycinę
# - lata_ryc_1 (lata z przepływem dobowym: zakres osi), ma_dwa_stanowiska, etykiety_stanowisk
################################################################################
# WYNIK
################################################################################
# - ryc_1: rycina (obiekt ggplot) albo NULL, gdy brak danych dobowych
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
# - dplyr
################################################################################

os_ryc_1 <- os_lat(lata_ryc_1)

# Rok jako faktor o poziomach z całego zakresu osi - dzięki temu zostaje na niej
# miejsce także na lata bez pomiarów.
dane_ryc_1 <- dane_dobowe_wiel |>
  mutate(rok_os = factor(rok_hydro, levels = os_ryc_1$breaks))

progi_ryc_1 <- dane_linie_progowe

ryc_1 = ggplot(dane_ryc_1, aes(x = rok_os, y = Q_E)) +
  geom_boxplot(na.rm = TRUE, linewidth = 0.3,
               outlier.colour = "darkred", outlier.size = 0.6) +
  geom_hline(data = progi_ryc_1,
             aes(yintercept = wartosc, colour = kategoria),
             linetype = "dashed", linewidth = 0.5) +
  # Panele tylko wtedy, gdy stacja ma dwa stanowiska; przy jednym wykres jest
  # bez paska panelu.
  (if (ma_dwa_stanowiska)
     facet_wrap(~ stanowisko, ncol = 1, scales = "free_y",
                labeller = as_labeller(etykiety_stanowisk))) +
  scale_x_discrete(labels = os_ryc_1$labels, drop = FALSE) +
  scale_colour_manual(name = "", values = kolory_kategorii,
                      breaks = kategorie_linii,
                      labels = unname(skroty_kategorii[kategorie_linii])) +
  xlab("") +
  ylab(etykieta_osi("Q_E")) +
  guides(colour = guide_legend(nrow = 1)) +
  plot_theme() +
  # Pasek panelu z kodem stanowiska: czarny pogrubiony napis nad wykresem, bez tła.
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5),
        strip.background = element_blank(),
        strip.text = element_text(size = 12, face = "bold", colour = "black"))

ryc_1

rm(dane_ryc_1, progi_ryc_1, os_ryc_1)

# Bez serii dobowej rycina byłaby pustą ramką z podpisem. NULL sprawia, że raport
# pomija jej blok w całości (eval = !is.null(ryc_1)).
if (!ma_dane(dane_dobowe_wiel$Q_E)) ryc_1 <- NULL
