################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 5 - udziały kategorii przepływu
#
# Trzy panele słupków skumulowanych, na każdym udział dni w sześciu kategoriach
# przepływu: A - w kolejnych miesiącach roku analizowanego, B - w miesiącach
# wielolecia, C - w kolejnych latach hydrologicznych. Panel A czyta się przez
# porównanie z panelem B: większy niż w wieloleciu udział niżówek oznacza miesiąc
# suchszy od przeciętnego, większy udział wezbrań - wilgotniejszy.
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Udziały kategorii natężenia przepływu {opis_miejsca}: A - w miesiącach roku hydrologicznego
#   {analizowany_rok}, B - w miesiącach wielolecia[ {opis_wielolecia_Q}], C - w
#   kolejnych latach hydrologicznych {zakres_lat(lata_ryc_5)}. {opis_kategorii}"
#
#   {opis_miejsca} to profil stanowiska ODNIESIENIA, np. "w profilu wodowskazowym
#   502 w Stacji Bazowej ZMŚP Pojezierze Chełmińskie"; fraza znika tylko
#   na stacji, która ma w słowniku jeden profil (Wigry mają dwa, choć raport opisuje
#   samo 008, więc fraza zostaje).
#   Fragment w nawiasie kwadratowym wypada, gdy baza nie ma dla stacji danych
#   wieloletnich. Gdy baza nie ma kategorii dla roku analizowanego, panel A wypada,
#   a pozostałe panele i człony podpisu dostają litery A i B.
#
# Uwagi do kodu:
#
# SŁUPEK NIŻSZY NIŻ 100%
#   Udziały liczone są względem liczby dni w okresie, a nie liczby dni z pomiarem,
#   więc okres z brakami nie domyka się do jedności. Niższy słupek to informacja
#   o niekompletnej serii.
#
# LEGENDA
#   Wymienia wszystkie sześć kategorii, także tę, która na danej stacji nie wystąpiła
#   ani razu - klucze poziomów bez danych przywraca klucze_legendy().
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_kategorie_miesiac_rok: udziały w miesiącach roku analizowanego
# - dane_kategorie_miesiac_wielolecie: udziały w miesiącach wielolecia
# - dane_kategorie_rok: udziały w kolejnych latach
# - lata_ryc_5 (lata z kategoriami: zakres osi panelu lat), analizowany_rok, opis_wielolecia_Q, brak_kategorii_w_roku
################################################################################
# WYNIK
################################################################################
# - ryc_5: rycina złożona z trzech paneli albo NULL, gdy brak danych o kategoriach
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
# - cowplot
################################################################################

# Wspólne elementy trzech paneli: paleta, skróty w legendzie oraz oś pionowa
# podpisana w procentach, od zera do stu.
skala_kategorii_5 <- list(
  scale_fill_manual(name = "", values = kolory_kategorii,
                    labels = unname(skroty_kategorii), drop = FALSE),
  scale_y_continuous(limits = c(0, 1), expand = expansion(mult = c(0, 0.02)),
                     labels = scales::label_percent(accuracy = 1)),
  ylab(""),
  plot_theme())

panel_miesiace_5 <- function(dane, tytul) {
  ggplot(dane, aes(x = miesiac, y = udzial, fill = kategoria)) +
    klucze_legendy(dane, "kategoria", names(kolory_kategorii)) +
    geom_bar(stat = "identity", position = "stack", na.rm = TRUE) +
    scale_x_discrete(labels = function(x) miesiac_rzymski(x), drop = FALSE) +
    xlab("") +
    ggtitle(tytul) +
    skala_kategorii_5 +
    # Mniejsza czcionka - dwanaście rzymskich podpisów musi się zmieścić na panelu
    # szerokim na pół ryciny.
    theme(axis.text.x = element_text(size = 9))
}

# A: rok analizowany. B: miesiące wielolecia.
ryc_5A <- panel_miesiace_5(dane_kategorie_miesiac_rok,
                           paste("Rok hydrologiczny", analizowany_rok))
# Tytuł panelu B to sam zakres lat wielolecia; jego kompletność podaje podpis ryciny.
ryc_5B <- panel_miesiace_5(dane_kategorie_miesiac_wielolecie,
                           paste("Wielolecie", wielolecie_Q))

# C: kolejne lata hydrologiczne.
os_ryc_5 <- os_lat(lata_ryc_5)

ryc_5C <- ggplot(dane_kategorie_rok, aes(x = rok_hydro, y = udzial, fill = kategoria)) +
  klucze_legendy(dane_kategorie_rok, "kategoria", names(kolory_kategorii)) +
  geom_bar(stat = "identity", position = "stack", na.rm = TRUE) +
  scale_x_continuous(breaks = os_ryc_5$breaks, labels = os_ryc_5$labels,
                     limits = os_ryc_5$limits, expand = expansion(add = 0)) +
  xlab("") +
  # Tytuł podaje zakres osi, a nie wykaz lat: przy lukach w serii wykaz nie mieści
  # się nad panelem, a luki i tak widać na osi. Pełny wykaz stoi w podpisie ryciny.
  ggtitle(paste0("Lata hydrologiczne ", min(os_ryc_5$breaks), "-", max(os_ryc_5$breaks))) +
  skala_kategorii_5 +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5))

# Legenda stoi tylko pod panelem C: we wszystkich trzech panelach znaczy to samo.
#
# Rok analizowany bez kategorii w bazie (rok zakwestionowany) nie dostaje pustego
# panelu A - panel bez słupków wyglądałby na usterkę. Rycina ma wtedy dwa panele:
# A - miesiące wielolecia i B - kolejne lata; podpis w tworzenie_raportu.qmd
# składa litery według tego samego znacznika brak_kategorii_w_roku.
panele_gorne_5 <- if (brak_kategorii_w_roku) list(ryc_5B) else list(ryc_5A, ryc_5B)
litery_5 <- LETTERS[seq_len(length(panele_gorne_5) + 1)]

ryc_5 = plot_grid(
  plot_grid(plotlist = lapply(panele_gorne_5, function(p) p + theme(legend.position = "none")),
            ncol = length(panele_gorne_5), labels = head(litery_5, -1),
            label_x = 0.02, hjust = 0),
  plot_grid(ryc_5C + guides(fill = guide_legend(nrow = 1)),
            labels = tail(litery_5, 1), label_x = 0.02, hjust = 0),
  ncol = 1, rel_heights = c(1, 1.2))

ryc_5

rm(skala_kategorii_5, panel_miesiace_5, os_ryc_5, ryc_5A, ryc_5B, ryc_5C,
   panele_gorne_5, litery_5)

# Stacja bez podziału na kategorie dałaby trzy puste ramki z podpisem.
if (!ma_dane(dane_kategorie_rok$udzial)) ryc_5 <- NULL
