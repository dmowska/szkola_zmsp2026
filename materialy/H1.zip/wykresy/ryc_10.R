################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 10 - miesięczny współczynnik przepływu na tle wielolecia
#
# Dwie linie prowadzone przez kolejne miesiące roku hydrologicznego (XI-X): rok
# analizowany i przebieg wieloletni. Współczynnik przepływu odnosi przepływ miesiąca
# do średniego przepływu wielolecia, więc linia przerywana przy wartości 1 wyznacza
# poziom przeciętny: punkt nad nią to miesiąc obfitszy niż zwykle, pod nią - uboższy.
# Zestawienie obu linii pokazuje, czy rok powtórzył typowy rozkład przepływu w roku,
# czy odbiegł od niego w konkretnych miesiącach.
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Miesięczny współczynnik natężenia przepływu {opis_miejsca} w roku hydrologicznym
#   {analizowany_rok}[ na tle wartości wieloletnich {opis_wielolecia_Q}]. Linia
#   przerywana wyznacza wartość 1, przy której miesięczne natężenie przepływu równa się
#   średniemu natężeniu przepływu wielolecia"
#
#   {opis_miejsca} to profil stanowiska ODNIESIENIA, np. "w profilu wodowskazowym
#   502 w Stacji Bazowej ZMŚP Pojezierze Chełmińskie"; fraza znika tylko
#   na stacji, która ma w słowniku jeden profil (Wigry mają dwa, choć raport opisuje
#   samo 008, więc fraza zostaje).
#   Fragment w nawiasie kwadratowym wypada, gdy baza nie ma dla stacji danych
#   wieloletnich.
#
# Uwagi do kodu:
#
# DWIE SERIE, TA SAMA KOLUMNA
#   Rok analizowany i wielolecie noszą w bazie tę samą nazwę kolumny (kj) i przychodzą
#   z dwóch różnych obiektów. Rozróżnia je dopiero kolumna seria, dopisywana przy
#   sklejaniu obu zestawów.
#
# WSPÓLNY MIANOWNIK
#   Obie serie są odniesione do tego samego średniego przepływu wielolecia - liczy je
#   baza, rycina tylko je zestawia. Dzięki temu porównuje się je wprost.
#
# STACJA BEZ WIELOLECIA
#   Serię bez wartości odrzucamy przed rysowaniem, a droplevels usuwa ją z legendy.
#   Rycina pokazuje wtedy samą linię roku analizowanego.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_miesieczne_rok: miesięczny współczynnik przepływu roku analizowanego (kj)
# - dane_wsp_miesieczny: wieloletni miesięczny współczynnik przepływu (kj)
# - analizowany_rok, wielolecie_Q
################################################################################
# WYNIK
################################################################################
# - ryc_10: rycina (obiekt ggplot) albo NULL, gdy żadna z dwóch serii nie ma wartości;
#     dokument pomija wtedy blok ryciny wraz z podpisem
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
# - dplyr
################################################################################

etykieta_roku_10 <- paste("rok", analizowany_rok)
# Legenda dostaje sam zakres lat - kompletność wielolecia podaje podpis ryciny.
etykieta_wielolecia_10 <- paste("wielolecie", wielolecie_Q)

dane_ryc_10 <- bind_rows(
  transmute(dane_miesieczne_rok, miesiac, wartosc = kj, seria = etykieta_roku_10),
  transmute(dane_wsp_miesieczny, miesiac, wartosc = kj, seria = etykieta_wielolecia_10)) |>
  filter(!is.na(wartosc)) |>
  # droplevels usuwa serię, dla której baza nie ma wartości - inaczej legenda
  # zapowiadałaby serię, której na rycinie nie widać.
  mutate(seria = droplevels(factor(seria, levels = c(etykieta_roku_10, etykieta_wielolecia_10))))

ryc_10 = ggplot(dane_ryc_10, aes(x = miesiac, y = wartosc, colour = seria, group = seria)) +
  geom_line(linewidth = 0.8) +
  geom_point(size = 1.2) +
  geom_hline(yintercept = 1, colour = "black", linewidth = 0.5, linetype = "dashed") +
  scale_colour_manual(name = "",
                      values = setNames(unname(kolory_rok_wielolecie),
                                        c(etykieta_roku_10, etykieta_wielolecia_10))) +
  scale_x_discrete(labels = function(x) miesiac_rzymski(x), drop = FALSE) +
  # Podziałka co 0,2 daje podpis osi przy wartości 1, czyli tam, gdzie stoi linia
  # odniesienia.
  scale_y_continuous(breaks = seq(0, 10, by = 0.2),
                     limits = c(0, max_lub(dane_ryc_10$wartosc) * 1.05)) +
  xlab("") +
  ylab(etykieta_osi("kj")) +
  guides(colour = guide_legend(nrow = 1)) +
  plot_theme()

ryc_10

rm(etykieta_roku_10, etykieta_wielolecia_10, dane_ryc_10)

# Rycina zestawia rok analizowany z wieloleciem, więc bez danych roku nie ma czego
# zestawiać - sama seria wieloletnia pod podpisem "w roku hydrologicznym ..." byłaby
# myląca. NULL sprawia, że dokument pomija jej blok (eval = !is.null(ryc_10)).
if (!ma_dane(dane_miesieczne_rok$kj)) ryc_10 <- NULL
