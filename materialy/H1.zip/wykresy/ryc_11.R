################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 11 - kompletność serii pomiarowych w ujęciu miesięcznym
#
# Mapa kafelków: w poziomie kolejne lata hydrologiczne, w pionie miesiące od listopada
# u góry do października u dołu, a barwa kafelka to klasa kompletności serii w tym
# miesiącu. Natężenie przepływu dostaje osobny panel dla każdego stanowiska, opad
# jeden, bo jest
# wspólny dla stacji. Najjaśniejsza klasa - "brak pomiaru" - oznacza, że serii w ogóle
# nie zarejestrowano, i jest czym innym niż klasa 0%, czyli seria istniejąca, ale bez
# ani jednego pomiaru.
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Kompletność serii pomiarowych natężenia przepływu i opadu atmosferycznego
#   {opis_miejsc} w ujęciu miesięcznym w latach hydrologicznych {zakres_lat(lata_ryc_11)}.
#   Próg uznania miesiąca za ważny wynosi 90% dla opadu atmosferycznego, a dla natężenia
#   przepływu od 50% do 90%, zależnie od charakteru zlewni - od nizinnej do górskiej.
#   Seria roczna wymaga 11 ważnych agregatów miesięcznych natężenia przepływu oraz 100%
#   kompletności opadu atmosferycznego"
#
#   {opis_miejsc} to profile WSZYSTKICH stanowisk, np. "w profilach
#   wodowskazowych 502 i 501 w Stacji Bazowej ZMŚP Pojezierze Chełmińskie"; fraza znika
#   tylko na stacji, która ma w słowniku jeden profil (Wigry mają dwa, choć raport
#   opisuje samo 008, więc fraza zostaje).
#
# Uwagi do kodu:
#
# PANELE
#   Składa je przetwarzanie_danych.R, razem z ich kolejnością zapisaną w poziomach
#   faktora panel - rycina niczego nie sortuje.
#
# KLASY KOMPLETNOŚCI
#   Podział na klasy i ich barwy niosą klasa_kompletnosci() oraz kolory_kompletnosc
#   z funkcje/funkcje_pomocnicze.R. Legenda wymienia komplet sześciu klas, także te,
#   których na mapie nie ma - dbają o to drop = FALSE oraz warstwa klucze_legendy(),
#   sama na rycinie niewidoczna.
#
# SIATKA
#   Linie siatki rysujemy ręcznie, na stykach kafelków - domyślna siatka ggplot
#   trafiałaby w ich środki.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_kompletnosc: kompletność w układzie rok x miesiąc, z klasą i panelem,
#     dla wszystkich stanowisk
# - lata_ryc_11 (lata z danymi miesięcznymi: zakres osi)
################################################################################
# WYNIK
################################################################################
# - ryc_11: rycina (obiekt ggplot) albo NULL, gdy brak danych o kompletności;
#     dokument pomija wtedy blok ryciny wraz z podpisem
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
################################################################################

os_ryc_11 <- os_lat(lata_ryc_11)

# Kolejność miesięcy na osi pionowej podajemy JAWNIE przez limits, zamiast odwracać
# faktor w aes(): kolejność osi dyskretnej powstaje wtedy z sumy wartości kolejnych
# warstw, więc warstwa domykająca legendę potrafi ją przestawić.
ryc_11 = ggplot(dane_kompletnosc,
                aes(x = rok_hydro, y = miesiac, fill = klasa)) +
  klucze_legendy(dane_kompletnosc, "klasa", names(kolory_kompletnosc)) +
  geom_tile() +
  geom_vline(xintercept = seq(min(os_ryc_11$breaks) - 0.5, max(os_ryc_11$breaks) + 0.5, by = 1),
             colour = "lightgrey", linewidth = 0.2) +
  geom_hline(yintercept = seq(0.5, length(miesiace_hydro) + 0.5, by = 1),
             colour = "lightgrey", linewidth = 0.2) +
  facet_wrap(~panel, ncol = 1) +
  scale_fill_manual(name = "Kompletność serii", values = kolory_kompletnosc, drop = FALSE) +
  scale_x_continuous(breaks = os_ryc_11$breaks, labels = os_ryc_11$labels,
                     expand = expansion(add = 0)) +
  scale_y_discrete(limits = rev(as.character(miesiace_hydro)),
                   labels = function(x) miesiac_rzymski(x)) +
  xlab("") +
  ylab("") +
  # Sześć klas kompletności nie mieści się w jednym wierszu na szerokości ryciny,
  # dlatego legenda idzie w dwóch wierszach.
  guides(fill = guide_legend(nrow = 2)) +
  plot_theme() +
  theme(panel.grid.major = element_blank(),
        strip.background = element_rect(colour = "darkgrey", fill = "white"),
        strip.text = element_text(colour = "black", face = "bold.italic", size = 11),
        axis.text.x = element_text(angle = 90, vjust = 0.5, size = 10),
        axis.text.y = element_text(size = 10),
        legend.key.size = unit(0.4, "cm"))

ryc_11

rm(os_ryc_11)

# Bez wartości kompletności rycina byłaby jednolicie szarą mapą z podpisem. NULL
# sprawia, że dokument pomija jej blok (eval = !is.null(ryc_11)).
if (!ma_dane(dane_kompletnosc$kompletnosc)) ryc_11 <- NULL
