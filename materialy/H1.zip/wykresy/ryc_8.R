################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 8 - miesięczny współczynnik odpływu na tle wielolecia
#
# Słupki stoją parami przy kolejnych miesiącach roku hydrologicznego (XI-X): rok
# analizowany obok wartości wieloletniej tego samego miesiąca. Współczynnik odpływu
# mówi, jaka część opadu odpłynęła ze zlewni, więc para słupków pokazuje, czy miesiąc
# odprowadził wodę obficiej, czy skąpiej niż zwykle. Linia przerywana przy wartości 1
# to poziom, przy którym odpływ zrównuje się z opadem.
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Miesięczne wartości współczynnika odpływu {opis_miejsca} w roku hydrologicznym
#   {analizowany_rok}[ na tle wartości miesięcznych wielolecia {opis_wielolecia_opad}].
#   Linia przerywana wyznacza wartość 1, przy której odpływ równa się opadowi"
#
#   {opis_miejsca} to profil stanowiska ODNIESIENIA, np. "w profilu wodowskazowym
#   502 w Stacji Bazowej ZMŚP Pojezierze Chełmińskie"; fraza znika tylko
#   na stacji, która ma w słowniku jeden profil (Wigry mają dwa, choć raport opisuje
#   samo 008, więc fraza zostaje).
#   Fragment w nawiasie kwadratowym wypada, gdy baza nie ma dla stacji danych
#   wieloletnich.
#
# Uwagi do kodu:
#
# DWIE SERIE, TA SAMA KOLUMNA
#   Rok analizowany i wielolecie noszą w bazie tę samą nazwę kolumny (a) i przychodzą
#   z dwóch różnych obiektów. Rozróżnia je dopiero kolumna seria, dopisywana przy
#   sklejaniu obu zestawów.
#
# STACJA BEZ WIELOLECIA
#   Serię bez wartości odrzucamy przed rysowaniem, a droplevels usuwa ją z legendy.
#   Rycina pokazuje wtedy sam rok analizowany, bez pustych miejsc w grupach słupków.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_miesieczne_rok: miesięczny współczynnik odpływu w roku analizowanym (a)
# - dane_wsp_miesieczny: wieloletni miesięczny współczynnik odpływu (a)
# - analizowany_rok, wielolecie_opad
################################################################################
# WYNIK
################################################################################
# - ryc_8: rycina (obiekt ggplot) albo NULL, gdy żadna z dwóch serii nie ma wartości;
#     dokument pomija wtedy blok ryciny wraz z podpisem
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
# - dplyr
################################################################################

etykieta_roku_8 <- paste("rok", analizowany_rok)
# Legenda dostaje sam zakres lat - kompletność wielolecia podaje podpis ryciny.
etykieta_wielolecia_8 <- paste("wielolecie", wielolecie_opad)

dane_ryc_8 <- bind_rows(
  transmute(dane_miesieczne_rok, miesiac, a, seria = etykieta_roku_8),
  transmute(dane_wsp_miesieczny, miesiac, a, seria = etykieta_wielolecia_8)) |>
  filter(!is.na(a)) |>
  # droplevels usuwa serię, dla której baza nie ma wartości - inaczej legenda
  # zapowiadałaby serię, której na rycinie nie widać.
  mutate(seria = droplevels(factor(seria, levels = c(etykieta_roku_8, etykieta_wielolecia_8))))

ryc_8 = ggplot(dane_ryc_8, aes(x = miesiac, y = a, fill = seria)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.75), width = 0.7) +
  geom_hline(yintercept = 1, colour = "black", linewidth = 0.5, linetype = "dashed") +
  scale_fill_manual(name = "",
                    values = setNames(unname(kolory_rok_wielolecie),
                                      c(etykieta_roku_8, etykieta_wielolecia_8))) +
  scale_x_discrete(labels = function(x) miesiac_rzymski(x), drop = FALSE) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  xlab("") +
  ylab(etykieta_osi("a")) +
  guides(fill = guide_legend(nrow = 1)) +
  plot_theme()

ryc_8

rm(etykieta_roku_8, etykieta_wielolecia_8, dane_ryc_8)

# Rycina zestawia rok analizowany z wieloleciem, więc bez danych roku nie ma czego
# zestawiać - sama seria wieloletnia pod podpisem "w roku hydrologicznym ..." byłaby
# myląca. NULL sprawia, że dokument pomija jej blok (eval = !is.null(ryc_8)).
if (!ma_dane(dane_miesieczne_rok$a)) ryc_8 <- NULL
