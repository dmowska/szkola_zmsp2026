################################################################################
# OPIS SKRYPTU
################################################################################
# Rycina 7 - roczne sumy opadu i odpływu
#
# Każdy rok hydrologiczny zakresu analizy dostaje dwa słupki wpisane jeden w drugi:
# ciemniejszy to suma opadu atmosferycznego, jaśniejszy - warstwa odpływu, czyli ta
# część opadu, która ze zlewni odpłynęła. Liczba obrócona nad słupkiem to współczynnik
# odpływu tego roku. Im mniejsza różnica między słupkami, tym większa część opadu
# zamieniła się w odpływ.
#
# Podpis w raporcie (w klamrach wartości wstawiane z danych):
#   "Roczne sumy opadu atmosferycznego i warstwy odpływu {opis_miejsca} w kolejnych
#   latach hydrologicznych {zakres_lat(lata_ryc_7)}. Liczby nad słupkami to współczynnik
#   odpływu[; jego średnia wartość dla wielolecia {opis_wielolecia_opad} wynosi
#   {wartość}]"
#
#   {opis_miejsca} to profil stanowiska ODNIESIENIA, np. "w profilu wodowskazowym
#   502 w Stacji Bazowej ZMŚP Pojezierze Chełmińskie"; fraza znika tylko
#   na stacji, która ma w słowniku jeden profil (Wigry mają dwa, choć raport opisuje
#   samo 008, więc fraza zostaje).
#   Fragment w nawiasie kwadratowym wypada, gdy baza nie ma dla stacji danych
#   wieloletnich.
#
# Uwagi do kodu:
#
# SŁUPKI JEDEN W DRUGIM
#   position = "identity" nakłada słupek odpływu na słupek opadu, zamiast stawiać oba
#   obok siebie. Współczynnik odpływu rzadko przekracza jedność, więc odpływ zwykle
#   mieści się w opadzie - gdy jednak wystaje ponad niego, oznacza to rok, w którym
#   odpłynęło więcej, niż spadło.
#
# ROK BEZ WARTOŚCI
#   Oś biegnie od pierwszego do ostatniego roku z danymi rocznymi (lata_ryc_7), więc
#   rok bez pomiarów leżący w tym zakresie zostaje na niej pustym miejscem - przerwa
#   w serii ma być widoczna.
################################################################################
# DANE WEJŚCIOWE
################################################################################
# - dane_roczne: roczne sumy opadu (RR_T) i warstwy odpływu (O) oraz współczynnik
#     odpływu (a), dla stanowiska odniesienia
# - lata_ryc_7 (lata z danymi rocznymi: zakres osi)
################################################################################
# WYNIK
################################################################################
# - ryc_7: rycina (obiekt ggplot) albo NULL, gdy brak danych o opadzie i odpływie;
#     dokument pomija wtedy blok ryciny wraz z podpisem
################################################################################
# WYMAGANE PAKIETY
################################################################################
# - ggplot2
# - dplyr
################################################################################

os_ryc_7 <- os_lat(lata_ryc_7)

# Zapas na obrócone etykiety współczynnika odpływu nad słupkami.
gora_ryc_7 <- max_lub(c(dane_roczne$RR_T, dane_roczne$O)) * 1.15

kolory_ryc_7 <- c("opad" = "#2f75b5", "odpływ" = "#a6cee3")

# Wielkość O to warstwa odpływu, czyli wysokość warstwy w milimetrach, a nie natężenie
# odpływu - dlatego stoi na tej samej osi co opad.

ryc_7 = ggplot(dane_roczne, aes(x = rok_hydro)) +
  geom_col(aes(y = RR_T, fill = "opad"), position = "identity", na.rm = TRUE) +
  geom_col(aes(y = O, fill = "odpływ"), position = "identity", na.rm = TRUE) +
  geom_text(data = filter(dane_roczne, !is.na(a)),
            aes(y = RR_T, label = format(round(a, 2), nsmall = 2)),
            angle = 90, hjust = -0.15, vjust = 0.5, size = 9 / .pt, na.rm = TRUE) +
  # Jawne breaks ustawiają w legendzie tę samą kolejność co na rycinie: opad,
  # potem odpływ. Domyślna byłaby alfabetyczna, czyli odwrotna.
  scale_fill_manual(name = "", values = kolory_ryc_7,
                    breaks = c("opad", "odpływ"),
                    labels = c("opad" = "opad atmosferyczny",
                               "odpływ" = "warstwa odpływu")) +
  scale_x_continuous(breaks = os_ryc_7$breaks, labels = os_ryc_7$labels,
                     limits = os_ryc_7$limits, expand = expansion(add = 0)) +
  scale_y_continuous(limits = c(0, gora_ryc_7), expand = expansion(mult = c(0, 0.02))) +
  xlab("") +
  ylab("Opad atmosferyczny, warstwa odpływu [mm]") +
  guides(fill = guide_legend(nrow = 1)) +
  plot_theme() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5))

ryc_7

rm(os_ryc_7, gora_ryc_7, kolory_ryc_7)

# Stacja bez pomiarów opadu dałaby wykres z samym odpływem i legendą zapowiadającą
# serię, której nie ma. NULL sprawia, że dokument pomija blok ryciny
# (eval = !is.null(ryc_7)).
if (!ma_dane(dane_roczne$RR_T) || !ma_dane(dane_roczne$O)) ryc_7 <- NULL
