################################################################################
# OPIS SKRYPTU
################################################################################
# instaluj_pakiety.R - jednorazowa instalacja pakietów R potrzebnych do programów
# A1 (meteorologia) i H1 (hydrologia) ZMŚP.
#
# JAK URUCHOMIĆ
#   1. Otwórz ten plik w RStudio (menu File -> Open File...).
#   2. Kliknij przycisk Source w prawym górnym rogu okna z kodem
#      (albo naciśnij Ctrl+Shift+S; na macOS Cmd+Shift+S).
#   3. Poczekaj. Pierwsza instalacja trwa od kilku do kilkunastu minut.
#      Na końcu w konsoli pojawi się podsumowanie: co jest zainstalowane,
#      a czego brakuje.
#
#   Skrypt można uruchamiać wielokrotnie - pakiety już zainstalowane są pomijane.
#
# DLACZEGO SKRYPT O NIC NIE PYTA
#   Zwykła instalacja potrafi zatrzymać się na pytaniu TAK/NIE (np. "Do you want
#   to install from sources the package which needs compilation?") albo na pytaniu
#   o wybór serwera CRAN. Ustawienia z części 1 usuwają wszystkie trzy takie
#   pytania, dlatego instalacja idzie do końca bez udziału użytkownika. Szczegóły
#   opisano przy każdym ustawieniu niżej.
################################################################################

################################################################################
# 1. USTAWIENIA, DZIĘKI KTÓRYM INSTALACJA O NIC NIE PYTA
################################################################################

## 1a. Serwer, z którego pobieramy pakiety ##
# Bez tego R przy pierwszej instalacji otwiera okienko z listą serwerów CRAN
# i czeka, aż użytkownik wybierze jeden z nich. Poniżej wybieramy go z góry:
# cloud.r-project.org to serwer globalny, który sam kieruje na najbliższy serwer.
options(repos = c(CRAN = "https://cloud.r-project.org"))

## 1b. Żadnego kompilowania ze źródeł ##
# To jest to słynne pytanie TAK/NIE. Pojawia się, gdy na CRAN leży nowsza wersja
# pakietu w postaci źródłowej niż gotowa wersja binarna: R pyta wtedy, czy
# skompilować ją na miejscu. Kompilacja na Windows wymaga dodatkowego programu
# (Rtools), trwa długo i często kończy się błędem - a gotowa wersja binarna jest
# w zupełności wystarczająca. Poniższe ustawienie sprawia, że R nigdy nie pyta
# i zawsze bierze wersję binarną.
options(install.packages.compile.from.source = "never")

# Windows i macOS mają gotowe paczki binarne - wymuszamy je jawnie.
# Na Linuksie pakiety buduje się ze źródeł i żadne pytanie się nie pojawia,
# więc zostawiamy domyślne ustawienie systemu.
system_operacyjny <- Sys.info()[["sysname"]]
typ_instalacji <- if (system_operacyjny %in% c("Windows", "Darwin")) {
  "binary"
} else {
  getOption("pkgType")
}

## 1c. Własna biblioteka pakietów użytkownika ##
# Trzecie pytanie, które potrafi zatrzymać instalację, brzmi mniej więcej:
# "Would you like to use a personal library instead?" - R zadaje je, gdy nie ma
# prawa zapisu do głównego katalogu z pakietami (typowa sytuacja na komputerze
# służbowym). Tworzymy więc ten prywatny katalog sami i wskazujemy go R-owi,
# zanim cokolwiek zaczniemy instalować.
biblioteka_uzytkownika <- Sys.getenv("R_LIBS_USER")
if (nzchar(biblioteka_uzytkownika)) {
  if (!dir.exists(biblioteka_uzytkownika)) {
    dir.create(biblioteka_uzytkownika, recursive = TRUE, showWarnings = FALSE)
  }
  if (dir.exists(biblioteka_uzytkownika)) {
    .libPaths(c(biblioteka_uzytkownika, .libPaths()))
  }
}

################################################################################
# 2. LISTA PAKIETÓW
################################################################################
# Pakiet to dodatek do R - zestaw gotowych funkcji. Same programy A1 i H1 nie
# zadziałają bez nich.
#
# Poniższe listy są rozpisane osobno dla A1 i dla H1, żeby było widać, co czemu
# służy. Instalujemy jednak sumę obu list (zmienna "pakiety" niżej): większość
# pakietów i tak się powtarza, a komplet nie przeszkadza w niczym - każdy program
# wczytuje tylko to, czego potrzebuje.

pakiety_A1 <- c(
  "RPostgres",     # połączenie z bazą danych ZMŚP (PostgreSQL)
  "readxl",        # czytanie pliku parametry/parametry.xlsx
  "tidyverse",     # zestaw pakietów do przetwarzania danych i rycin
                   #   (ggplot2, dplyr, tidyr, forcats, purrr, readr, stringr)
  "cowplot",       # składanie kilku rycin w jedną
  "ggrepel",       # etykiety na rycinach, które na siebie nie nachodzą
  "RColorBrewer",  # palety kolorów
  "scales",        # formatowanie osi i etykiet
  "svglite",       # zapis rycin do plików SVG
  "flextable",     # tabele w raporcie Word
  "openxlsx",      # zapis tabel do pliku Excela
  "trend",         # testy trendu (Manna-Kendalla)
  "quarto"         # składanie raportu Word z pliku .qmd
)

pakiety_H1 <- c(
  "RPostgres",     # połączenie z bazą danych ZMŚP (PostgreSQL)
  "DBI",           # wspólny interfejs do baz danych
  "readxl",        # czytanie pliku parametry/parametry.xlsx
  "tidyverse",     # przetwarzanie danych i ryciny
  "cowplot",       # składanie rycin
  "svglite",       # zapis rycin do plików SVG
  "flextable",     # tabele w raporcie i aneksie Word
  "openxlsx",      # zapis tabel do pliku Excela
  "quarto"         # składanie raportu i aneksu z plików .qmd
)

# Pakiety, których A1 i H1 nie wczytują wprost, ale bez których praca się nie uda.
# knitr i rmarkdown wykonują kod R w dokumentach .qmd; rstudioapi pozwala skryptom
# ustalić własny katalog roboczy, gdy uruchamiamy je z RStudio.
pakiety_dodatkowe <- c("knitr", "rmarkdown", "rstudioapi")

pakiety <- unique(c(pakiety_A1, pakiety_H1, pakiety_dodatkowe))

################################################################################
# 3. INSTALACJA
################################################################################

message("\n=== Instalacja pakietów R dla programów A1 i H1 ===")
message("  System:          ", system_operacyjny)
message("  Wersja R:        ", getRversion())
message("  Pakiety trafią do: ", .libPaths()[1])

# Instalujemy tylko to, czego jeszcze nie ma - dzięki temu skrypt można uruchomić
# ponownie po przerwanym pobieraniu i nie zaczyna od zera.
zainstalowane <- rownames(installed.packages())
brakujace <- setdiff(pakiety, zainstalowane)

if (length(brakujace) == 0) {
  message("\n  Wszystkie potrzebne pakiety są już zainstalowane.")
} else {
  message("\n  Do zainstalowania (", length(brakujace), "): ",
          paste(brakujace, collapse = ", "))
  message("  To potrwa od kilku do kilkunastu minut. Nie zamykaj RStudio.\n")

  # dependencies = c("Depends", "Imports", "LinkingTo") to komplet pakietów,
  # bez których instalowany pakiet nie działa. R dociąga je sam, bez pytania.
  # (Wartość TRUE dołożyłaby jeszcze pakiety z sekcji Suggests - setki pakietów
  # używanych wyłącznie w testach i przykładach; nie są nam do niczego potrzebne.)
  install.packages(brakujace,
                   type = typ_instalacji,
                   dependencies = c("Depends", "Imports", "LinkingTo"))
}

################################################################################
# 4. SPRAWDZENIE, CZY WSZYSTKO SIĘ UDAŁO
################################################################################
# install.packages() nie przerywa pracy, gdy któregoś pakietu nie da się pobrać -
# wypisuje ostrzeżenie, które łatwo przeoczyć wśród setek linii z instalacji.
# Dlatego na koniec sprawdzamy każdy pakiet po kolei i wypisujemy czytelną listę.

message("\n=== Sprawdzenie ===")
wynik <- vapply(pakiety, requireNamespace, logical(1), quietly = TRUE)

for (p in pakiety) {
  message(if (wynik[[p]]) "  [OK]    " else "  [BRAK]  ", p)
}

################################################################################
# 5. SPRAWDZENIE PROGRAMU QUARTO
################################################################################
# Quarto to osobny program (nie pakiet R), który składa raporty Word z plików
# .qmd. Nowsze wersje RStudio mają go w sobie. Pakiet R o nazwie quarto jest
# tylko łącznikiem do tego programu i szuka go w zmiennej środowiskowej
# QUARTO_PATH oraz na ścieżce systemowej PATH - RStudio wskazuje własną kopię
# zmienną RSTUDIO_QUARTO, o której pakiet quarto nie wie, więc podstawiamy ją
# tak samo, jak robią to skrypty uruchamianie_skryptow.R w A1 i H1.
if (wynik[["quarto"]]) {
  if (is.null(quarto::quarto_path()) && nzchar(Sys.getenv("RSTUDIO_QUARTO"))) {
    wskazanie <- Sys.getenv("RSTUDIO_QUARTO")
    plik_quarto <- if (.Platform$OS.type == "windows") "quarto.exe" else "quarto"
    kandydaci <- c(wskazanie,
                   file.path(wskazanie, plik_quarto),
                   file.path(wskazanie, "bin", plik_quarto))
    kandydaci <- kandydaci[file.exists(kandydaci) & !dir.exists(kandydaci)]
    if (length(kandydaci) > 0) Sys.setenv(QUARTO_PATH = kandydaci[1])
  }
  sciezka_quarto <- quarto::quarto_path()
} else {
  sciezka_quarto <- NULL
}

################################################################################
# 6. PODSUMOWANIE
################################################################################

message("\n=== Podsumowanie ===")

if (all(wynik)) {
  message("  Pakiety: komplet (", length(pakiety), " pakietów).")
} else {
  message("  Pakiety: BRAKUJE ", sum(!wynik), " z ", length(pakiety), ": ",
          paste(names(wynik)[!wynik], collapse = ", "))
  message("  Co zrobić: uruchom ten skrypt jeszcze raz (przycisk Source).\n",
          "  Jeśli braki zostaną, poszukaj w konsoli czerwonej linii ze słowem\n",
          "  'ERROR' albo 'nie powiodło' przy nazwie pakietu i prześlij ją osobie,\n",
          "  która przekazała Ci projekt.")
}

if (is.null(sciezka_quarto)) {
  message("  Quarto:  NIE ZNALEZIONO. Bez niego raport Word nie powstanie.\n",
          "           Pobierz Quarto ze strony https://quarto.org, zainstaluj,\n",
          "           uruchom RStudio ponownie i kliknij Source jeszcze raz.")
} else {
  message("  Quarto:  ", sciezka_quarto)
}

if (all(wynik) && !is.null(sciezka_quarto)) {
  message("\n>>> Gotowe. Następny krok: otwórz plik test.qmd i kliknij Render.")
}
